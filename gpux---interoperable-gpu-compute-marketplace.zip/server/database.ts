import { 
  ClusterNode, 
  ContractStatus, 
  GpuCapability, 
  GpuModelId, 
  LiveGpuTelemetry, 
  OrderBookEntry, 
  ProofOfCompute, 
  ProviderFacility, 
  SettlementMethod, 
  SpotMarketState, 
  StrikeContract,
  GpuxIndex,
  MacroScenario
} from './types.js';
import { GPU_CAPABILITY_CATALOG, calculateNormalizedCu } from './gpuModels.js';

export interface BlockchainBlock {
  blockNumber: number;
  blockHash: string;
  previousHash: string;
  timestamp: string;
  txCount: number;
  transactions: {
    txHash: string;
    type: 'ESCROW_LOCK' | 'PROOF_VERIFIED' | 'SETTLEMENT_PAYOUT' | 'SLA_SLASH' | 'ORACLE_UPDATE';
    contractId?: string;
    amountUsd?: number;
    proofHash?: string;
    from: string;
    to: string;
    status: 'SUCCESS' | 'FINALIZED';
  }[];
}

class GpuxDatabase {
  facilities: ProviderFacility[] = [];
  nodes: ClusterNode[] = [];
  orders: OrderBookEntry[] = [];
  trades: { id: string; gpuModel: GpuModelId; quantity: number; price: number; timestamp: string; buyer: string; seller: string }[] = [];
  contracts: StrikeContract[] = [];
  proofs: ProofOfCompute[] = [];
  blocks: BlockchainBlock[] = [];
  activeScenarioKey: string = 'BASE_MARKET';

  // Real-time market states per GPU model
  spotMarketStates: Record<GpuModelId, SpotMarketState> = {} as any;

  constructor() {
    this.seedDatabase();
    this.initSpotMarkets();
    this.seedGenesisBlocks();
  }

  seedDatabase() {
    this.facilities = [
      {
        id: 'FAC-CW-NJ-01',
        providerId: 'PROV-COREWEAVE',
        providerName: 'CoreWeave NeoCloud',
        providerType: 'NEOCLOUD',
        facilityId: 'facility-us-east-nj01',
        facilityName: 'Weehawken Tier IV HPC',
        region: 'US-East (New Jersey)',
        country: 'United States',
        city: 'Weehawken',
        lat: 40.7684,
        lng: -74.0199,
        pue: 1.14,
        electricityRateKwh: 0.082,
        greenEnergyPercentage: 78,
        networkTier: 'Tier 1 InfiniBand Quantum-2',
        egressCostGb: 0.015,
        clusterCount: 16,
        totalGpuCount: 16384,
        availableGpuCount: 2048,
        externalProviderId: 'coreweave-nj-ord01'
      },
      {
        id: 'FAC-LAMBDA-TX-02',
        providerId: 'PROV-LAMBDA',
        providerName: 'Lambda Labs Compute',
        providerType: 'NEOCLOUD',
        facilityId: 'facility-us-south-austin',
        facilityName: 'Austin TeraScale Facility',
        region: 'US-South (Texas)',
        country: 'United States',
        city: 'Austin',
        lat: 30.2672,
        lng: -97.7431,
        pue: 1.18,
        electricityRateKwh: 0.068,
        greenEnergyPercentage: 65,
        networkTier: 'RoCE v2 800Gbps Mesh',
        egressCostGb: 0.02,
        clusterCount: 12,
        totalGpuCount: 8192,
        availableGpuCount: 1024,
        externalProviderId: 'lambda-austin-cluster-04'
      },
      {
        id: 'FAC-CRUSOE-ND-01',
        providerId: 'PROV-CRUSOE',
        providerName: 'Crusoe Clean Cloud',
        providerType: 'NEOCLOUD',
        facilityId: 'facility-us-midwest-bakken',
        facilityName: 'Bakken Flare Mitigation Hydro-DataCenter',
        region: 'US-Midwest (North Dakota)',
        country: 'United States',
        city: 'Williston',
        lat: 48.147,
        lng: -103.618,
        pue: 1.08,
        electricityRateKwh: 0.042, // Extremely cheap stranded flared gas power
        greenEnergyPercentage: 99,
        networkTier: 'InfiniBand NDR 400G',
        egressCostGb: 0.03,
        clusterCount: 8,
        totalGpuCount: 4096,
        availableGpuCount: 768,
        externalProviderId: 'crusoe-flare-hydro-01'
      },
      {
        id: 'FAC-NEBIUS-FI-01',
        providerId: 'PROV-NEBIUS',
        providerName: 'Nebius AI European Grid',
        providerType: 'NEOCLOUD',
        facilityId: 'facility-eu-north-mantsala',
        facilityName: 'Mäntsälä Geothermal Sub-Arctic',
        region: 'Europe-North (Finland)',
        country: 'Finland',
        city: 'Mäntsälä',
        lat: 60.6358,
        lng: 25.3183,
        pue: 1.05,
        electricityRateKwh: 0.055,
        greenEnergyPercentage: 100,
        networkTier: 'Full NVLink-4 Rail-Optimized',
        egressCostGb: 0.012,
        clusterCount: 10,
        totalGpuCount: 10240,
        availableGpuCount: 1840,
        externalProviderId: 'nebius-finland-dc02'
      },
      {
        id: 'FAC-EQUINIX-LDN-01',
        providerId: 'PROV-EQUINIX',
        providerName: 'Equinix Metal Interconnect',
        providerType: 'PRIVATE_DATACENTRE',
        facilityId: 'facility-eu-west-ldn08',
        facilityName: 'LD8 London Docklands AI Hub',
        region: 'Europe-West (London)',
        country: 'United Kingdom',
        city: 'London',
        lat: 51.5074,
        lng: -0.1278,
        pue: 1.25,
        electricityRateKwh: 0.165,
        greenEnergyPercentage: 85,
        networkTier: 'Direct Equinix Fabric 100Gbps low-latency',
        egressCostGb: 0.04,
        clusterCount: 6,
        totalGpuCount: 3072,
        availableGpuCount: 384,
        externalProviderId: 'eqx-ld8-metal-gpus'
      },
      {
        id: 'FAC-AWS-IAD-01',
        providerId: 'PROV-AWS',
        providerName: 'AWS EC2 UltraClusters',
        providerType: 'HYPERSCALER',
        facilityId: 'facility-us-east-iad',
        facilityName: 'Northern Virginia P5/P4de MegaZone',
        region: 'US-East (N. Virginia)',
        country: 'United States',
        city: 'Ashburn',
        lat: 39.0438,
        lng: -77.4874,
        pue: 1.22,
        electricityRateKwh: 0.095,
        greenEnergyPercentage: 70,
        networkTier: 'EFA 3200 Gbps Petabit Scale',
        egressCostGb: 0.08, // Higher hyperscaler egress
        clusterCount: 24,
        totalGpuCount: 32768,
        availableGpuCount: 3200,
        externalProviderId: 'aws-us-east-1-az4'
      }
    ];

    // Generate clusters & nodes
    let nodeCounter = 100;
    for (const fac of this.facilities) {
      // H100 SXM5 nodes
      for (let i = 1; i <= 4; i++) {
        this.nodes.push({
          id: `NODE-H100-${nodeCounter++}`,
          clusterId: `CLUSTER-${fac.id}-H100-01`,
          facilityId: fac.id,
          providerId: fac.providerId,
          nodeName: `sxm5-h100-node-${i.toString().padStart(2, '0')}`,
          gpuModel: 'H100_SXM5',
          gpuCount: 8,
          cpuModel: 'Dual Intel Xeon Platinum 8480+ (112 cores)',
          ramGb: 2048,
          storageTb: 30,
          interconnect: 'NVLINK_4',
          networkSpeedGbps: 3200,
          status: i === 4 ? 'RESERVED' : 'AVAILABLE',
          hourlySpotAsk: Number((41.5 + (fac.electricityRateKwh * 15) + (Math.random() * 2.5 - 1.2)).toFixed(2)),
          reliabilityScore: 0.998,
          externalNodeId: `${fac.externalProviderId}-n${i}`
        });
      }

      // H200 nodes in select facilities
      if (fac.id.includes('CW') || fac.id.includes('NEBIUS') || fac.id.includes('AWS')) {
        for (let i = 1; i <= 2; i++) {
          this.nodes.push({
            id: `NODE-H200-${nodeCounter++}`,
            clusterId: `CLUSTER-${fac.id}-H200-01`,
            facilityId: fac.id,
            providerId: fac.providerId,
            nodeName: `sxm5-h200-node-${i.toString().padStart(2, '0')}`,
            gpuModel: 'H200_SXM5',
            gpuCount: 8,
            cpuModel: 'Dual AMD EPYC 9654 96-Core',
            ramGb: 2048,
            storageTb: 60,
            interconnect: 'NVLINK_4',
            networkSpeedGbps: 3200,
            status: 'AVAILABLE',
            hourlySpotAsk: Number((54.0 + (fac.electricityRateKwh * 15) + (Math.random() * 3 - 1.5)).toFixed(2)),
            reliabilityScore: 0.999,
            externalNodeId: `${fac.externalProviderId}-h200-n${i}`
          });
        }
      }

      // B200 next-gen nodes
      if (fac.id.includes('CW') || fac.id.includes('NEBIUS')) {
        this.nodes.push({
          id: `NODE-B200-${nodeCounter++}`,
          clusterId: `CLUSTER-${fac.id}-B200-PILOT`,
          facilityId: fac.id,
          providerId: fac.providerId,
          nodeName: `blackwell-b200-node-01`,
          gpuModel: 'B200',
          gpuCount: 8,
          cpuModel: 'Grace CPU + Dual AMD Turin 128-Core',
          ramGb: 3072,
          storageTb: 100,
          interconnect: 'NVLINK_5',
          networkSpeedGbps: 6400,
          status: 'AVAILABLE',
          hourlySpotAsk: Number((72.0 + (fac.electricityRateKwh * 20)).toFixed(2)),
          reliabilityScore: 0.995,
          externalNodeId: `${fac.externalProviderId}-b200-pilot`
        });
      }

      // A100 / L40S nodes
      this.nodes.push({
        id: `NODE-A100-${nodeCounter++}`,
        clusterId: `CLUSTER-${fac.id}-A100-LEGACY`,
        facilityId: fac.id,
        providerId: fac.providerId,
        nodeName: `sxm4-a100-node-01`,
        gpuModel: 'A100_SXM4_80GB',
        gpuCount: 8,
        cpuModel: 'Dual AMD EPYC 7763 64-Core',
        ramGb: 1024,
        storageTb: 15,
        interconnect: 'INFINIBAND_HDR',
        networkSpeedGbps: 1600,
        status: 'AVAILABLE',
        hourlySpotAsk: Number((22.5 + (fac.electricityRateKwh * 10)).toFixed(2)),
        reliabilityScore: 0.994,
        externalNodeId: `${fac.externalProviderId}-a100-01`
      });

      this.nodes.push({
        id: `NODE-L40S-${nodeCounter++}`,
        clusterId: `CLUSTER-${fac.id}-L40S-INFER`,
        facilityId: fac.id,
        providerId: fac.providerId,
        nodeName: `l40s-pcie-node-01`,
        gpuModel: 'L40S',
        gpuCount: 8,
        cpuModel: 'Dual Intel Xeon 6430',
        ramGb: 512,
        storageTb: 10,
        interconnect: 'PCIE_GEN5',
        networkSpeedGbps: 400,
        status: 'AVAILABLE',
        hourlySpotAsk: Number((14.8 + (fac.electricityRateKwh * 8)).toFixed(2)),
        reliabilityScore: 0.992,
        externalNodeId: `${fac.externalProviderId}-l40s-01`
      });
    }

    // Seed active demo strike contracts
    this.contracts = [
      {
        id: 'CTR-STRIKE-78901',
        contractNumber: 'GPUX-FWD-H100-20260901-01',
        buyerAddress: '0x71C...4a91',
        buyerName: 'Anthropic AI Research Ops',
        sellerAddress: '0x99A...12bc',
        sellerName: 'CoreWeave Automated Market Vault',
        gpuModel: 'H100_SXM5',
        gpuQuantity: 64,
        totalNormalizedCu: 64,
        executionStartTime: new Date(Date.now() + 86400000 * 3).toISOString(),
        executionEndTime: new Date(Date.now() + 86400000 * 3 + 3600000 * 12).toISOString(),
        durationHours: 12,
        strikePricePerGpuHour: 41.20,
        totalPremiumUsd: 2845.00,
        notionalValueUsd: 31641.60,
        escrowLockedUsd: 31641.60,
        settlementMethod: 'PHYSICAL_EXECUTION',
        performanceFloorPct: 96.0,
        availabilityFloorPct: 99.8,
        locationConstraint: 'US-East (New Jersey)',
        status: 'ESCROW_LOCKED',
        createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
        txHashEscrow: '0x4f89d3a1290b4e28741eafc83002341908ab9182371928374910283746192837'
      },
      {
        id: 'CTR-STRIKE-78902',
        contractNumber: 'GPUX-FWD-H200-20260915-04',
        buyerAddress: '0x33B...8109',
        buyerName: 'DeepSeek Infrastructure Cluster',
        sellerAddress: '0x55E...90ff',
        sellerName: 'Nebius European Liquidity Vault',
        gpuModel: 'H200_SXM5',
        gpuQuantity: 128,
        totalNormalizedCu: 176.64,
        executionStartTime: new Date(Date.now() - 3600000 * 6).toISOString(),
        executionEndTime: new Date(Date.now() + 3600000 * 18).toISOString(),
        durationHours: 24,
        strikePricePerGpuHour: 53.50,
        totalPremiumUsd: 8900.00,
        notionalValueUsd: 164352.00,
        escrowLockedUsd: 164352.00,
        settlementMethod: 'PHYSICAL_EXECUTION',
        performanceFloorPct: 95.0,
        availabilityFloorPct: 99.5,
        locationConstraint: 'Europe-North (Finland)',
        status: 'ACTIVE_EXECUTING',
        createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
        txHashEscrow: '0x99281a8b27341209384729102837461928374619082736451928374619203847'
      },
      {
        id: 'CTR-STRIKE-78903',
        contractNumber: 'GPUX-OPT-B200-20260810-09',
        buyerAddress: '0x88F...4302',
        buyerName: 'Mistral Frontier Model Train',
        sellerAddress: '0x77C...11aa',
        sellerName: 'Crusoe Flared Gas Compute Pool',
        gpuModel: 'B200',
        gpuQuantity: 32,
        totalNormalizedCu: 91.2,
        executionStartTime: new Date(Date.now() - 3600000 * 30).toISOString(),
        executionEndTime: new Date(Date.now() - 3600000 * 6).toISOString(),
        durationHours: 24,
        strikePricePerGpuHour: 69.00,
        totalPremiumUsd: 4120.00,
        notionalValueUsd: 52992.00,
        escrowLockedUsd: 52992.00,
        settlementMethod: 'PHYSICAL_EXECUTION',
        performanceFloorPct: 95.0,
        availabilityFloorPct: 99.5,
        status: 'SETTLED',
        createdAt: new Date(Date.now() - 3600000 * 72).toISOString(),
        txHashEscrow: '0x12a9bc4908123746192837461920384756192837461928374619283746192837',
        txHashSettlement: '0x8837192038475619283746192837461928374619082736451928374619203847',
        proofHash: '0x3b89019283746192837461920384756192837461928374619283746192837461',
        actualDeliveredPerformance: 98.4,
        actualAvailability: 100.0,
        settlementAmountUsd: 52992.00,
        penaltySlashedUsd: 0.00
      }
    ];

    // Seed proofs
    this.proofs = [
      {
        id: 'PROOF-90821',
        contractId: 'CTR-STRIKE-78903',
        jobId: 'JOB-MISTRAL-TRAIN-8921',
        providerId: 'PROV-CRUSOE',
        nodeId: 'NODE-B200-112',
        gpuModel: 'B200',
        gpuCount: 32,
        startTime: new Date(Date.now() - 3600000 * 30).toISOString(),
        endTime: new Date(Date.now() - 3600000 * 6).toISOString(),
        workloadType: 'transformer_pretrain',
        workloadSignatureSha256: '0x8f4c2810a9384726192837461920384756192837461928374619283746192837',
        telemetryMerkleRoot: '0x7e1102938475619283746192837461928374619082736451928374619203847',
        dcgmSamplingCount: 1440,
        avgGpuUtilPct: 96.8,
        avgTensorUtilPct: 94.2,
        avgMemoryUtilPct: 91.5,
        totalEnergyKwh: 768.4,
        deliveredPerformancePct: 98.4,
        deliveredAvailabilityPct: 100.0,
        slaPassed: true,
        oracleSignature: 'SIG_0x9920194827364519283746192837461928374619082736451928374619203847',
        verifiedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
        onChainBlockNumber: 4891024
      }
    ];
  }

  seedGenesisBlocks() {
    this.blocks = [
      {
        blockNumber: 4891024,
        blockHash: '0x3f98a21094827364519283746192837461928374619082736451928374619203',
        previousHash: '0x892a019482736451928374619283746192837461908273645192837461920384',
        timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
        txCount: 3,
        transactions: [
          {
            txHash: '0x8837192038475619283746192837461928374619082736451928374619203847',
            type: 'SETTLEMENT_PAYOUT',
            contractId: 'CTR-STRIKE-78903',
            amountUsd: 52992.00,
            from: 'GPUX_ESCROW_SMART_CONTRACT',
            to: '0x77C...11aa (Crusoe Vault)',
            status: 'FINALIZED'
          },
          {
            txHash: '0x3b89019283746192837461920384756192837461928374619283746192837461',
            type: 'PROOF_VERIFIED',
            contractId: 'CTR-STRIKE-78903',
            proofHash: '0x8f4c2810a9384726192837461920384756192837461928374619283746192837',
            from: 'GPUX_DECENTRALIZED_ORACLE_CONSENSUS',
            to: 'GPUX_SETTLEMENT_CORE',
            status: 'FINALIZED'
          }
        ]
      },
      {
        blockNumber: 4891023,
        blockHash: '0x892a019482736451928374619283746192837461908273645192837461920384',
        previousHash: '0x12a9bc4908123746192837461920384756192837461928374619283746192837',
        timestamp: new Date(Date.now() - 3600000 * 6).toISOString(),
        txCount: 1,
        transactions: [
          {
            txHash: '0x4f89d3a1290b4e28741eafc83002341908ab9182371928374910283746192837',
            type: 'ESCROW_LOCK',
            contractId: 'CTR-STRIKE-78901',
            amountUsd: 31641.60,
            from: '0x71C...4a91 (Anthropic)',
            to: 'GPUX_ESCROW_SMART_CONTRACT',
            status: 'FINALIZED'
          }
        ]
      }
    ];
  }

  initSpotMarkets() {
    const basePrices: Record<GpuModelId, number> = {
      H100_SXM5: 41.85,
      H100_NVL: 44.50,
      H200_SXM5: 53.40,
      B100: 64.20,
      B200: 71.80,
      GB200_NVL72: 96.50,
      A100_SXM4_80GB: 23.90,
      L40S: 15.60,
      RTX_4090: 8.40,
      RTX_6000_ADA: 17.20
    };

    (Object.keys(GPU_CAPABILITY_CATALOG) as GpuModelId[]).forEach((model) => {
      const mid = basePrices[model] || 35.0;
      const bids: OrderBookEntry[] = [];
      const asks: OrderBookEntry[] = [];

      // Generate initial resting bids
      for (let i = 1; i <= 6; i++) {
        const p = Number((mid - (i * 0.45) - Math.random() * 0.2).toFixed(2));
        const qty = [8, 16, 32, 64, 128][Math.floor(Math.random() * 5)];
        bids.push({
          id: `BID-${model}-${i}`,
          side: 'BUY',
          gpuModel: model,
          quantityGpus: qty,
          normalizedCu: calculateNormalizedCu(model, qty),
          pricePerGpuHour: p,
          durationHours: [6, 12, 24, 48][Math.floor(Math.random() * 4)],
          minReliability: 0.99,
          creatorAddress: `0x${Math.random().toString(16).substring(2, 8)}...${Math.random().toString(16).substring(2, 6)}`,
          creatorName: ['Scale AI', 'Stability Research', 'Midjourney Training', 'Adept AI', 'Nexus Labs'][i % 5],
          timestamp: new Date(Date.now() - i * 180000).toISOString(),
          filledQuantity: 0
        });
      }

      // Generate initial resting asks
      for (let i = 1; i <= 6; i++) {
        const p = Number((mid + (i * 0.50) + Math.random() * 0.2).toFixed(2));
        const qty = [8, 16, 32, 64, 256][Math.floor(Math.random() * 5)];
        asks.push({
          id: `ASK-${model}-${i}`,
          side: 'SELL',
          gpuModel: model,
          quantityGpus: qty,
          normalizedCu: calculateNormalizedCu(model, qty),
          pricePerGpuHour: p,
          durationHours: [12, 24, 72, 168][Math.floor(Math.random() * 4)],
          minReliability: 0.995,
          creatorAddress: `0x${Math.random().toString(16).substring(2, 8)}...${Math.random().toString(16).substring(2, 6)}`,
          creatorName: ['CoreWeave NJ Vault', 'Lambda Texas Pool', 'Crusoe Hydro 01', 'Nebius Nordics', 'Equinix Metal'][i % 5],
          timestamp: new Date(Date.now() - i * 120000).toISOString(),
          filledQuantity: 0
        });
      }

      // Sort bids desc, asks asc
      bids.sort((a, b) => b.pricePerGpuHour - a.pricePerGpuHour);
      asks.sort((a, b) => a.pricePerGpuHour - b.pricePerGpuHour);

      // Generate depth points
      const depthChart: { price: number; cumulativeBids: number; cumulativeAsks: number }[] = [];
      let cumBid = 0;
      bids.forEach(b => {
        cumBid += b.quantityGpus;
        depthChart.push({ price: b.pricePerGpuHour, cumulativeBids: cumBid, cumulativeAsks: 0 });
      });
      let cumAsk = 0;
      asks.forEach(a => {
        cumAsk += a.quantityGpus;
        depthChart.push({ price: a.pricePerGpuHour, cumulativeBids: 0, cumulativeAsks: cumAsk });
      });
      depthChart.sort((a, b) => a.price - b.price);

      // Generate 24h price candle history
      const priceHistory = [];
      let currentP = mid * 0.94;
      for (let h = 24; h >= 0; h--) {
        const open = currentP;
        const delta = (Math.random() - 0.48) * (mid * 0.03);
        const close = Number(Math.max(1, open + delta).toFixed(2));
        const high = Number(Math.max(open, close) + Math.random() * (mid * 0.02)).toFixed(2);
        const low = Number(Math.min(open, close) - Math.random() * (mid * 0.02)).toFixed(2);
        const vol = Math.floor(256 + Math.random() * 1024);
        priceHistory.push({
          timestamp: new Date(Date.now() - h * 3600000).toISOString(),
          open,
          high: Number(high),
          low: Number(low),
          close,
          volume: vol
        });
        currentP = close;
      }

      this.spotMarketStates[model] = {
        gpuModel: model,
        lastPrice: mid,
        priceChange24hPct: Number(((mid - priceHistory[0].open) / priceHistory[0].open * 100).toFixed(2)),
        high24h: Number((mid * 1.05).toFixed(2)),
        low24h: Number((mid * 0.93).toFixed(2)),
        volume24hGpuHours: 24580,
        impliedVolatility24h: 21.4,
        bids,
        asks,
        depthChart,
        priceHistory
      };
    });
  }

  getLiveTelemetrySample(): LiveGpuTelemetry[] {
    const samples: LiveGpuTelemetry[] = [];
    const models: GpuModelId[] = ['H100_SXM5', 'H200_SXM5', 'B200', 'A100_SXM4_80GB', 'L40S'];

    models.forEach((m, idx) => {
      const cap = GPU_CAPABILITY_CATALOG[m];
      const baseUtil = 84 + Math.sin(Date.now() / 10000 + idx) * 10;
      const temp = Math.min(cap.thermalLimitC, 62 + (baseUtil / 100) * 18 + Math.random() * 2);
      const power = Number(((baseUtil / 100) * cap.powerTdpW * 0.92).toFixed(0));
      const powerKw = power / 1000;
      const energyRate = 0.075; // average $/kWh
      const hourlyEnergyCost = Number((powerKw * energyRate * 1.14).toFixed(4)); // with 1.14 PUE

      samples.push({
        nodeId: `NODE-${m}-01`,
        gpuIndex: idx,
        gpuModel: m,
        timestamp: new Date().toISOString(),
        gpuUtilPct: Number(Math.min(100, Math.max(10, baseUtil + (Math.random() * 4 - 2))).toFixed(1)),
        memoryUtilPct: Number((78 + Math.random() * 14).toFixed(1)),
        tensorCoreUtilPct: Number((baseUtil * 0.96 + Math.random() * 3).toFixed(1)),
        hbm3eBandwidthPct: Number((72 + Math.random() * 20).toFixed(1)),
        powerDrawWatts: Number(power),
        temperatureC: Number(temp.toFixed(1)),
        fanSpeedPct: Number((65 + (temp / cap.thermalLimitC) * 30).toFixed(0)),
        pcieRxMbS: Number((14000 + Math.random() * 8000).toFixed(0)),
        pcieTxMbS: Number((12000 + Math.random() * 6000).toFixed(0)),
        nvlinkThroughputGbs: Number((cap.nvlinkBandwidthGbs * 0.75 + Math.random() * 50).toFixed(0)),
        throttleReason: temp > 83 ? 'THERMAL' : 'NONE',
        energyCostCurrentHourUsd: hourlyEnergyCost
      });
    });

    return samples;
  }
}

export const db = new GpuxDatabase();
