import { MacroScenario, GpuModelId } from './types.js';
import { db } from './database.js';
import { pricingEngine } from './pricingEngine.js';

export const MACRO_SCENARIOS: Record<string, MacroScenario> = {
  BASE_MARKET: {
    id: 'SCENARIO-BASE',
    key: 'BASE_MARKET',
    title: 'Normal Equilibrium Market',
    description: 'Balanced AI compute supply and demand with standard volatility and regular grid tariffs.',
    active: true,
    spotMultiplier: 1.0,
    volatilityMultiplier: 1.0,
    demandMultiplier: 1.0,
    capacityMultiplier: 1.0,
    energyMultiplier: 1.0,
    narrative: 'Market is in steady state equilibrium. H100 clearing ~$41.80/hr, implied 30d vol at 21.4%.'
  },
  SCENARIO_A_OVERSUPPLY: {
    id: 'SCENARIO-A',
    key: 'SCENARIO_A_OVERSUPPLY',
    title: 'Scenario A: GPU Oversupply',
    description: 'Post-crypto/model stabilization release flood. Thousands of idle nodes seeking liquidation.',
    active: false,
    spotMultiplier: 0.62,
    volatilityMultiplier: 0.75,
    demandMultiplier: 0.70,
    capacityMultiplier: 1.80,
    energyMultiplier: 0.95,
    narrative: 'Providers slashing spot asks toward pure marginal energy costs ($18-$26/hr H100). Contango in forward curve.'
  },
  SCENARIO_B_SHORTAGE: {
    id: 'SCENARIO-B',
    key: 'SCENARIO_B_SHORTAGE',
    title: 'Scenario B: Critical GPU Shortage',
    description: 'Hyperscaler aggressive multi-year cluster buyouts leave open market capacity under 5%.',
    active: false,
    spotMultiplier: 1.75,
    volatilityMultiplier: 2.20,
    demandMultiplier: 1.60,
    capacityMultiplier: 0.40,
    energyMultiplier: 1.05,
    narrative: 'Immediate spot prices spike past $70/hr for H100. Strike contract premiums surged 300% on right-to-execute protection.'
  },
  SCENARIO_C_AI_EXPLOSION: {
    id: 'SCENARIO-C',
    key: 'SCENARIO_C_AI_EXPLOSION',
    title: 'Scenario C: Frontier AI Demand Explosion',
    description: 'Breakthrough in reasoning architectures sparks frantic training runs and inference demand wave.',
    active: false,
    spotMultiplier: 1.95,
    volatilityMultiplier: 2.50,
    demandMultiplier: 2.80,
    capacityMultiplier: 0.90,
    energyMultiplier: 1.10,
    narrative: 'Massive upward shift across all tenors. GB200 & H200 spot trading at historic highs; huge hedging volume in forward contracts.'
  },
  SCENARIO_D_ENERGY_SHOCK: {
    id: 'SCENARIO-D',
    key: 'SCENARIO_D_ENERGY_SHOCK',
    title: 'Scenario D: Electricity Grid Price Shock',
    description: 'Grid capacity constraints and natural gas spikes double power rates to $0.22/kWh.',
    active: false,
    spotMultiplier: 1.35,
    volatilityMultiplier: 1.60,
    demandMultiplier: 1.00,
    capacityMultiplier: 0.95,
    energyMultiplier: 2.60,
    narrative: 'PUE and power costs drive sharp bifurcation. Green flare/hydro data centers (Crusoe/Nebius) enjoy massive price advantages.'
  },
  SCENARIO_E_OUTAGE: {
    id: 'SCENARIO-E',
    key: 'SCENARIO_E_OUTAGE',
    title: 'Scenario E: Major Data Centre Outage',
    description: 'Catastrophic subsea fiber break and Frankfurt substation transformer fire cuts 30,000 GPUs offline.',
    active: false,
    spotMultiplier: 2.10,
    volatilityMultiplier: 3.10,
    demandMultiplier: 1.30,
    capacityMultiplier: 0.35,
    energyMultiplier: 1.15,
    narrative: 'Immediate failover trigger. Automatic SLA slash mechanisms activate on defaulted nodes; European spot compute spikes 110%.'
  },
  SCENARIO_F_BLACKWELL_LAUNCH: {
    id: 'SCENARIO-F',
    key: 'SCENARIO_F_BLACKWELL_LAUNCH',
    title: 'Scenario F: Blackwell B200 / GB200 Mass Deployment',
    description: 'Next-generation architecture arrives in volume, delivering 3.5x FP8 throughput at lower power per token.',
    active: false,
    spotMultiplier: 0.78,
    volatilityMultiplier: 1.45,
    demandMultiplier: 1.40,
    capacityMultiplier: 1.90,
    energyMultiplier: 0.85,
    narrative: 'B200 becomes the new anchor compute unit. H100 spot pricing depreciates into deep backwardation.'
  },
  SCENARIO_G_DEPRECIATION_SHOCK: {
    id: 'SCENARIO-G',
    key: 'SCENARIO_G_DEPRECIATION_SHOCK',
    title: 'Scenario G: Hardware Depreciation Write-down',
    description: 'Operators accelerate CapEx write-downs on older Ampere/Hopper nodes to clear balance sheets.',
    active: false,
    spotMultiplier: 0.70,
    volatilityMultiplier: 0.85,
    demandMultiplier: 0.90,
    capacityMultiplier: 1.20,
    energyMultiplier: 1.00,
    narrative: 'A100 and older Hopper units drop to rock-bottom spot rates ($12-$18/hr), creating ideal conditions for budget batch training.'
  },
  SCENARIO_H_NETWORK_CONGESTION: {
    id: 'SCENARIO-H',
    key: 'SCENARIO_H_NETWORK_CONGESTION',
    title: 'Scenario H: Transatlantic Fiber Congestion',
    description: 'Subsea cable degradation increases cross-region latency by 180ms and doubles egress tariffs.',
    active: false,
    spotMultiplier: 1.25,
    volatilityMultiplier: 1.70,
    demandMultiplier: 1.05,
    capacityMultiplier: 0.85,
    energyMultiplier: 1.00,
    narrative: 'Locality premium spikes: workloads strictly prioritize local data centre nodes over remote budget capacity.'
  },
  SCENARIO_I_REGIONAL_SHORTAGE: {
    id: 'SCENARIO-I',
    key: 'SCENARIO_I_REGIONAL_SHORTAGE',
    title: 'Scenario I: European Sovereignty Compute Mandate',
    description: 'EU AI Act strict data residency rules trigger sudden localized demand rush for EU-based nodes.',
    active: false,
    spotMultiplier: 1.55,
    volatilityMultiplier: 1.90,
    demandMultiplier: 1.50,
    capacityMultiplier: 0.60,
    energyMultiplier: 1.20,
    narrative: 'European GPU capacity (Nebius Finland, Equinix London) commands 45% premium over US Midwest clusters.'
  },
  SCENARIO_J_IDLE_CAPACITY: {
    id: 'SCENARIO-J',
    key: 'SCENARIO_J_IDLE_CAPACITY',
    title: 'Scenario J: Off-Peak Idle Capacity Surge',
    description: 'Overnight and weekend enterprise idle cycles dump millions of unreserved GPU-minutes on spot.',
    active: false,
    spotMultiplier: 0.55,
    volatilityMultiplier: 0.90,
    demandMultiplier: 0.60,
    capacityMultiplier: 2.10,
    energyMultiplier: 0.90,
    narrative: 'Spot buyers execute spot batch jobs at 45% off standard rates. Strike contracts reflect steep weekend discounts.'
  }
};

export class GpuxSimulationEngine {
  applyScenario(scenarioKey: string) {
    const scenario = MACRO_SCENARIOS[scenarioKey];
    if (!scenario) throw new Error(`Scenario ${scenarioKey} not found`);

    db.activeScenarioKey = scenarioKey;
    Object.values(MACRO_SCENARIOS).forEach(s => s.active = s.key === scenarioKey);

    // Recalculate spot prices and adjust orderbooks for all models
    (Object.keys(db.spotMarketStates) as GpuModelId[]).forEach(model => {
      const market = db.spotMarketStates[model];
      const baseCalc = pricingEngine.calculateSpotPrice(
        model,
        84 * scenario.demandMultiplier / scenario.capacityMultiplier,
        1.15,
        0.08 * scenario.energyMultiplier,
        scenario.demandMultiplier,
        scenario.spotMultiplier
      );

      const oldPrice = market.lastPrice;
      market.lastPrice = baseCalc.spotPrice;
      market.priceChange24hPct = Number((((baseCalc.spotPrice - oldPrice) / oldPrice) * 100).toFixed(2));
      market.impliedVolatility24h = Number((21.4 * scenario.volatilityMultiplier).toFixed(1));

      // Adjust bids and asks
      market.bids.forEach(b => {
        b.pricePerGpuHour = Number((b.pricePerGpuHour * scenario.spotMultiplier).toFixed(2));
      });
      market.asks.forEach(a => {
        a.pricePerGpuHour = Number((a.pricePerGpuHour * scenario.spotMultiplier).toFixed(2));
      });

      // Append historical candle
      market.priceHistory.push({
        timestamp: new Date().toISOString(),
        open: oldPrice,
        high: Math.max(oldPrice, baseCalc.spotPrice) * 1.02,
        low: Math.min(oldPrice, baseCalc.spotPrice) * 0.98,
        close: baseCalc.spotPrice,
        volume: Math.floor(25000 * scenario.demandMultiplier)
      });
    });

    return scenario;
  }

  stepTime(timeUnit: '1D' | '1W' | '1M' | '1Y') {
    const hours = { '1D': 24, '1W': 168, '1M': 720, '1Y': 8760 }[timeUnit];

    // Simulate forward step with slight drift and noise
    (Object.keys(db.spotMarketStates) as GpuModelId[]).forEach(model => {
      const market = db.spotMarketStates[model];
      const drift = (Math.random() - 0.48) * (market.impliedVolatility24h / 100) * Math.sqrt(hours / 8760);
      const newPrice = Number(Math.max(5.0, market.lastPrice * (1 + drift)).toFixed(2));

      market.priceHistory.push({
        timestamp: new Date(Date.now() + hours * 3600000).toISOString(),
        open: market.lastPrice,
        high: Number((Math.max(market.lastPrice, newPrice) * 1.03).toFixed(2)),
        low: Number((Math.min(market.lastPrice, newPrice) * 0.97).toFixed(2)),
        close: newPrice,
        volume: Math.floor(30000 + Math.random() * 20000)
      });
      market.lastPrice = newPrice;
    });

    return { steppedHours: hours, timestamp: new Date().toISOString() };
  }
}

export const simulationEngine = new GpuxSimulationEngine();
