import { GpuCapability, GpuModelId, WorkloadType } from './types.js';

export const GPU_CAPABILITY_CATALOG: Record<GpuModelId, GpuCapability> = {
  H100_SXM5: {
    id: 'H100_SXM5',
    manufacturer: 'NVIDIA',
    model: 'H100 SXM5 80GB',
    architecture: 'Hopper (GH100)',
    generation: 'H-Series 2023',
    memoryGb: 80,
    memoryType: 'HBM3',
    memoryBandwidthGbs: 3350,
    computeCapability: '9.0',
    tensorCoreGen: 4,
    tensorCoreCount: 456,
    fp32Tflops: 67.0,
    fp16Tflops: 989.0,
    bf16Tflops: 989.0,
    fp8Tflops: 1979.0,
    int8Tops: 1979.0,
    nvlinkBandwidthGbs: 900,
    powerTdpW: 700,
    thermalLimitC: 84,
    baseGpuxCu: 1.00, // Standard baseline unit
    workloadMultipliers: {
      transformer_pretrain: 1.00,
      transformer_inference: 1.00,
      matrix_multiplication: 1.00,
      image_diffusion: 1.00,
      scientific_hpc: 0.95,
      simulation_rendering: 0.90,
      finetuning_lora: 1.00
    }
  },
  H100_NVL: {
    id: 'H100_NVL',
    manufacturer: 'NVIDIA',
    model: 'H100 NVL 94GB Dual',
    architecture: 'Hopper (GH100)',
    generation: 'H-Series 2023',
    memoryGb: 94,
    memoryType: 'HBM3',
    memoryBandwidthGbs: 3900,
    computeCapability: '9.0',
    tensorCoreGen: 4,
    tensorCoreCount: 480,
    fp32Tflops: 68.0,
    fp16Tflops: 1020.0,
    bf16Tflops: 1020.0,
    fp8Tflops: 2040.0,
    int8Tops: 2040.0,
    nvlinkBandwidthGbs: 600,
    powerTdpW: 800,
    thermalLimitC: 82,
    baseGpuxCu: 1.08,
    workloadMultipliers: {
      transformer_pretrain: 1.05,
      transformer_inference: 1.25, // extra memory helps large KV cache
      matrix_multiplication: 1.02,
      image_diffusion: 1.10,
      scientific_hpc: 1.00,
      simulation_rendering: 0.95,
      finetuning_lora: 1.12
    }
  },
  H200_SXM5: {
    id: 'H200_SXM5',
    manufacturer: 'NVIDIA',
    model: 'H200 SXM5 141GB',
    architecture: 'Hopper (GH100 Extended)',
    generation: 'H-Series 2024',
    memoryGb: 141,
    memoryType: 'HBM3e',
    memoryBandwidthGbs: 4800,
    computeCapability: '9.0',
    tensorCoreGen: 4,
    tensorCoreCount: 456,
    fp32Tflops: 67.0,
    fp16Tflops: 989.0,
    bf16Tflops: 989.0,
    fp8Tflops: 1979.0,
    int8Tops: 1979.0,
    nvlinkBandwidthGbs: 900,
    powerTdpW: 700,
    thermalLimitC: 84,
    baseGpuxCu: 1.38,
    workloadMultipliers: {
      transformer_pretrain: 1.28,
      transformer_inference: 1.85, // 141GB HBM3e massive KV throughput
      matrix_multiplication: 1.15,
      image_diffusion: 1.40,
      scientific_hpc: 1.30,
      simulation_rendering: 1.10,
      finetuning_lora: 1.50
    }
  },
  B100: {
    id: 'B100',
    manufacturer: 'NVIDIA',
    model: 'B100 192GB',
    architecture: 'Blackwell (GB100)',
    generation: 'B-Series 2024-2025',
    memoryGb: 192,
    memoryType: 'HBM3e',
    memoryBandwidthGbs: 8000,
    computeCapability: '10.0',
    tensorCoreGen: 5,
    tensorCoreCount: 768,
    fp32Tflops: 120.0,
    fp16Tflops: 1800.0,
    bf16Tflops: 1800.0,
    fp8Tflops: 3500.0,
    int8Tops: 3500.0,
    nvlinkBandwidthGbs: 1800,
    powerTdpW: 700,
    thermalLimitC: 80,
    baseGpuxCu: 2.10,
    workloadMultipliers: {
      transformer_pretrain: 2.15,
      transformer_inference: 2.40,
      matrix_multiplication: 2.10,
      image_diffusion: 2.05,
      scientific_hpc: 1.90,
      simulation_rendering: 1.80,
      finetuning_lora: 2.20
    }
  },
  B200: {
    id: 'B200',
    manufacturer: 'NVIDIA',
    model: 'B200 192GB 1000W',
    architecture: 'Blackwell (GB200 Dual-Die)',
    generation: 'B-Series 2025',
    memoryGb: 192,
    memoryType: 'HBM3e',
    memoryBandwidthGbs: 8000,
    computeCapability: '10.0',
    tensorCoreGen: 5,
    tensorCoreCount: 960,
    fp32Tflops: 150.0,
    fp16Tflops: 2250.0,
    bf16Tflops: 2250.0,
    fp8Tflops: 4500.0,
    int8Tops: 4500.0,
    nvlinkBandwidthGbs: 1800,
    powerTdpW: 1000,
    thermalLimitC: 85,
    baseGpuxCu: 2.85,
    workloadMultipliers: {
      transformer_pretrain: 2.95,
      transformer_inference: 3.40,
      matrix_multiplication: 2.80,
      image_diffusion: 2.70,
      scientific_hpc: 2.50,
      simulation_rendering: 2.40,
      finetuning_lora: 3.10
    }
  },
  GB200_NVL72: {
    id: 'GB200_NVL72',
    manufacturer: 'NVIDIA',
    model: 'GB200 NVL72 Rack-Scale (Per GPU Slice)',
    architecture: 'Blackwell + Grace CPU Coherent',
    generation: 'B-Series 2025',
    memoryGb: 384, // 192GB HBM3e + 192GB LPDDR5X Coherent
    memoryType: 'HBM3e / NVLink-C2C',
    memoryBandwidthGbs: 8000,
    computeCapability: '10.0',
    tensorCoreGen: 5,
    tensorCoreCount: 960,
    fp32Tflops: 180.0,
    fp16Tflops: 2500.0,
    bf16Tflops: 2500.0,
    fp8Tflops: 5000.0,
    int8Tops: 5000.0,
    nvlinkBandwidthGbs: 1800,
    powerTdpW: 1200,
    thermalLimitC: 78,
    baseGpuxCu: 3.75,
    workloadMultipliers: {
      transformer_pretrain: 4.10,
      transformer_inference: 4.80,
      matrix_multiplication: 3.60,
      image_diffusion: 3.40,
      scientific_hpc: 3.90,
      simulation_rendering: 3.10,
      finetuning_lora: 4.30
    }
  },
  A100_SXM4_80GB: {
    id: 'A100_SXM4_80GB',
    manufacturer: 'NVIDIA',
    model: 'A100 SXM4 80GB',
    architecture: 'Ampere (GA100)',
    generation: 'A-Series 2021',
    memoryGb: 80,
    memoryType: 'HBM2e',
    memoryBandwidthGbs: 2039,
    computeCapability: '8.0',
    tensorCoreGen: 3,
    tensorCoreCount: 432,
    fp32Tflops: 19.5,
    fp16Tflops: 312.0,
    bf16Tflops: 312.0,
    fp8Tflops: 312.0,
    int8Tops: 624.0,
    nvlinkBandwidthGbs: 600,
    powerTdpW: 400,
    thermalLimitC: 80,
    baseGpuxCu: 0.58,
    workloadMultipliers: {
      transformer_pretrain: 0.58,
      transformer_inference: 0.62,
      matrix_multiplication: 0.60,
      image_diffusion: 0.64,
      scientific_hpc: 0.65,
      simulation_rendering: 0.55,
      finetuning_lora: 0.60
    }
  },
  L40S: {
    id: 'L40S',
    manufacturer: 'NVIDIA',
    model: 'L40S 48GB PCIe',
    architecture: 'Ada Lovelace (AD102)',
    generation: 'L-Series 2023',
    memoryGb: 48,
    memoryType: 'GDDR6 ECC',
    memoryBandwidthGbs: 864,
    computeCapability: '8.9',
    tensorCoreGen: 4,
    tensorCoreCount: 568,
    fp32Tflops: 91.6,
    fp16Tflops: 366.0,
    bf16Tflops: 366.0,
    fp8Tflops: 733.0,
    int8Tops: 733.0,
    nvlinkBandwidthGbs: 0,
    powerTdpW: 350,
    thermalLimitC: 83,
    baseGpuxCu: 0.44,
    workloadMultipliers: {
      transformer_pretrain: 0.38,
      transformer_inference: 0.65,
      matrix_multiplication: 0.45,
      image_diffusion: 0.72, // excellent for Stable Diffusion / video
      scientific_hpc: 0.40,
      simulation_rendering: 0.88, // RT Cores shine here
      finetuning_lora: 0.50
    }
  },
  RTX_4090: {
    id: 'RTX_4090',
    manufacturer: 'NVIDIA',
    model: 'GeForce RTX 4090 24GB',
    architecture: 'Ada Lovelace (AD102-300)',
    generation: 'Consumer Ada 2022',
    memoryGb: 24,
    memoryType: 'GDDR6X',
    memoryBandwidthGbs: 1008,
    computeCapability: '8.9',
    tensorCoreGen: 4,
    tensorCoreCount: 512,
    fp32Tflops: 82.6,
    fp16Tflops: 330.0,
    bf16Tflops: 330.0,
    fp8Tflops: 660.0,
    int8Tops: 660.0,
    nvlinkBandwidthGbs: 0,
    powerTdpW: 450,
    thermalLimitC: 84,
    baseGpuxCu: 0.28,
    workloadMultipliers: {
      transformer_pretrain: 0.18,
      transformer_inference: 0.35,
      matrix_multiplication: 0.28,
      image_diffusion: 0.48,
      scientific_hpc: 0.22,
      simulation_rendering: 0.60,
      finetuning_lora: 0.32
    }
  },
  RTX_6000_ADA: {
    id: 'RTX_6000_ADA',
    manufacturer: 'NVIDIA',
    model: 'RTX 6000 Ada Generation 48GB',
    architecture: 'Ada Lovelace (AD102)',
    generation: 'Workstation Ada 2023',
    memoryGb: 48,
    memoryType: 'GDDR6 ECC',
    memoryBandwidthGbs: 960,
    computeCapability: '8.9',
    tensorCoreGen: 4,
    tensorCoreCount: 568,
    fp32Tflops: 91.1,
    fp16Tflops: 364.0,
    bf16Tflops: 364.0,
    fp8Tflops: 728.0,
    int8Tops: 728.0,
    nvlinkBandwidthGbs: 0,
    powerTdpW: 300,
    thermalLimitC: 82,
    baseGpuxCu: 0.46,
    workloadMultipliers: {
      transformer_pretrain: 0.39,
      transformer_inference: 0.68,
      matrix_multiplication: 0.46,
      image_diffusion: 0.74,
      scientific_hpc: 0.42,
      simulation_rendering: 0.92,
      finetuning_lora: 0.52
    }
  }
};

/**
 * Calculates benchmark-normalised compute units for a given hardware and workload configuration.
 */
export function calculateNormalizedCu(
  gpuModel: GpuModelId,
  gpuCount: number,
  workload: WorkloadType = 'transformer_inference'
): number {
  const cap = GPU_CAPABILITY_CATALOG[gpuModel];
  if (!cap) return gpuCount * 1.0;
  const multiplier = cap.workloadMultipliers[workload] ?? cap.baseGpuxCu;
  return Number((gpuCount * multiplier).toFixed(2));
}

/**
 * Derives the required GPU count to satisfy a requested GPUX-CU normalized capacity.
 */
export function solveRequiredGpus(
  gpuModel: GpuModelId,
  requiredCu: number,
  workload: WorkloadType = 'transformer_inference'
): number {
  const cap = GPU_CAPABILITY_CATALOG[gpuModel];
  if (!cap) return Math.ceil(requiredCu);
  const multiplier = cap.workloadMultipliers[workload] ?? cap.baseGpuxCu;
  return Math.ceil(requiredCu / multiplier);
}
