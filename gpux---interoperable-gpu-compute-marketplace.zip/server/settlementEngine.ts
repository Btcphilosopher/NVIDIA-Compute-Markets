import crypto from 'crypto';
import { ProofOfCompute, StrikeContract, WorkloadType } from './types.js';
import { db, BlockchainBlock } from './database.js';

export class GpuxSettlementEngine {
  /**
   * Generates a cryptographic Proof-of-Compute for a completed workload.
   */
  generateProofOfCompute(params: {
    contractId: string;
    jobId: string;
    providerId: string;
    nodeId: string;
    workloadType: WorkloadType;
    actualPerformancePct: number;
    actualAvailabilityPct: number;
    avgGpuUtilPct: number;
    avgTensorUtilPct: number;
    avgMemoryUtilPct: number;
    totalEnergyKwh: number;
  }): ProofOfCompute {
    const contract = db.contracts.find(c => c.id === params.contractId);
    if (!contract) {
      throw new Error(`Contract ${params.contractId} not found`);
    }

    // Generate SHA-256 workload fingerprint
    const rawTelemetryDigest = `${params.contractId}:${params.jobId}:${params.providerId}:${params.nodeId}:${params.actualPerformancePct}:${Date.now()}`;
    const workloadSignatureSha256 = '0x' + crypto.createHash('sha256').update(rawTelemetryDigest).digest('hex');
    const telemetryMerkleRoot = '0x' + crypto.createHash('sha256').update(workloadSignatureSha256 + ':DCGM_MERKLE').digest('hex');

    const slaPassed = params.actualPerformancePct >= contract.performanceFloorPct && 
                      params.actualAvailabilityPct >= contract.availabilityFloorPct;

    const oracleSignature = '0x_ORACLE_SIG_' + crypto.createHash('sha256').update(telemetryMerkleRoot + ':GPUX_ORACLE_CONSENSUS').digest('hex').substring(0, 40);

    const blockNum = (db.blocks[0]?.blockNumber ?? 4891024) + 1;

    const proof: ProofOfCompute = {
      id: `PROOF-${Date.now()}`,
      contractId: params.contractId,
      jobId: params.jobId,
      providerId: params.providerId,
      nodeId: params.nodeId,
      gpuModel: contract.gpuModel,
      gpuCount: contract.gpuQuantity,
      startTime: contract.executionStartTime,
      endTime: contract.executionEndTime,
      workloadType: params.workloadType,
      workloadSignatureSha256,
      telemetryMerkleRoot,
      dcgmSamplingCount: Math.floor(contract.durationHours * 60),
      avgGpuUtilPct: params.avgGpuUtilPct,
      avgTensorUtilPct: params.avgTensorUtilPct,
      avgMemoryUtilPct: params.avgMemoryUtilPct,
      totalEnergyKwh: params.totalEnergyKwh,
      deliveredPerformancePct: params.actualPerformancePct,
      deliveredAvailabilityPct: params.actualAvailabilityPct,
      slaPassed,
      oracleSignature,
      verifiedAt: new Date().toISOString(),
      onChainBlockNumber: blockNum
    };

    db.proofs.unshift(proof);
    return proof;
  }

  /**
   * Settles a contract, verifies Proof-of-Compute, calculates SLA penalties if any, and mines an on-chain block.
   */
  settleContract(contractId: string, proofId: string) {
    const contract = db.contracts.find(c => c.id === contractId);
    if (!contract) throw new Error(`Contract ${contractId} not found`);

    const proof = db.proofs.find(p => p.id === proofId);
    if (!proof) throw new Error(`Proof ${proofId} not found`);

    const escrow = contract.escrowLockedUsd || contract.notionalValueUsd;
    let penaltySlashed = 0;
    let finalPayout = escrow;

    // If SLA failed, apply penalty proportional to shortfall
    if (!proof.slaPassed) {
      const perfDeficit = Math.max(0, contract.performanceFloorPct - proof.deliveredPerformancePct);
      const availDeficit = Math.max(0, contract.availabilityFloorPct - proof.deliveredAvailabilityPct);
      const penaltyPct = Math.min(1.0, (perfDeficit * 2.0 + availDeficit * 5.0) / 100);
      penaltySlashed = Number((escrow * penaltyPct).toFixed(2));
      finalPayout = Number((escrow - penaltySlashed).toFixed(2));
      contract.status = 'SLA_PENALIZED';
    } else {
      contract.status = 'SETTLED';
    }

    const txHash = '0x' + crypto.createHash('sha256').update(`${contractId}:SETTLE:${Date.now()}`).digest('hex');
    const blockNum = (db.blocks[0]?.blockNumber ?? 4891024) + 1;
    const prevBlock = db.blocks[0]?.blockHash ?? '0x0000000000000000000000000000000000000000';
    const blockHash = '0x' + crypto.createHash('sha256').update(`${prevBlock}:${blockNum}:${Date.now()}`).digest('hex');

    contract.txHashSettlement = txHash;
    contract.proofHash = proof.workloadSignatureSha256;
    contract.actualDeliveredPerformance = proof.deliveredPerformancePct;
    contract.actualAvailability = proof.deliveredAvailabilityPct;
    contract.settlementAmountUsd = finalPayout;
    contract.penaltySlashedUsd = penaltySlashed;

    // Append to Blockchain Ledger
    const newBlock: BlockchainBlock = {
      blockNumber: blockNum,
      blockHash,
      previousHash: prevBlock,
      timestamp: new Date().toISOString(),
      txCount: 2,
      transactions: [
        {
          txHash,
          type: penaltySlashed > 0 ? 'SLA_SLASH' : 'SETTLEMENT_PAYOUT',
          contractId,
          amountUsd: finalPayout,
          proofHash: proof.workloadSignatureSha256,
          from: 'GPUX_ESCROW_SMART_CONTRACT',
          to: `${contract.sellerName || 'Provider Vault'} (Payout: $${finalPayout}, Refund: $${penaltySlashed})`,
          status: 'FINALIZED'
        },
        {
          txHash: '0x' + crypto.createHash('sha256').update(`${proof.id}:ORACLE_CONFIRM`).digest('hex'),
          type: 'PROOF_VERIFIED',
          contractId,
          proofHash: proof.telemetryMerkleRoot,
          from: 'GPUX_DECENTRALIZED_ORACLE_CONSENSUS',
          to: 'GPUX_SETTLEMENT_CORE',
          status: 'FINALIZED'
        }
      ]
    };

    db.blocks.unshift(newBlock);

    return {
      contract,
      proof,
      block: newBlock,
      finalPayout,
      penaltySlashed
    };
  }
}

export const settlementEngine = new GpuxSettlementEngine();
