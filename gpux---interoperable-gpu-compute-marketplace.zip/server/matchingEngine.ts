import { GpuModelId, OrderBookEntry } from './types.js';
import { db } from './database.js';
import { calculateNormalizedCu } from './gpuModels.js';

export interface MatchResult {
  tradeExecuted: boolean;
  trades: {
    id: string;
    gpuModel: GpuModelId;
    quantity: number;
    price: number;
    timestamp: string;
    buyer: string;
    seller: string;
  }[];
  restingOrder?: OrderBookEntry;
}

export class GpuxMatchingEngine {
  /**
   * Places a limit or market order and checks for matches in the order book.
   */
  placeOrder(order: {
    side: 'BUY' | 'SELL';
    gpuModel: GpuModelId;
    quantityGpus: number;
    pricePerGpuHour: number;
    durationHours: number;
    minReliability?: number;
    creatorAddress: string;
    creatorName: string;
  }): MatchResult {
    const market = db.spotMarketStates[order.gpuModel];
    if (!market) {
      throw new Error(`Market for ${order.gpuModel} not found`);
    }

    const executedTrades: MatchResult['trades'] = [];
    let remainingQty = order.quantityGpus;

    if (order.side === 'BUY') {
      // Match against asks (sorted lowest price first)
      for (const ask of market.asks) {
        if (remainingQty <= 0) break;
        if (ask.pricePerGpuHour <= order.pricePerGpuHour) {
          const matchQty = Math.min(remainingQty, ask.quantityGpus - ask.filledQuantity);
          if (matchQty > 0) {
            ask.filledQuantity += matchQty;
            remainingQty -= matchQty;

            const trade = {
              id: `TRD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              gpuModel: order.gpuModel,
              quantity: matchQty,
              price: ask.pricePerGpuHour,
              timestamp: new Date().toISOString(),
              buyer: order.creatorName,
              seller: ask.creatorName
            };
            executedTrades.push(trade);
            db.trades.unshift(trade);
            market.lastPrice = ask.pricePerGpuHour;
          }
        }
      }
      // Remove fully filled asks
      market.asks = market.asks.filter(a => a.filledQuantity < a.quantityGpus);
    } else {
      // Match against bids (sorted highest price first)
      for (const bid of market.bids) {
        if (remainingQty <= 0) break;
        if (bid.pricePerGpuHour >= order.pricePerGpuHour) {
          const matchQty = Math.min(remainingQty, bid.quantityGpus - bid.filledQuantity);
          if (matchQty > 0) {
            bid.filledQuantity += matchQty;
            remainingQty -= matchQty;

            const trade = {
              id: `TRD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              gpuModel: order.gpuModel,
              quantity: matchQty,
              price: bid.pricePerGpuHour,
              timestamp: new Date().toISOString(),
              buyer: bid.creatorName,
              seller: order.creatorName
            };
            executedTrades.push(trade);
            db.trades.unshift(trade);
            market.lastPrice = bid.pricePerGpuHour;
          }
        }
      }
      // Remove fully filled bids
      market.bids = market.bids.filter(b => b.filledQuantity < b.quantityGpus);
    }

    let restingOrder: OrderBookEntry | undefined;
    if (remainingQty > 0) {
      restingOrder = {
        id: `${order.side === 'BUY' ? 'BID' : 'ASK'}-${order.gpuModel}-${Date.now()}`,
        side: order.side,
        gpuModel: order.gpuModel,
        quantityGpus: remainingQty,
        normalizedCu: calculateNormalizedCu(order.gpuModel, remainingQty),
        pricePerGpuHour: order.pricePerGpuHour,
        durationHours: order.durationHours,
        minReliability: order.minReliability ?? 0.99,
        creatorAddress: order.creatorAddress,
        creatorName: order.creatorName,
        timestamp: new Date().toISOString(),
        filledQuantity: 0
      };

      if (order.side === 'BUY') {
        market.bids.push(restingOrder);
        market.bids.sort((a, b) => b.pricePerGpuHour - a.pricePerGpuHour);
      } else {
        market.asks.push(restingOrder);
        market.asks.sort((a, b) => a.pricePerGpuHour - b.pricePerGpuHour);
      }
    }

    // Recompute depth chart
    const depthChart: { price: number; cumulativeBids: number; cumulativeAsks: number }[] = [];
    let cumBid = 0;
    market.bids.forEach(b => {
      cumBid += (b.quantityGpus - b.filledQuantity);
      depthChart.push({ price: b.pricePerGpuHour, cumulativeBids: cumBid, cumulativeAsks: 0 });
    });
    let cumAsk = 0;
    market.asks.forEach(a => {
      cumAsk += (a.quantityGpus - a.filledQuantity);
      depthChart.push({ price: a.pricePerGpuHour, cumulativeBids: 0, cumulativeAsks: cumAsk });
    });
    depthChart.sort((a, b) => a.price - b.price);
    market.depthChart = depthChart;

    return {
      tradeExecuted: executedTrades.length > 0,
      trades: executedTrades,
      restingOrder
    };
  }
}

export const matchingEngine = new GpuxMatchingEngine();
