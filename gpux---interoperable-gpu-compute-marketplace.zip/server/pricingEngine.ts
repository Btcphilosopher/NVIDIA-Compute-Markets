import { 
  ForwardCurvePoint, 
  GpuModelId, 
  MonteCarloPath, 
  MonteCarloSummary 
} from './types.js';
import { GPU_CAPABILITY_CATALOG } from './gpuModels.js';
import { db } from './database.js';

// Standard normal cumulative distribution function approximation (Abramowitz & Stegun)
function normalCdf(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x) / Math.sqrt(2.0);

  const t = 1.0 / (1.0 + p * absX);
  const erf = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);

  return 0.5 * (1.0 + sign * erf);
}

function normalPdf(x: number): number {
  return (1.0 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * x * x);
}

export class GpuxPricingEngine {
  /**
   * Calculates the theoretical spot price based on physical cost of capacity and market supply/demand.
   */
  calculateSpotPrice(
    gpuModel: GpuModelId,
    utilizationPct: number = 84,
    pue: number = 1.15,
    electricityRateKwh: number = 0.08,
    demandMultiplier: number = 1.0,
    activeScenarioMultiplier: number = 1.0
  ): { spotPrice: number; breakdown: Record<string, number> } {
    const cap = GPU_CAPABILITY_CATALOG[gpuModel] || GPU_CAPABILITY_CATALOG.H100_SXM5;

    // Approximate CapEx baseline for 3-year depreciation (8760 * 3 = 26,280 hours)
    const capexEstimates: Record<GpuModelId, number> = {
      H100_SXM5: 32000,
      H100_NVL: 34000,
      H200_SXM5: 42000,
      B100: 50000,
      B200: 58000,
      GB200_NVL72: 75000,
      A100_SXM4_80GB: 15000,
      L40S: 9000,
      RTX_4090: 2200,
      RTX_6000_ADA: 7500
    };

    const hardwareCapEx = capexEstimates[gpuModel] || 30000;
    const hourlyCapExDepr = hardwareCapEx / 26280; // $/hr amortization
    const chassisNetworkOverhead = hourlyCapExDepr * 0.35; // server chassis, InfiniBand, switches

    // Energy calculation: Power TDP (W) / 1000 * PUE * Electricity $/kWh
    const powerKw = cap.powerTdpW / 1000;
    const energyCostHourly = powerKw * pue * electricityRateKwh;

    // Facility & maintenance OpEx
    const facilityOpEx = 0.25;

    // Base cost of capacity per GPU hour
    const baseCostOfCapacity = hourlyCapExDepr + chassisNetworkOverhead + energyCostHourly + facilityOpEx;

    // Scarcity / utilization pricing curve
    // When utilization > 80%, price increases sharply (exponential scarcity rent)
    // When utilization < 50%, price discounts toward cost of capacity
    let scarcityMultiplier = 1.0;
    if (utilizationPct > 80) {
      scarcityMultiplier = 1.0 + Math.pow((utilizationPct - 80) / 20, 2) * 1.8;
    } else if (utilizationPct < 60) {
      scarcityMultiplier = Math.max(0.65, 1.0 - (60 - utilizationPct) * 0.015);
    }

    // Standard operator profit margin
    const targetMargin = 0.40;

    const theoreticalSpot = (baseCostOfCapacity * (1 + targetMargin) * scarcityMultiplier * demandMultiplier * activeScenarioMultiplier);
    const finalSpot = Number(Math.max(baseCostOfCapacity * 1.05, theoreticalSpot).toFixed(2));

    return {
      spotPrice: finalSpot,
      breakdown: {
        hourlyCapExDepr: Number(hourlyCapExDepr.toFixed(2)),
        chassisNetworkOverhead: Number(chassisNetworkOverhead.toFixed(2)),
        energyCostHourly: Number(energyCostHourly.toFixed(3)),
        facilityOpEx: Number(facilityOpEx.toFixed(2)),
        baseCostOfCapacity: Number(baseCostOfCapacity.toFixed(2)),
        scarcityMultiplier: Number(scarcityMultiplier.toFixed(2)),
        marginPct: Number((targetMargin * 100).toFixed(0))
      }
    };
  }

  /**
   * Generates the Forward Curve across multiple tenors for a given GPU class.
   */
  generateForwardCurve(gpuModel: GpuModelId): ForwardCurvePoint[] {
    const market = db.spotMarketStates[gpuModel];
    const spot = market ? market.lastPrice : 42.0;

    const tenors: { tenor: string; days: number; demandGrowth: number; supplyGrowth: number }[] = [
      { tenor: 'SPOT', days: 0, demandGrowth: 0, supplyGrowth: 0 },
      { tenor: '1D', days: 1, demandGrowth: 0.002, supplyGrowth: 0.001 },
      { tenor: '7D', days: 7, demandGrowth: 0.015, supplyGrowth: 0.008 },
      { tenor: '14D', days: 14, demandGrowth: 0.032, supplyGrowth: 0.018 },
      { tenor: '30D', days: 30, demandGrowth: 0.075, supplyGrowth: 0.045 },
      { tenor: '60D', days: 60, demandGrowth: 0.145, supplyGrowth: 0.095 },
      { tenor: '90D', days: 90, demandGrowth: 0.220, supplyGrowth: 0.160 },
      { tenor: '180D', days: 180, demandGrowth: 0.380, supplyGrowth: 0.320 },
      { tenor: '360D', days: 360, demandGrowth: 0.650, supplyGrowth: 0.600 }
    ];

    const r = 0.045; // 4.5% annual risk-free rate
    const baseVol = market ? market.impliedVolatility24h / 100 : 0.22;
    const baseCost = this.calculateSpotPrice(gpuModel).breakdown.baseCostOfCapacity;

    return tenors.map((t) => {
      if (t.days === 0) {
        return {
          tenor: t.tenor,
          days: t.days,
          forwardSpotPrice: spot,
          impliedVolatility: Number((baseVol * 100).toFixed(1)),
          costOfCapacityFloor: baseCost,
          expectedDemandGrowthPct: 0,
          riskFreeRate: r
        };
      }

      const timeYears = t.days / 365.0;
      // Net drift rate: risk free rate + net AI demand excess over hardware supply expansion
      const netDrift = r + (t.demandGrowth - t.supplyGrowth) * (1 / timeYears);
      const fwd = spot * Math.exp(netDrift * timeYears);

      // Volatility term structure (mean-reverting term structure)
      const tenorVol = baseVol * Math.sqrt(1 + (t.days / 180) * 0.35);

      return {
        tenor: t.tenor,
        days: t.days,
        forwardSpotPrice: Number(Math.max(baseCost * 1.1, fwd).toFixed(2)),
        impliedVolatility: Number((tenorVol * 100).toFixed(1)),
        costOfCapacityFloor: Number(baseCost.toFixed(2)),
        expectedDemandGrowthPct: Number((t.demandGrowth * 100).toFixed(1)),
        riskFreeRate: r
      };
    });
  }

  /**
   * Strike Pricing Engine using Black-76 formulation for compute forward rights.
   */
  calculateStrikePricing(
    gpuModel: GpuModelId,
    daysToExecution: number,
    strikePrice: number,
    durationHours: number,
    gpuQuantity: number
  ): {
    forwardPrice: number;
    strikePrice: number;
    unitPremiumUsd: number;
    totalPremiumUsd: number;
    notionalValueUsd: number;
    moneyness: number;
    greeks: { delta: number; gamma: number; vega: number; theta: number };
  } {
    const market = db.spotMarketStates[gpuModel];
    const spot = market ? market.lastPrice : 42.0;
    const fwdCurve = this.generateForwardCurve(gpuModel);
    
    // Interpolate forward price
    const timeYears = Math.max(0.0027, daysToExecution / 365.0); // min 1 day
    const closestPoint = fwdCurve.find(p => p.days >= daysToExecution) || fwdCurve[fwdCurve.length - 1];
    const F = closestPoint.forwardSpotPrice;
    const sigma = closestPoint.impliedVolatility / 100;
    const r = 0.045;
    const K = strikePrice;

    // Black-76 formulas
    const d1 = (Math.log(F / K) + 0.5 * sigma * sigma * timeYears) / (sigma * Math.sqrt(timeYears));
    const d2 = d1 - sigma * Math.sqrt(timeYears);

    const df = Math.exp(-r * timeYears);
    const callValue = df * (F * normalCdf(d1) - K * normalCdf(d2));

    // Greeks
    const delta = df * normalCdf(d1);
    const gamma = (df * normalPdf(d1)) / (F * sigma * Math.sqrt(timeYears));
    const vega = F * df * normalPdf(d1) * Math.sqrt(timeYears) * 0.01; // for 1% vol change
    const theta = -(F * df * normalPdf(d1) * sigma) / (2 * Math.sqrt(timeYears)) / 365.0;

    const unitPremium = Number(Math.max(0.25, callValue).toFixed(2));
    const totalGpuHours = gpuQuantity * durationHours;
    const totalPremium = Number((unitPremium * totalGpuHours).toFixed(2));
    const notionalValue = Number((K * totalGpuHours).toFixed(2));

    return {
      forwardPrice: F,
      strikePrice: K,
      unitPremiumUsd: unitPremium,
      totalPremiumUsd: totalPremium,
      notionalValueUsd: notionalValue,
      moneyness: Number((F / K).toFixed(3)),
      greeks: {
        delta: Number(delta.toFixed(3)),
        gamma: Number(gamma.toFixed(4)),
        vega: Number(vega.toFixed(3)),
        theta: Number(theta.toFixed(3))
      }
    };
  }

  /**
   * Monte Carlo Simulation Engine: Simulates thousands of price/shortage paths.
   */
  runMonteCarloSimulation(
    gpuModel: GpuModelId,
    daysToExecution: number = 30,
    simulationsCount: number = 1000,
    strikeTarget?: number
  ): MonteCarloSummary {
    const market = db.spotMarketStates[gpuModel];
    const spot = market ? market.lastPrice : 42.0;
    const baseCost = this.calculateSpotPrice(gpuModel).breakdown.baseCostOfCapacity;
    const sigma = (market ? market.impliedVolatility24h : 22.0) / 100;
    const dt = 1.0 / 365.0; // daily steps
    const numSteps = Math.max(1, daysToExecution);
    const mu = 0.08; // positive annual drift for AI compute demand
    const strike = strikeTarget || spot;

    const samplePaths: MonteCarloPath[] = [];
    const finalPrices: number[] = [];
    const payoffs: number[] = [];

    // Poisson jump parameters (AI model breakthrough or data center outage shock)
    const jumpIntensityLambda = 0.05; // 5% chance of jump per month
    const jumpMean = 0.25; // 25% price spike upon jump

    for (let sim = 0; sim < simulationsCount; sim++) {
      let currentPrice = spot;
      const points: { step: number; day: number; simulatedSpot: number; simulatedCost: number }[] = [];
      let isShortage = false;

      points.push({ step: 0, day: 0, simulatedSpot: spot, simulatedCost: baseCost });

      for (let step = 1; step <= numSteps; step++) {
        // Standard normal random using Box-Muller transform
        const u1 = Math.random();
        const u2 = Math.random();
        const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);

        // Jump diffusion check
        let jump = 0;
        if (Math.random() < jumpIntensityLambda * dt * 30) {
          jump = (Math.random() * 0.35 + 0.15); // +15% to +50% shortage shock
          isShortage = true;
        }

        // Geometric Brownian Motion with Jump
        const dS = currentPrice * (mu * dt + sigma * Math.sqrt(dt) * z + jump);
        currentPrice = Math.max(baseCost * 0.9, currentPrice + dS);

        if (sim < 15) {
          points.push({
            step,
            day: step,
            simulatedSpot: Number(currentPrice.toFixed(2)),
            simulatedCost: Number((baseCost * (1 + (step / 365) * 0.02)).toFixed(2))
          });
        }
      }

      finalPrices.push(currentPrice);
      payoffs.push(Math.max(0, currentPrice - strike));

      if (sim < 15) {
        samplePaths.push({
          pathIndex: sim,
          points,
          finalPrice: Number(currentPrice.toFixed(2)),
          isTriggeredShortage: isShortage
        });
      }
    }

    finalPrices.sort((a, b) => a - b);
    const meanStrike = Number((finalPrices.reduce((a, b) => a + b, 0) / finalPrices.length).toFixed(2));
    const medianStrike = Number(finalPrices[Math.floor(finalPrices.length * 0.5)].toFixed(2));
    const p05Strike = Number(finalPrices[Math.floor(finalPrices.length * 0.05)].toFixed(2));
    const p95Strike = Number(finalPrices[Math.floor(finalPrices.length * 0.95)].toFixed(2));
    const expectedPayoff = Number((payoffs.reduce((a, b) => a + b, 0) / payoffs.length).toFixed(2));

    const strikePricing = this.calculateStrikePricing(gpuModel, daysToExecution, strike, 1, 1);

    return {
      simulationsCount,
      meanStrike,
      medianStrike,
      p05Strike,
      p95Strike,
      expectedPayoff,
      delta: strikePricing.greeks.delta,
      gamma: strikePricing.greeks.gamma,
      vega: strikePricing.greeks.vega,
      theta: strikePricing.greeks.theta,
      samplePaths
    };
  }

  /**
   * Generates a 3D Strike Volatility Surface grid across tenors and strikes.
   */
  generateStrikeSurface(gpuModel: GpuModelId) {
    const market = db.spotMarketStates[gpuModel];
    const spot = market ? market.lastPrice : 42.0;
    const tenors = [
      { label: '7D', days: 7 },
      { label: '14D', days: 14 },
      { label: '30D', days: 30 },
      { label: '60D', days: 60 },
      { label: '90D', days: 90 },
      { label: '180D', days: 180 },
      { label: '360D', days: 360 }
    ];

    const moneynessDeltas = [0.80, 0.90, 0.95, 1.00, 1.05, 1.10, 1.20]; // 80% to 120% of spot

    const matrix: { tenor: string; days: number; strike: number; moneyness: number; premium: number; iv: number }[] = [];

    tenors.forEach(t => {
      moneynessDeltas.forEach(m => {
        const strike = Number((spot * m).toFixed(2));
        const res = this.calculateStrikePricing(gpuModel, t.days, strike, 1, 1);
        // Volatility smile: OTM calls and deep ITM puts have higher implied volatility
        const smile = Math.abs(1.0 - m) * 12.5;
        const surfaceIv = (market?.impliedVolatility24h || 21.4) + smile + (t.days / 365) * 4.0;

        matrix.push({
          tenor: t.label,
          days: t.days,
          strike,
          moneyness: m,
          premium: res.unitPremiumUsd,
          iv: Number(surfaceIv.toFixed(1))
        });
      });
    });

    return matrix;
  }
}

export const pricingEngine = new GpuxPricingEngine();
