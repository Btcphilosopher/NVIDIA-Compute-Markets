import { GpuxIndex, GpuModelId } from './types.js';
import { db } from './database.js';

export function calculateGpuxIndices(): GpuxIndex[] {
  const getPrice = (m: GpuModelId) => db.spotMarketStates[m]?.lastPrice || 40.0;
  const getChange = (m: GpuModelId) => db.spotMarketStates[m]?.priceChange24hPct || 0.0;

  const h100 = getPrice('H100_SXM5');
  const h200 = getPrice('H200_SXM5');
  const b200 = getPrice('B200');
  const a100 = getPrice('A100_SXM4_80GB');
  const l40s = getPrice('L40S');
  const gb200 = getPrice('GB200_NVL72');

  // GPUX Global 100: 35% H100, 25% H200, 20% B200, 10% A100, 10% L40S
  const global100Val = Number((h100 * 0.35 + h200 * 0.25 + b200 * 0.20 + a100 * 0.10 + l40s * 0.10).toFixed(2));
  const globalChange = Number((getChange('H100_SXM5') * 0.35 + getChange('H200_SXM5') * 0.25 + getChange('B200') * 0.20).toFixed(2));

  // GPUX Train Index: Heavy weight on Blackwell & Hopper NVLink
  const trainVal = Number((gb200 * 0.30 + b200 * 0.35 + h100 * 0.25 + h200 * 0.10).toFixed(2));

  // GPUX Infer Index: Heavy weight on HBM3e bandwidth (H200, B200, L40S)
  const inferVal = Number((h200 * 0.40 + b200 * 0.30 + l40s * 0.30).toFixed(2));

  // GPUX Green Compute: Low PUE, stranded clean flare & hydro nodes
  const greenVal = Number((h100 * 0.92 * 0.5 + h200 * 0.91 * 0.3 + b200 * 0.90 * 0.2).toFixed(2));

  const generateHistory = (base: number) => {
    const hist = [];
    let p = base * 0.96;
    for (let i = 24; i >= 0; i--) {
      p += (Math.random() - 0.49) * (base * 0.015);
      hist.push({
        timestamp: new Date(Date.now() - i * 3600000).toISOString(),
        value: Number(p.toFixed(2))
      });
    }
    return hist;
  };

  return [
    {
      symbol: 'GPUX-GLOBAL-100',
      name: 'GPUX Global 100 Compute Benchmark',
      value: global100Val,
      change24h: Number((global100Val * (globalChange / 100)).toFixed(2)),
      change24hPct: globalChange,
      description: 'Capitalization-weighted composite benchmark of global spot compute capacity.',
      basket: [
        { gpuModel: 'H100 SXM5', weightPct: 35, currentPrice: h100 },
        { gpuModel: 'H200 SXM5', weightPct: 25, currentPrice: h200 },
        { gpuModel: 'B200 Blackwell', weightPct: 20, currentPrice: b200 },
        { gpuModel: 'A100 80GB', weightPct: 10, currentPrice: a100 },
        { gpuModel: 'L40S PCIe', weightPct: 10, currentPrice: l40s }
      ],
      history: generateHistory(global100Val)
    },
    {
      symbol: 'GPUX-TRAIN-INDEX',
      name: 'GPUX Frontier Training Index',
      value: trainVal,
      change24h: Number((trainVal * 0.024).toFixed(2)),
      change24hPct: 2.4,
      description: 'High-interconnect dense FP8/BF16 pretraining cluster index (NVLink 4/5).',
      basket: [
        { gpuModel: 'GB200 NVL72', weightPct: 30, currentPrice: gb200 },
        { gpuModel: 'B200', weightPct: 35, currentPrice: b200 },
        { gpuModel: 'H100 SXM5', weightPct: 25, currentPrice: h100 },
        { gpuModel: 'H200 SXM5', weightPct: 10, currentPrice: h200 }
      ],
      history: generateHistory(trainVal)
    },
    {
      symbol: 'GPUX-INFER-INDEX',
      name: 'GPUX Large Model Inference Index',
      value: inferVal,
      change24h: Number((inferVal * 0.018).toFixed(2)),
      change24hPct: 1.8,
      description: 'HBM3e memory-bandwidth intensive cluster index for real-time generative token serving.',
      basket: [
        { gpuModel: 'H200 141GB', weightPct: 40, currentPrice: h200 },
        { gpuModel: 'B200 192GB', weightPct: 30, currentPrice: b200 },
        { gpuModel: 'L40S 48GB', weightPct: 30, currentPrice: l40s }
      ],
      history: generateHistory(inferVal)
    },
    {
      symbol: 'GPUX-GREEN-COMPUTE',
      name: 'GPUX Carbon-Neutral Compute Index',
      value: greenVal,
      change24h: Number((greenVal * -0.012).toFixed(2)),
      change24hPct: -1.2,
      description: 'Zero-carbon hydro, geothermal, and flared-gas mitigation compute clusters with PUE < 1.10.',
      basket: [
        { gpuModel: 'Crusoe Hydro Flare', weightPct: 50, currentPrice: h100 * 0.90 },
        { gpuModel: 'Nebius Geothermal', weightPct: 30, currentPrice: h200 * 0.91 },
        { gpuModel: 'Nordic Clean B200', weightPct: 20, currentPrice: b200 * 0.90 }
      ],
      history: generateHistory(greenVal)
    }
  ];
}
