import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

import { db } from './server/database.js';
import { GPU_CAPABILITY_CATALOG } from './server/gpuModels.js';
import { pricingEngine } from './server/pricingEngine.js';
import { matchingEngine } from './server/matchingEngine.js';
import { settlementEngine } from './server/settlementEngine.js';
import { workloadRouter } from './server/workloadRouter.js';
import { MACRO_SCENARIOS, simulationEngine } from './server/simulationEngine.js';
import { calculateGpuxIndices } from './server/indices.js';
import { GpuModelId, WorkloadType } from './server/types.js';

dotenv.config();

let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    try {
      aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    } catch (err) {
      console.warn('Gemini client init warning:', err);
    }
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Healthcheck
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', protocol: 'GPUX_V1.4', timestamp: new Date().toISOString() });
  });

  // Providers and Interoperability Facilities
  app.get(['/api/providers', '/api/facilities'], (req, res) => {
    res.json({
      facilities: db.facilities,
      totalFacilities: db.facilities.length,
      totalGpusAcrossNetwork: db.facilities.reduce((acc, f) => acc + f.totalGpuCount, 0),
      availableGpusAcrossNetwork: db.facilities.reduce((acc, f) => acc + f.availableGpuCount, 0)
    });
  });

  // GPU Capability Catalog & Benchmarks
  app.get(['/api/gpus', '/api/gpu-models'], (req, res) => {
    res.json({
      catalog: GPU_CAPABILITY_CATALOG,
      gpuModels: GPU_CAPABILITY_CATALOG,
      standardUnit: {
        name: 'GPUX-CU',
        definition: '1.0 GPUX-CU = 1x NVIDIA H100 SXM5 80GB executing standard BF16 Transformer benchmark',
        baselineTflops: 989.0,
        baselineMemoryGb: 80
      }
    });
  });

  // Cluster Nodes and Capacity
  app.get(['/api/capacity', '/api/nodes'], (req, res) => {
    const { model, facility } = req.query;
    let nodes = db.nodes;
    if (model) nodes = nodes.filter(n => n.gpuModel === model);
    if (facility) nodes = nodes.filter(n => n.facilityId === facility);
    res.json({ nodes, count: nodes.length });
  });

  // Spot Markets Overview
  app.get('/api/markets', (req, res) => {
    res.json({ markets: Object.values(db.spotMarketStates) });
  });

  // Specific Market State
  app.get('/api/markets/:gpuModel', (req, res) => {
    const model = req.params.gpuModel as GpuModelId;
    const market = db.spotMarketStates[model];
    if (!market) {
      return res.status(404).json({ error: `Market for ${model} not found` });
    }
    res.json(market);
  });

  // Place Spot Order
  app.post('/api/orders', (req, res) => {
    try {
      const { side, gpuModel, quantityGpus, pricePerGpuHour, durationHours, creatorAddress, creatorName } = req.body;
      if (!side || !gpuModel || !quantityGpus || !pricePerGpuHour) {
        return res.status(400).json({ error: 'Missing required order fields' });
      }

      const result = matchingEngine.placeOrder({
        side,
        gpuModel,
        quantityGpus: Number(quantityGpus),
        pricePerGpuHour: Number(pricePerGpuHour),
        durationHours: Number(durationHours || 12),
        creatorAddress: creatorAddress || '0xUser...Web3',
        creatorName: creatorName || 'GPUX Web Terminal Trader'
      });

      res.json({ success: true, result });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Executed Trades
  app.get('/api/trades', (req, res) => {
    res.json({ trades: db.trades.slice(0, 50) });
  });

  // Spot Price Breakdown
  app.get('/api/spot/:gpuModel/:region?', (req, res) => {
    const model = req.params.gpuModel as GpuModelId;
    const calc = pricingEngine.calculateSpotPrice(model);
    res.json({ gpuModel: model, ...calc });
  });

  // Forward Curve
  app.get('/api/forward/:gpuModel', (req, res) => {
    const model = req.params.gpuModel as GpuModelId;
    const curve = pricingEngine.generateForwardCurve(model);
    res.json({ gpuModel: model, curve });
  });

  // Strike Pricing Calculator
  app.get('/api/strike/:gpuModel', (req, res) => {
    const model = req.params.gpuModel as GpuModelId;
    const days = Number(req.query.days || 30);
    const strike = Number(req.query.strike || (db.spotMarketStates[model]?.lastPrice || 42));
    const duration = Number(req.query.duration || 24);
    const quantity = Number(req.query.quantity || 8);

    const result = pricingEngine.calculateStrikePricing(model, days, strike, duration, quantity);
    res.json({ gpuModel: model, ...result });
  });

  // 3D Strike Volatility Surface
  app.get('/api/strike-surface/:gpuModel', (req, res) => {
    const model = req.params.gpuModel as GpuModelId;
    const surface = pricingEngine.generateStrikeSurface(model);
    res.json({ gpuModel: model, surface });
  });

  // Monte Carlo Simulation
  app.post('/api/monte-carlo', (req, res) => {
    const { gpuModel, daysToExecution, simulationsCount, strikeTarget } = req.body;
    const model = (gpuModel as GpuModelId) || 'H100_SXM5';
    const result = pricingEngine.runMonteCarloSimulation(
      model,
      Number(daysToExecution || 30),
      Number(simulationsCount || 1000),
      strikeTarget ? Number(strikeTarget) : undefined
    );
    res.json(result);
  });

  // Strike Contracts
  app.get('/api/contracts', (req, res) => {
    res.json({ contracts: db.contracts });
  });

  // Create & Lock a Compute Strike Contract
  app.post('/api/contracts', (req, res) => {
    try {
      const {
        gpuModel,
        gpuQuantity,
        executionStartTime,
        executionEndTime,
        durationHours,
        strikePricePerGpuHour,
        settlementMethod,
        performanceFloorPct,
        availabilityFloorPct,
        buyerName,
        buyerAddress
      } = req.body;

      const dur = Number(durationHours || 24);
      const qty = Number(gpuQuantity || 8);
      const strike = Number(strikePricePerGpuHour || 42.0);
      const notional = Number((dur * qty * strike).toFixed(2));
      const pricing = pricingEngine.calculateStrikePricing(gpuModel, 14, strike, dur, qty);

      const contractNumber = `GPUX-CTR-${Date.now().toString().slice(-6)}`;
      const contract = {
        id: `CTR-${Date.now()}`,
        contractNumber,
        buyerAddress: buyerAddress || '0x992...WebWallet',
        buyerName: buyerName || 'Enterprise Compute Reserve',
        sellerAddress: '0xCoreWeave...Pool',
        sellerName: 'Decentralized Compute Escrow Vault',
        gpuModel: gpuModel as GpuModelId,
        gpuQuantity: qty,
        totalNormalizedCu: qty * (GPU_CAPABILITY_CATALOG[gpuModel as GpuModelId]?.baseGpuxCu || 1.0),
        executionStartTime: executionStartTime || new Date(Date.now() + 86400000 * 7).toISOString(),
        executionEndTime: executionEndTime || new Date(Date.now() + 86400000 * 7 + dur * 3600000).toISOString(),
        durationHours: dur,
        strikePricePerGpuHour: strike,
        totalPremiumUsd: pricing.totalPremiumUsd,
        notionalValueUsd: notional,
        escrowLockedUsd: notional,
        settlementMethod: settlementMethod || 'PHYSICAL_EXECUTION',
        performanceFloorPct: Number(performanceFloorPct || 95.0),
        availabilityFloorPct: Number(availabilityFloorPct || 99.5),
        status: 'ESCROW_LOCKED' as const,
        createdAt: new Date().toISOString(),
        txHashEscrow: '0x' + Math.random().toString(16).substring(2) + Math.random().toString(16).substring(2)
      };

      db.contracts.unshift(contract);
      res.json({ success: true, contract });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Proofs of Compute
  app.get('/api/proofs', (req, res) => {
    res.json({ proofs: db.proofs });
  });

  // Generate Proof of Compute
  app.post('/api/proofs/generate', (req, res) => {
    try {
      const proof = settlementEngine.generateProofOfCompute(req.body);
      res.json({ success: true, proof });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Settle Contract on Blockchain
  app.post(['/api/settlement/settle', '/api/settle'], (req, res) => {
    try {
      const { contractId, proofId } = req.body;
      const result = settlementEngine.settleContract(contractId, proofId);
      res.json({ success: true, result });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Blockchain Ledger Blocks
  app.get(['/api/blockchain/blocks', '/api/blockchain'], (req, res) => {
    res.json({ blocks: db.blocks });
  });

  // Live NVML/DCGM Telemetry Stream
  app.get('/api/telemetry', (req, res) => {
    const telemetry = db.getLiveTelemetrySample();
    res.json({ telemetry, timestamp: new Date().toISOString() });
  });

  // GPUX Indices
  app.get('/api/indices', (req, res) => {
    const indices = calculateGpuxIndices();
    res.json({ indices });
  });

  // Macro Scenarios
  app.get('/api/scenarios', (req, res) => {
    res.json({
      activeScenarioKey: db.activeScenarioKey,
      activeScenario: db.activeScenarioKey,
      scenarios: Object.values(MACRO_SCENARIOS)
    });
  });

  // Apply Macro Scenario
  app.post(['/api/scenarios/apply', '/api/scenarios/activate/:key'], (req, res) => {
    const scenarioKey = req.params.key || req.body.scenarioKey;
    try {
      const scenario = simulationEngine.applyScenario(scenarioKey);
      res.json({ success: true, scenario, activeKey: db.activeScenarioKey, activeScenario: db.activeScenarioKey });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Advance Time Step
  app.post(['/api/scenarios/step', '/api/simulation/step'], (req, res) => {
    const { timeUnit, unit } = req.body; // '1D', '1W', '1M', '1Y'
    const result = simulationEngine.stepTime(timeUnit || unit || '1D');
    res.json({ success: true, ...result });
  });

  // Workload Compute Routing Solver
  app.post(['/api/route-compute', '/api/routing/solve'], (req, res) => {
    try {
      const solutions = workloadRouter.routeCompute(req.body);
      res.json({ success: true, solutions, count: solutions.length });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Gemini AI Assistant for Market Analysis & Quantitative Strategies
  app.post(['/api/ai-assistant', '/api/ai/analysis'], async (req, res) => {
    const prompt = req.body.prompt || req.body.userQuery;
    const context = req.body.context || req.body.marketContext;
    const ai = getAiClient();

    if (!ai) {
      // Fallback deterministic quantitative insights if no Gemini API key
      return res.json({
        analysis: `[GPUX Quantitative Core] Analysis based on current market state (${db.activeScenarioKey}):\n` +
          `• H100 Spot ($${db.spotMarketStates.H100_SXM5.lastPrice}/hr) presents a tight spread against 30D Forward ($${pricingEngine.generateForwardCurve('H100_SXM5')[4].forwardSpotPrice}).\n` +
          `• Implied Volatility is standing at ${db.spotMarketStates.H100_SXM5.impliedVolatility24h}%. Recommended strategy: Lock physical strike contracts on Crusoe Hydro (PUE 1.08) to hedge prospective grid volatility.`
      });
    }

    try {
      const h100Price = db.spotMarketStates.H100_SXM5.lastPrice;
      const b200Price = db.spotMarketStates.B200.lastPrice;
      const systemPrompt = `You are the lead Quantitative Pricing and GPU Infrastructure Architect for GPUX (the Interoperable Compute Capacity Marketplace).
Current Market Conditions:
- Active Macro Scenario: ${db.activeScenarioKey}
- H100 Spot Price: $${h100Price}/hr
- B200 Spot Price: $${b200Price}/hr
- Standard Unit: 1.0 GPUX-CU (Hopper Baseline)
- Global Network Capacity: 84% utilized
Provide concise, institutional-grade quantitative commentary, risk analysis, and arbitrage/hedging recommendations based on the user question. Keep responses structured, concise, and focused on physical and financial settlement mechanics.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `${systemPrompt}\n\nUser Query: ${prompt || 'Analyze current GPU compute forward curve and recommended hedging strategy.'}`
      });

      res.json({ analysis: response.text });
    } catch (err: any) {
      res.json({
        analysis: `[GPUX Quant Engine Offline Fallback] Analysis for ${db.activeScenarioKey}: H100 spot $${db.spotMarketStates.H100_SXM5.lastPrice}/hr with 30D forward curve showing contango due to training compute backlog.`
      });
    }
  });

  // Code Export Playground: Rust & R snippets
  app.get('/api/rust-code', (req, res) => {
    const rustSnippet = `// GPUX High-Performance Order Matching & Cryptographic Settlement Engine in Rust
use std::collections::BTreeMap;
use sha2::{Sha256, Digest};

#[derive(Debug, Clone)]
pub struct StrikeContract {
    pub contract_id: String,
    pub gpu_model: String,
    pub gpu_count: u32,
    pub strike_price_usd_hr: f64,
    pub execution_hours: u32,
    pub performance_floor: f32,
    pub escrow_amount: f64,
}

pub struct GpuxSettlementEngine {
    pub blocks: Vec<String>,
}

impl GpuxSettlementEngine {
    pub fn verify_proof_and_settle(
        &mut self,
        contract: &StrikeContract,
        actual_perf: f32,
        dcgm_merkle_root: &str,
    ) -> Result<f64, &'static str> {
        if actual_perf < contract.performance_floor {
            let penalty = contract.escrow_amount * 0.20;
            return Ok(contract.escrow_amount - penalty);
        }
        let mut hasher = Sha256::new();
        hasher.update(format!("{}:{}", contract.contract_id, dcgm_merkle_root));
        let proof_hash = format!("{:x}", hasher.finalize());
        self.blocks.push(proof_hash);
        Ok(contract.escrow_amount)
    }
}`;
    res.json({ code: rustSnippet, language: 'rust' });
  });

  app.get('/api/r-code', (req, res) => {
    const rSnippet = `# GPUX Quantitative Volatility & Forward Curve Pricing Engine in R
library(stats)

compute_black76_strike <- function(F, K, r, sigma, T) {
  d1 <- (log(F / K) + 0.5 * sigma^2 * T) / (sigma * sqrt(T))
  d2 <- d1 - sigma * sqrt(T)
  df <- exp(-r * T)
  call_price <- df * (F * pnorm(d1) - K * pnorm(d2))
  delta <- df * pnorm(d1)
  return(list(premium = call_price, delta = delta, d1 = d1, d2 = d2))
}

# Monte Carlo GPU Spot Price Path Simulation with Shortage Jumps
simulate_gpux_paths <- function(S0, mu, sigma, lambda_jump, jump_mean, n_sims = 1000, days = 30) {
  dt <- 1 / 365
  paths <- matrix(0, nrow = days + 1, ncol = n_sims)
  paths[1, ] <- S0
  for (t in 1:days) {
    z <- rnorm(n_sims)
    jumps <- rpois(n_sims, lambda_jump * dt) * rexp(n_sims, 1 / jump_mean)
    paths[t + 1, ] <- paths[t, ] * (1 + mu * dt + sigma * sqrt(dt) * z + jumps)
  }
  return(paths)
}`;
    res.json({ code: rSnippet, language: 'r' });
  });

  // AI Quantitative Market Intelligence Endpoint
  app.post('/api/ai/analysis', async (req, res) => {
    try {
      const { userQuery, marketContext } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
        // High quality quantitative analyst fallback response
        const fallback = `### GPUX Quantitative Compute Market Intelligence

**1. Market Structure & Forward Term Analysis:**
- **Term Structure**: Forward curves across H100 and B200 show moderate contango (+12.4% annualized), reflecting sustained enterprise pretraining backlog and datacenter power interconnection queues.
- **Scarcity Rent**: Current spot pricing at $42.50/GPU-hr clears +48% above the physical cost-of-capacity floor ($28.70/hr, accounting for 3-yr amortized CapEx, chassis InfiniBand NDR switches, and 1.15 PUE energy costs).

**2. Optimal Strike & Hedging Recommendation:**
- For multi-week transformer training, executing a **Physical Delivery Strike Contract at $43.20/GPU-hr** locks supply against hyperscaler price spikes while establishing a strict ≥95.0% performance benchmark floor.
- In the event of cluster throttling or thermal degradation below 95%, automated cryptographic slashing refunds 20% of escrow notional directly to the buyer's settlement account.`;
        return res.json({ analysis: fallback, source: 'quantitative_engine' });
      }

      const { GoogleGenAI } = await import('@google/genai');
      const ai = new GoogleGenAI({ apiKey });

      const prompt = `You are the Lead Quantitative GPU Commodity Strategist at GPUX.
Market Context:
- Active Global Spot Markets: H100 SXM5 ($42.50/hr), H200 ($54.00/hr), B200 ($78.00/hr), A100 ($28.00/hr), L40S ($18.00/hr)
- GPUX Index: $1,420.50 (+4.2%)
- Market Regime: ${JSON.stringify(marketContext || {})}

User Inquiry: ${userQuery || 'Analyze the current GPU compute market forward curves, strike lock strategies, and provide a quantitative hedging recommendation for an AI lab.'}

Provide a concise, highly technical quantitative assessment covering:
1. Physical cost-of-capacity floor vs current spot clearing price.
2. Contango / backwardation forward curve implications.
3. Recommended strike price & escrow hedging strategy with SLA enforcement.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
      });

      res.json({ analysis: response.text, source: 'gemini_2_5_flash' });
    } catch (err: any) {
      console.error('AI Analysis error:', err);
      res.status(500).json({ error: err.message || 'AI analysis failed' });
    }
  });

  // Vite middleware in development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GPUX Compute Market & Settlement Engine running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
