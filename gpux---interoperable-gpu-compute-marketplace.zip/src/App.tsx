import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.js';
import { SpotMarketDesk } from './components/SpotMarketDesk.js';
import { StrikePricingDesk } from './components/StrikePricingDesk.js';
import { WorkloadRouterModal } from './components/WorkloadRouterModal.js';
import { InteroperabilityTopology } from './components/InteroperabilityTopology.js';
import { TelemetryDCGM } from './components/TelemetryDCGM.js';
import { BlockchainSettlement } from './components/BlockchainSettlement.js';
import { ScenarioSandbox } from './components/ScenarioSandbox.js';
import { IndicesAndAnalytics } from './components/IndicesAndAnalytics.js';
import { CodePlayground } from './components/CodePlayground.js';
import { AiMarketAnalystModal } from './components/AiMarketAnalystModal.js';

import { 
  BlockchainBlock, 
  ClusterNode, 
  ComputeRoutingRequest, 
  ComputeRoutingSolution, 
  GpuCapability, 
  GpuModelId, 
  GpuxIndex, 
  MacroScenario, 
  ProofOfCompute, 
  ProviderFacility, 
  SpotMarketState, 
  StrikeContract 
} from './types/market.js';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('spot');
  const [selectedModel, setSelectedModel] = useState<GpuModelId>('H100_SXM5');

  // Application Data State
  const [markets, setMarkets] = useState<SpotMarketState[]>([]);
  const [capabilities, setCapabilities] = useState<Record<GpuModelId, GpuCapability>>({} as any);
  const [indices, setIndices] = useState<GpuxIndex[]>([]);
  const [scenarios, setScenarios] = useState<MacroScenario[]>([]);
  const [activeScenario, setActiveScenario] = useState<string>('BASE_MARKET');
  const [facilities, setFacilities] = useState<ProviderFacility[]>([]);
  const [nodes, setNodes] = useState<ClusterNode[]>([]);
  const [contracts, setContracts] = useState<StrikeContract[]>([]);
  const [proofs, setProofs] = useState<ProofOfCompute[]>([]);
  const [blocks, setBlocks] = useState<BlockchainBlock[]>([]);
  const [trades, setTrades] = useState<any[]>([]);

  // Modals State
  const [isSolverOpen, setIsSolverOpen] = useState<boolean>(false);
  const [isAiAnalystOpen, setIsAiAnalystOpen] = useState<boolean>(false);
  const [isLoadingInitial, setIsLoadingInitial] = useState<boolean>(true);

  // Safe fetch helper that handles non-JSON or error responses gracefully
  const safeFetchJson = async (url: string, defaultValue: any = {}) => {
    try {
      const res = await fetch(url);
      if (!res.ok) return defaultValue;
      const contentType = res.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        return await res.json();
      }
      return defaultValue;
    } catch {
      return defaultValue;
    }
  };

  // Fetch all authoritative state from backend
  const fetchAllState = async () => {
    try {
      const [
        mRes, capRes, idxRes, scenRes, facRes, nodeRes, conRes, proofRes, blockRes, tradeRes
      ] = await Promise.all([
        safeFetchJson('/api/markets', { markets: [] }),
        safeFetchJson('/api/gpu-models', { gpuModels: {} }),
        safeFetchJson('/api/indices', { indices: [] }),
        safeFetchJson('/api/scenarios', { scenarios: [] }),
        safeFetchJson('/api/facilities', { facilities: [] }),
        safeFetchJson('/api/nodes', { nodes: [] }),
        safeFetchJson('/api/contracts', { contracts: [] }),
        safeFetchJson('/api/proofs', { proofs: [] }),
        safeFetchJson('/api/blockchain', { blocks: [] }),
        safeFetchJson('/api/trades', { trades: [] })
      ]);

      if (mRes?.markets) setMarkets(mRes.markets);
      if (capRes?.gpuModels) setCapabilities(capRes.gpuModels);
      if (idxRes?.indices) setIndices(idxRes.indices);
      if (scenRes?.scenarios) {
        setScenarios(scenRes.scenarios);
        if (scenRes.activeScenario || scenRes.activeScenarioKey) {
          setActiveScenario(scenRes.activeScenario || scenRes.activeScenarioKey);
        }
      }
      if (facRes?.facilities) setFacilities(facRes.facilities);
      if (nodeRes?.nodes) setNodes(nodeRes.nodes);
      if (conRes?.contracts) setContracts(conRes.contracts);
      if (proofRes?.proofs) setProofs(proofRes.proofs);
      if (blockRes?.blocks) setBlocks(blockRes.blocks);
      if (tradeRes?.trades) setTrades(tradeRes.trades);
    } catch (err) {
      console.warn('Error fetching GPUX state:', err);
    } finally {
      setIsLoadingInitial(false);
    }
  };

  useEffect(() => {
    fetchAllState();
    const interval = setInterval(fetchAllState, 4000);
    return () => clearInterval(interval);
  }, []);

  // Handlers
  const handleSelectScenario = async (key: string) => {
    try {
      const res = await fetch(`/api/scenarios/activate/${key}`, { method: 'POST' });
      const data = await res.json();
      if (data.activeScenario) {
        setActiveScenario(data.activeScenario);
        fetchAllState();
      }
    } catch (err) {
      console.error('Failed to set scenario:', err);
    }
  };

  const handleStepTime = async (unit: '1D' | '1W' | '1M' | '1Y') => {
    try {
      await fetch(`/api/simulation/step`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ unit })
      });
      fetchAllState();
    } catch (err) {
      console.error('Failed to step time:', err);
    }
  };

  const handlePlaceSpotOrder = async (order: {
    side: 'BUY' | 'SELL';
    gpuModel: GpuModelId;
    quantityGpus: number;
    pricePerGpuHour: number;
    durationHours: number;
    creatorName: string;
  }) => {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(order)
    });
    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error || 'Failed to place order');
    }
    fetchAllState();
  };

  const handleLockContract = async (contractParams: any) => {
    const res = await fetch('/api/contracts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(contractParams)
    });
    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error || 'Failed to lock contract');
    }
    fetchAllState();
  };

  const handleLockRouteContract = async (
    solution: ComputeRoutingSolution,
    request: ComputeRoutingRequest
  ) => {
    const execStart = new Date(request.executionDate || Date.now() + 86400000 * 3).toISOString();
    const execEnd = new Date(
      new Date(execStart).getTime() + request.durationHours * 3600000
    ).toISOString();

    await handleLockContract({
      gpuModel: solution.gpuModel,
      gpuQuantity: solution.recommendedGpuCount,
      executionStartTime: execStart,
      executionEndTime: execEnd,
      durationHours: request.durationHours,
      strikePricePerGpuHour: solution.strikeLockRecommendedPrice,
      settlementMethod: 'PHYSICAL_EXECUTION',
      performanceFloorPct: request.minPerformancePct || 95.0,
      availabilityFloorPct: 99.5,
      locationConstraint: solution.location,
      buyerName: 'Workload Router Auto-Allocated'
    });
  };

  const handleTriggerSettlement = async (contractId: string, proofId: string) => {
    const res = await fetch('/api/settle', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contractId, proofId })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Settlement failed');
    }
    fetchAllState();
  };

  const handleGenerateProof = async (params: any) => {
    const res = await fetch('/api/proofs/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to generate proof');
    }
    const data = await res.json();
    fetchAllState();
    return data.proof;
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#D1D1D1] flex flex-col font-sans selection:bg-[#00E5FF] selection:text-[#050505]">
      {/* Top Header & Navigation */}
      <Header
        markets={markets}
        indices={indices}
        activeScenario={activeScenario}
        scenarios={scenarios}
        onSelectScenario={handleSelectScenario}
        onStepTime={handleStepTime}
        onOpenSolver={() => setIsSolverOpen(true)}
        onOpenAiAnalyst={() => setIsAiAnalystOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Workspace Tabs */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto pb-10">
        {activeTab === 'spot' && (
          <SpotMarketDesk
            markets={markets}
            selectedModel={selectedModel}
            onSelectModel={setSelectedModel}
            capabilities={capabilities}
            onPlaceOrder={handlePlaceSpotOrder}
            trades={trades}
          />
        )}

        {activeTab === 'strike' && (
          <StrikePricingDesk
            selectedModel={selectedModel}
            capabilities={capabilities}
            onSelectModel={setSelectedModel}
            contracts={contracts}
            onLockContract={handleLockContract}
          />
        )}

        {activeTab === 'solver' && (
          <div className="p-4 space-y-4">
            <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-6 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-white font-mono">Autonomous Workload Capacity Router</h2>
                <p className="text-xs text-[#888] font-mono mt-1">Multi-objective constraint solver matching pretraining and inference runs to lowest-cost verified capacity.</p>
              </div>
              <button
                onClick={() => setIsSolverOpen(true)}
                className="px-5 py-2.5 bg-[#00E5FF] hover:bg-[#00cce6] rounded text-[#050505] font-mono font-bold text-xs uppercase tracking-wider shadow-[0_0_12px_rgba(0,229,255,0.3)]"
              >
                Launch Workload Solver
              </button>
            </div>
            <InteroperabilityTopology facilities={facilities} nodes={nodes} />
          </div>
        )}

        {activeTab === 'topology' && (
          <InteroperabilityTopology facilities={facilities} nodes={nodes} />
        )}

        {activeTab === 'telemetry' && (
          <TelemetryDCGM />
        )}

        {activeTab === 'settlement' && (
          <BlockchainSettlement
            contracts={contracts}
            proofs={proofs}
            blocks={blocks}
            onTriggerSettlement={handleTriggerSettlement}
            onGenerateProof={handleGenerateProof}
          />
        )}

        {activeTab === 'scenarios' && (
          <ScenarioSandbox
            scenarios={scenarios}
            activeScenarioKey={activeScenario}
            onSelectScenario={handleSelectScenario}
            onStepTime={handleStepTime}
          />
        )}

        {activeTab === 'indices' && (
          <IndicesAndAnalytics indices={indices} />
        )}

        {activeTab === 'api' && (
          <CodePlayground />
        )}
      </main>

      {/* Workload Router & Solver Modal */}
      <WorkloadRouterModal
        isOpen={isSolverOpen}
        onClose={() => setIsSolverOpen(false)}
        onLockRouteContract={handleLockRouteContract}
      />

      {/* AI Quantitative Analyst Modal */}
      <AiMarketAnalystModal
        isOpen={isAiAnalystOpen}
        onClose={() => setIsAiAnalystOpen(false)}
        markets={markets}
        activeScenario={activeScenario}
      />

      {/* Persistent Footer Status */}
      <footer className="h-10 bg-[#0A0A0A] border-t border-[#222] flex items-center px-6 justify-between text-[9px] tracking-widest text-[#555] uppercase font-mono">
        <div className="flex gap-6">
          <span>SYSTEM_VERSION: 2.4.0-PROD</span>
          <span>ARCHITECTURE: DISTRIBUTED_HYBRID</span>
          <span>CONSENSUS: POC+BLS12-381</span>
          <span>DBMS: POSTGRES_TS</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 bg-[#00FF41] rounded-full animate-pulse"></span>
          <span className="text-[#00FF41]">ALL SYSTEMS NOMINAL (74,752 GPUS ONLINE)</span>
        </div>
      </footer>
    </div>
  );
}
