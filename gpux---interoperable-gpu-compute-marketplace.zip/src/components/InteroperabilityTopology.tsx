import React, { useState } from 'react';
import { 
  Database, 
  Server, 
  Layers, 
  Globe, 
  Cpu, 
  CheckCircle2, 
  Zap, 
  ShieldCheck, 
  ExternalLink,
  Search,
  Filter
} from 'lucide-react';
import { ClusterNode, ProviderFacility } from '../types/market.js';

interface InteroperabilityTopologyProps {
  facilities: ProviderFacility[];
  nodes: ClusterNode[];
}

export const InteroperabilityTopology: React.FC<InteroperabilityTopologyProps> = ({
  facilities,
  nodes
}) => {
  const [selectedFacilityId, setSelectedFacilityId] = useState<string>(facilities[0]?.id || '');
  const selectedFacility = facilities.find(f => f.id === selectedFacilityId) || facilities[0];
  const facilityNodes = nodes.filter(n => n.facilityId === selectedFacility?.id);

  return (
    <div id="interoperability-topology" className="p-4 space-y-4 text-[#D1D1D1] font-sans">
      {/* Top Banner */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="text-xl font-black text-white font-mono flex items-center gap-2">
              <Database className="w-5 h-5 text-[#00E5FF]" />
              Interoperability Database & Node Topology
            </div>
            <span className="px-2 py-0.5 rounded bg-[#001A1D] text-[#00E5FF] text-[9px] font-mono border border-[#00E5FF]/40 uppercase tracking-wider">
              POSTGRESQL MULTI-TIER
            </span>
          </div>
          <p className="text-xs text-[#888] font-mono mt-1">
            Universal relational mapping between disparate cloud providers, private data centres, clusters, and cryptographic contracts.
          </p>
        </div>

        {/* Database Hierarchy Visual Flow */}
        <div className="flex items-center gap-2 text-[10px] font-mono text-[#666] bg-[#050505] px-3.5 py-2 rounded border border-[#222]">
          <span className="text-[#00E5FF] font-bold">PROVIDER</span>
          <span>→</span>
          <span className="text-[#00E5FF] font-bold">FACILITY</span>
          <span>→</span>
          <span className="text-[#00E5FF] font-bold">CLUSTER</span>
          <span>→</span>
          <span className="text-[#00E5FF] font-bold">NODE</span>
          <span>→</span>
          <span className="text-[#00FF41] font-bold">GPU</span>
          <span>→</span>
          <span className="text-[#F27D26] font-bold">CONTRACT</span>
        </div>
      </div>

      {/* External ID Cross-Mapping Table Card */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-2">
            <ExternalLink className="w-4 h-4 text-[#00E5FF]" />
            External-ID Cross-Mapping Engine (Heterogeneous Provider Resolution)
          </div>
          <span className="text-[9px] font-mono text-[#00E5FF]">GPUX ID ⟷ NATIVE PROVIDER ID</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left">
            <thead>
              <tr className="text-[#555] border-b border-[#1A1A1A] text-[9px] uppercase">
                <th className="pb-2">GPUX CANONICAL ID</th>
                <th className="pb-2">PROVIDER NAME</th>
                <th className="pb-2">REGION / LOCATION</th>
                <th className="pb-2">EXTERNAL NATIVE ID</th>
                <th className="pb-2">PUE</th>
                <th className="pb-2">ENERGY TARIFF</th>
                <th className="pb-2">INTERCONNECT</th>
                <th className="pb-2">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1A1A1A]">
              {facilities.map((fac) => (
                <tr 
                  key={fac.id}
                  onClick={() => setSelectedFacilityId(fac.id)}
                  className={`hover:bg-[#111] cursor-pointer transition ${
                    selectedFacilityId === fac.id ? 'bg-[#001A1D] font-bold' : ''
                  }`}
                >
                  <td className="py-2.5 text-[#00E5FF]">{fac.id}</td>
                  <td className="py-2.5 text-white">{fac.providerName}</td>
                  <td className="py-2.5 text-[#888]">{fac.city}, {fac.country}</td>
                  <td className="py-2.5 text-[#00E5FF] font-bold">{fac.externalProviderId}</td>
                  <td className="py-2.5 text-[#F27D26]">{fac.pue?.toFixed(2) ?? '1.10'}</td>
                  <td className="py-2.5 text-[#D1D1D1]">${fac.electricityRateKwh?.toFixed(3) ?? '0.080'}/kWh</td>
                  <td className="py-2.5 text-[#666]">{fac.networkTier}</td>
                  <td className="py-2.5">
                    <span className="inline-flex items-center gap-1.5 text-[9px] px-2 py-0.5 rounded bg-[#002200] text-[#00FF41] border border-[#00FF41]/40 font-bold uppercase">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#00FF41] animate-pulse"></span>
                      ONLINE ({fac.availableGpuCount.toLocaleString()})
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Facility Cluster Nodes & Real-time Node Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 4 Cols: Facility Selector */}
        <div className="lg:col-span-4 bg-[#0A0A0A] border border-[#222] rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-[#00E5FF]" />
              Connected Facilities
            </div>
            <span className="text-[9px] font-mono text-[#888]">{facilities.length} Global Hubs</span>
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto pr-1 scrollbar-thin">
            {facilities.map((f) => {
              const isSelected = f.id === selectedFacilityId;
              return (
                <div
                  key={f.id}
                  onClick={() => setSelectedFacilityId(f.id)}
                  className={`p-3 rounded border transition cursor-pointer ${
                    isSelected
                      ? 'bg-[#001A1D] border-[#00E5FF] shadow-[0_0_10px_rgba(0,229,255,0.2)]'
                      : 'bg-[#050505] border-[#222] hover:border-[#333]'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-bold text-xs text-white font-mono">{f.providerName}</div>
                      <div className="text-[10px] text-[#888] font-mono">{f.facilityName}</div>
                    </div>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#1A1A1A] text-[#00E5FF] font-mono border border-[#333]">
                      {f.totalGpuCount.toLocaleString()} GPUs
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-[#1A1A1A] text-[9px] font-mono text-[#666]">
                    <div>PUE: <span className="text-[#00FF41] font-bold">{f.pue}</span></div>
                    <div>TARIFF: <span className="text-[#F27D26]">${f.electricityRateKwh}</span></div>
                    <div>GREEN: <span className="text-[#00E5FF]">{f.greenEnergyPercentage}%</span></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 8 Cols: Hardware Nodes & Interconnect Specs */}
        <div className="lg:col-span-8 bg-[#0A0A0A] border border-[#222] rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-[#222] pb-3">
            <div>
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-[#00E5FF]" />
                <h3 className="font-bold text-sm text-white font-mono">
                  Cluster Nodes in {selectedFacility?.facilityName}
                </h3>
              </div>
              <p className="text-xs text-[#888] font-mono mt-0.5">
                Facility ID: <span className="text-[#00E5FF]">{selectedFacility?.id}</span> • Native ID: <span className="text-[#F27D26]">{selectedFacility?.externalProviderId}</span>
              </p>
            </div>

            <span className="text-xs font-mono text-[#00FF41] bg-[#002200] px-2.5 py-1 rounded border border-[#00FF41]/40">
              {facilityNodes.length} Verified Nodes
            </span>
          </div>

          {/* Node Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {facilityNodes.map((n) => (
              <div
                key={n.id}
                className="bg-[#050505] border border-[#222] rounded p-3.5 space-y-2 hover:border-[#333] transition"
              >
                <div className="flex items-center justify-between">
                  <div className="font-bold text-xs text-white font-mono">{n.id}</div>
                  <span className={`text-[9px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                    n.status === 'AVAILABLE'
                      ? 'bg-[#002200] text-[#00FF41] border border-[#00FF41]/40'
                      : 'bg-[#221200] text-[#F27D26] border border-[#F27D26]/40'
                  }`}>
                    {n.status}
                  </span>
                </div>

                <div className="space-y-1 text-xs font-mono">
                  <div className="flex justify-between text-[#888]">
                    <span>GPU RIG:</span>
                    <span className="text-[#00E5FF] font-bold">{n.gpuCount}× {n.gpuModel}</span>
                  </div>
                  <div className="flex justify-between text-[#888]">
                    <span>INTERCONNECT:</span>
                    <span className="text-[#D1D1D1]">{n.interconnect} ({n.networkSpeedGbps} Gbps)</span>
                  </div>
                  <div className="flex justify-between text-[#888]">
                    <span>RAM / NVME:</span>
                    <span className="text-[#D1D1D1]">{n.ramGb}GB / {n.storageTb}TB</span>
                  </div>
                  <div className="flex justify-between text-[#888] pt-1 border-t border-[#1A1A1A]">
                    <span>SPOT ASK:</span>
                    <span className="text-white font-bold">${n.hourlySpotAsk?.toFixed(2) ?? '0.00'}/hr</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
