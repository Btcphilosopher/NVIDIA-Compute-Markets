import React from 'react';
import { 
  Layers, 
  TrendingUp, 
  TrendingDown, 
  PieChart as PieIcon, 
  BarChart2, 
  ArrowUpRight, 
  ArrowDownRight,
  ShieldCheck,
  Zap,
  Globe
} from 'lucide-react';
import { GpuxIndex } from '../types/market.js';

interface IndicesAndAnalyticsProps {
  indices: GpuxIndex[];
}

export const IndicesAndAnalytics: React.FC<IndicesAndAnalyticsProps> = ({ indices }) => {
  return (
    <div id="indices-and-analytics-desk" className="p-4 space-y-4 text-[#D1D1D1] font-sans">
      {/* Top Banner */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="text-xl font-black text-white font-mono flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#00E5FF]" />
              GPUX Compute Commodity Benchmark Indices
            </div>
            <span className="px-2 py-0.5 rounded bg-[#001A1D] text-[#00E5FF] text-[9px] font-mono border border-[#00E5FF]/40 uppercase tracking-wider">
              VOLUME-WEIGHTED CU BASKETS
            </span>
          </div>
          <p className="text-xs text-[#888] font-mono mt-1">
            Global standardized benchmark indices tracking aggregate compute power, specialized pretraining clusters, inference capacity, and zero-carbon green compute.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-[#00E5FF] bg-[#050505] px-3 py-1.5 rounded border border-[#222]">
          <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse"></span>
          REAL-TIME INDEX CALCULATION
        </div>
      </div>

      {/* Index Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {indices.map((idx) => {
          const isPos = idx.change24hPct >= 0;
          return (
            <div
              key={idx.symbol}
              className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 flex flex-col justify-between hover:border-[#333] transition"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-[#00E5FF] bg-[#001A1D] px-2 py-0.5 rounded border border-[#00E5FF]/40">
                      {idx.symbol}
                    </span>
                    <h3 className="font-bold text-sm text-white mt-2 font-mono">{idx.name}</h3>
                  </div>
                  <div className={`text-xs font-mono font-bold flex items-center gap-1 ${
                    isPos ? 'text-[#00FF41]' : 'text-[#FF4444]'
                  }`}>
                    {isPos ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                    {isPos ? '+' : ''}{idx.change24hPct?.toFixed(2) ?? '0.00'}%
                  </div>
                </div>

                <p className="text-xs text-[#888] font-sans mt-2 leading-relaxed">
                  {idx.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#1A1A1A]">
                <div className="flex items-baseline justify-between font-mono">
                  <span className="text-[10px] text-[#666] uppercase tracking-widest">INDEX VALUE</span>
                  <span className="text-2xl font-bold text-white">${idx.value?.toFixed(2) ?? '0.00'}</span>
                </div>

                {/* Basket Composition Weightings */}
                <div className="mt-3 space-y-1 text-[10px] font-mono">
                  <span className="text-[9px] uppercase tracking-widest text-[#555]">BASKET CONSTITUENTS:</span>
                  <div className="space-y-1 pt-1">
                    {(idx.constituents || []).map((c) => (
                      <div key={c.gpuModel} className="flex justify-between text-[#888]">
                        <span className="text-[#D1D1D1]">{c.gpuModel ? c.gpuModel.split('_')[0] : 'GPU'}</span>
                        <span className="text-[#00E5FF] font-bold">{((c.weight || 0) * 100).toFixed(0)}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
