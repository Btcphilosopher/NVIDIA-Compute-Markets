import React, { useState } from 'react';
import { 
  Cpu, 
  X, 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  Server, 
  DollarSign, 
  Leaf, 
  Clock,
  Layers,
  Globe,
  Sliders
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { 
  ComputeRoutingRequest, 
  ComputeRoutingSolution, 
  GpuModelId 
} from '../types/market.js';

interface WorkloadRouterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLockRouteContract: (solution: ComputeRoutingSolution, request: ComputeRoutingRequest) => Promise<void>;
}

export const WorkloadRouterModal: React.FC<WorkloadRouterModalProps> = ({
  isOpen,
  onClose,
  onLockRouteContract
}) => {
  const [naturalLanguagePrompt, setNaturalLanguagePrompt] = useState<string>(
    'I need 1,000 units of verified NVIDIA compute for six hours next Tuesday to run a batch inference job. Find me the cheapest zero-carbon capacity.'
  );

  const [workloadType, setWorkloadType] = useState<any>('LLM_PRETRAINING');
  const [targetGpuxCu, setTargetGpuxCu] = useState<number>(1000);
  const [durationHours, setDurationHours] = useState<number>(6);
  const [executionDate, setExecutionDate] = useState<string>(
    new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0]
  );
  const [priority, setPriority] = useState<any>('BALANCED');
  const [zeroCarbonOnly, setZeroCarbonOnly] = useState<boolean>(false);
  const [locationConstraint, setLocationConstraint] = useState<string>('ANY');

  const [solutions, setSolutions] = useState<ComputeRoutingSolution[]>([]);
  const [selectedSolutionIndex, setSelectedSolutionIndex] = useState<number>(0);
  const [isSolving, setIsSolving] = useState<boolean>(false);
  const [isLocking, setIsLocking] = useState<boolean>(false);
  const [lockFeedback, setLockFeedback] = useState<string | null>(null);

  const handleSolve = async () => {
    setIsSolving(true);
    setLockFeedback(null);
    try {
      const res = await fetch('/api/routing/solve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workloadType,
          targetGpuxCu,
          durationHours,
          executionDate,
          priority,
          zeroCarbonOnly,
          locationConstraint,
          minPerformancePct: 95.0,
          minAvailabilityPct: 99.5
        })
      });
      const data = await res.json();
      if (data.solutions) {
        setSolutions(data.solutions);
        setSelectedSolutionIndex(0);
      }
    } catch (err: any) {
      console.error('Failed to solve workload routing:', err);
    } finally {
      setIsSolving(false);
    }
  };

  const handleLockSelectedSolution = async () => {
    const solution = solutions[selectedSolutionIndex];
    if (!solution) return;
    setIsLocking(true);
    setLockFeedback(null);
    try {
      await onLockRouteContract(solution, {
        workloadType,
        targetGpuxCu,
        durationHours,
        executionDate,
        priority,
        zeroCarbonOnly,
        locationConstraint,
        minPerformancePct: 95.0,
        minAvailabilityPct: 99.5
      });
      confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
      setLockFeedback(`Capacity allocation locked! Smart contract escrow instantiated.`);
      setTimeout(() => {
        setLockFeedback(null);
        onClose();
      }, 2500);
    } catch (err: any) {
      setLockFeedback(`Lock failed: ${err.message}`);
    } finally {
      setIsLocking(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div id="workload-router-modal" className="fixed inset-0 z-50 bg-[#050505]/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0A0A0A] border border-[#222] rounded-xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden text-[#D1D1D1] font-sans">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#222] flex items-center justify-between bg-[#050505]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-[#001A1D] border border-[#00E5FF] flex items-center justify-center text-[#00E5FF]">
              <Cpu className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white flex items-center gap-2 font-mono">
                GPUX Workload Routing & Capacity Solver
                <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#001A1D] text-[#00E5FF] border border-[#00E5FF]/40 uppercase tracking-wider">
                  OPTIMAL ESCROW MATCH
                </span>
              </h2>
              <p className="text-xs text-[#888] font-mono">
                Solve capacity allocation across global clusters, verify SLA metrics, and lock cryptographic forward contracts.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-[#1A1A1A] text-[#888] hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Natural Language Prompt Preview */}
          <div className="bg-[#050505] p-3.5 rounded border border-[#222] space-y-2">
            <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-1.5 font-mono">
              <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" />
              Natural Language Intent Parser
            </div>
            <textarea
              rows={2}
              value={naturalLanguagePrompt}
              onChange={(e) => setNaturalLanguagePrompt(e.target.value)}
              className="w-full bg-transparent text-xs text-white focus:outline-none resize-none font-mono"
            />
          </div>

          {/* Structured Parameters Form */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
            <div>
              <label className="block text-[#888] text-[10px] uppercase mb-1">TARGET GPUX CU:</label>
              <input
                type="number"
                value={targetGpuxCu}
                onChange={(e) => setTargetGpuxCu(Number(e.target.value))}
                className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-white focus:border-[#00E5FF] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[#888] text-[10px] uppercase mb-1">DURATION (HOURS):</label>
              <input
                type="number"
                value={durationHours}
                onChange={(e) => setDurationHours(Number(e.target.value))}
                className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-white focus:border-[#00E5FF] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[#888] text-[10px] uppercase mb-1">EXECUTION DATE:</label>
              <input
                type="date"
                value={executionDate}
                onChange={(e) => setExecutionDate(e.target.value)}
                className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-white focus:border-[#00E5FF] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[#888] text-[10px] uppercase mb-1">OPTIMIZATION OBJECTIVE:</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-white focus:border-[#00E5FF] focus:outline-none"
              >
                <option value="CHEAPEST">Lowest Total Cost</option>
                <option value="PERFORMANCE">Highest FLOPs Throughput</option>
                <option value="GREEN">Zero-Carbon Verified</option>
                <option value="BALANCED">Balanced Multi-Objective</option>
              </select>
            </div>
          </div>

          {/* Quick Solver Trigger Button */}
          <button
            onClick={handleSolve}
            disabled={isSolving}
            className="w-full py-2.5 rounded bg-[#001A1D] border border-[#00E5FF] text-[#00E5FF] hover:bg-[#00E5FF]/20 text-xs font-mono font-bold transition flex items-center justify-center gap-2 uppercase tracking-wider"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isSolving ? 'SOLVING OPTIMAL ROUTE...' : 'Solve Global Workload Allocation'}</span>
          </button>

          {/* Solutions List */}
          {solutions.length > 0 && (
            <div className="space-y-3">
              <div className="text-[10px] uppercase tracking-widest text-[#666] font-mono">
                RANKED ALLOCATION SOLUTIONS ({solutions.length} CANDIDATES)
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono">
                {solutions.map((sol, idx) => {
                  const isSelected = selectedSolutionIndex === idx;
                  return (
                    <div
                      key={idx}
                      onClick={() => setSelectedSolutionIndex(idx)}
                      className={`p-4 rounded border transition cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'bg-[#001A1D] border-[#00E5FF] shadow-[0_0_12px_rgba(0,229,255,0.25)]'
                          : 'bg-[#050505] border-[#222] hover:border-[#333]'
                      }`}
                    >
                      <div>
                        <div className="flex items-start justify-between">
                          <span className="font-bold text-white text-xs">{sol.providerName}</span>
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#1A1A1A] text-[#00E5FF] border border-[#333]">
                            MATCH #{idx + 1}
                          </span>
                        </div>
                        <div className="text-[11px] text-[#00E5FF] font-bold mt-1">
                          {sol.recommendedGpuCount}× {sol.gpuModel.split('_')[0]}
                        </div>
                        <div className="text-[10px] text-[#888] mt-0.5">{sol.facilityName} ({sol.location})</div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-[#1A1A1A] space-y-1 text-xs">
                        <div className="flex justify-between text-[#888]">
                          <span>ESTIMATED TOTAL:</span>
                          <span className="text-white font-bold">${sol.estimatedTotalCostUsd.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-[#888]">
                          <span>LOCKED STRIKE:</span>
                          <span className="text-[#00E5FF] font-bold">${sol.strikeLockRecommendedPrice?.toFixed(2) ?? '0.00'}/hr</span>
                        </div>
                        <div className="flex justify-between text-[#888]">
                          <span>GREEN ENERGY:</span>
                          <span className="text-[#00FF41] font-bold">{sol.greenScore}%</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Selected Solution Full Lock Actions */}
              {solutions[selectedSolutionIndex] && (
                <div className="bg-[#050505] border border-[#222] rounded p-4 space-y-3 font-mono">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-[#00FF41]" />
                      <span className="text-white font-bold">
                        Selected: {solutions[selectedSolutionIndex].recommendedGpuCount}× {solutions[selectedSolutionIndex].gpuModel} at {solutions[selectedSolutionIndex].facilityName}
                      </span>
                    </div>
                    <span className="text-[#00E5FF] font-bold">
                      Escrow: ${solutions[selectedSolutionIndex].estimatedTotalCostUsd.toLocaleString()} USD
                    </span>
                  </div>

                  {lockFeedback && (
                    <div className="p-2.5 rounded bg-[#001A1D] border border-[#00E5FF] text-[#00E5FF] text-xs">
                      {lockFeedback}
                    </div>
                  )}

                  <button
                    onClick={handleLockSelectedSolution}
                    disabled={isLocking}
                    className="w-full py-3 rounded bg-[#00E5FF] hover:bg-[#00cce6] text-[#050505] text-xs font-bold transition shadow-[0_0_12px_rgba(0,229,255,0.3)] flex items-center justify-center gap-2 uppercase tracking-wider"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>{isLocking ? 'ALLOCATING CAPACITY...' : `Lock Contract & Escrow Capacity`}</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
