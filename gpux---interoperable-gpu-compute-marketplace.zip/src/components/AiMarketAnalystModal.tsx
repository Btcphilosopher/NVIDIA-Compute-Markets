import React, { useState } from 'react';
import { 
  Sparkles, 
  X, 
  Send, 
  Bot, 
  TrendingUp, 
  ShieldCheck, 
  Layers,
  Cpu
} from 'lucide-react';
import { MacroScenario, SpotMarketState } from '../types/market.js';

interface AiMarketAnalystModalProps {
  isOpen: boolean;
  onClose: () => void;
  markets: SpotMarketState[];
  activeScenario: string;
}

export const AiMarketAnalystModal: React.FC<AiMarketAnalystModalProps> = ({
  isOpen,
  onClose,
  markets,
  activeScenario
}) => {
  const [query, setQuery] = useState<string>(
    'How should an AI lab hedge compute costs for an upcoming 6-month pretraining run on 512x H100s given current forward curve contango and power tariffs?'
  );
  const [analysisText, setAnalysisText] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleRunAnalysis = async (customQuery?: string) => {
    const q = customQuery || query;
    setIsLoading(true);
    try {
      const res = await fetch('/api/ai/analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userQuery: q,
          marketContext: {
            activeScenario,
            topMarkets: markets.map(m => ({
              gpu: m.gpuModel,
              lastPrice: m.lastPrice,
              change24hPct: m.priceChange24hPct
            }))
          }
        })
      });
      const data = await res.json();
      setAnalysisText(data.analysis || 'Analysis received.');
    } catch (err: any) {
      setAnalysisText(`Analysis error: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    if (isOpen && !analysisText) {
      handleRunAnalysis();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div id="ai-analyst-modal" className="fixed inset-0 z-50 bg-[#050505]/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0A0A0A] border border-[#222] rounded-xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden text-[#D1D1D1] font-sans">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#222] flex items-center justify-between bg-[#050505]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-[#001A1D] border border-[#00E5FF] flex items-center justify-center text-[#00E5FF]">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-base text-white flex items-center gap-2 font-mono">
                GPUX AI Quantitative Market Strategist
                <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#001A1D] text-[#00E5FF] border border-[#00E5FF]/40 uppercase tracking-wider">
                  GEMINI 2.5 FLASH QUANT ENGINE
                </span>
              </h2>
              <p className="text-xs text-[#888] font-mono">
                Autonomous quantitative market analysis, volatility forecasting, and strike hedging advisor.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-[#1A1A1A] text-[#888] hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {/* Quick Prompts */}
          <div className="flex flex-wrap gap-2 text-xs font-mono">
            <span className="text-[#666] text-[10px] self-center uppercase tracking-wider">STRATEGY QUERIES:</span>
            <button
              type="button"
              onClick={() => {
                const q = 'Should we lock 1-year forward H100 contracts today or trade spot given expected Blackwell B200 supply ramp?';
                setQuery(q);
                handleRunAnalysis(q);
              }}
              className="px-2.5 py-1 rounded bg-[#050505] border border-[#222] text-[#888] hover:border-[#00E5FF] hover:text-[#00E5FF] text-[10px]"
            >
              H100 Lock vs B200 Ramp
            </button>
            <button
              type="button"
              onClick={() => {
                const q = 'Analyze the cost-of-capacity floor breakdown for zero-carbon geothermal facilities in the Nordics.';
                setQuery(q);
                handleRunAnalysis(q);
              }}
              className="px-2.5 py-1 rounded bg-[#050505] border border-[#222] text-[#888] hover:border-[#00E5FF] hover:text-[#00E5FF] text-[10px]"
            >
              Nordics Zero-Carbon Floor
            </button>
            <button
              type="button"
              onClick={() => {
                const q = 'Explain how Proof-of-Compute cryptographic slashing protects against DCGM thermal throttling in multi-node clusters.';
                setQuery(q);
                handleRunAnalysis(q);
              }}
              className="px-2.5 py-1 rounded bg-[#050505] border border-[#222] text-[#888] hover:border-[#00E5FF] hover:text-[#00E5FF] text-[10px]"
            >
              Proof-of-Compute SLA Slashing
            </button>
          </div>

          {/* Response Window */}
          <div className="bg-[#050505] border border-[#222] rounded-lg p-5 min-h-[220px]">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-12 space-y-3 text-[#00E5FF]">
                <Sparkles className="w-8 h-8 animate-spin" />
                <span className="text-xs font-mono">Synthesizing quantitative market state & forward curves...</span>
              </div>
            ) : analysisText ? (
              <div className="prose prose-invert prose-sm max-w-none text-[#D1D1D1] text-xs font-mono leading-relaxed whitespace-pre-wrap">
                {analysisText}
              </div>
            ) : null}
          </div>

          {/* Prompt input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleRunAnalysis();
            }}
            className="flex items-center gap-2 font-mono"
          >
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ask the Quantitative Market Strategist about hedging, strikes, or forward volatility..."
              className="flex-1 bg-[#050505] border border-[#222] rounded px-4 py-2.5 text-xs text-white focus:border-[#00E5FF] focus:outline-none"
            />
            <button
              type="submit"
              disabled={isLoading}
              className="px-5 py-2.5 rounded bg-[#00E5FF] hover:bg-[#00cce6] text-[#050505] font-bold text-xs flex items-center gap-1.5 transition uppercase tracking-wider shadow-[0_0_12px_rgba(0,229,255,0.3)]"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Ask Quant</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
