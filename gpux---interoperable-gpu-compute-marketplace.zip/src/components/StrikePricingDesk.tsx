import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  TrendingUp, 
  ShieldCheck, 
  Clock, 
  DollarSign, 
  Calendar, 
  Cpu, 
  Play, 
  BarChart2,
  Lock,
  Layers
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend 
} from 'recharts';
import confetti from 'canvas-confetti';
import { 
  ForwardCurvePoint, 
  GpuCapability, 
  GpuModelId, 
  MonteCarloSummary, 
  SettlementMethod, 
  StrikeContract 
} from '../types/market.js';

interface StrikePricingDeskProps {
  selectedModel: GpuModelId;
  capabilities: Record<GpuModelId, GpuCapability>;
  onSelectModel: (model: GpuModelId) => void;
  contracts: StrikeContract[];
  onLockContract: (contract: any) => Promise<void>;
}

export const StrikePricingDesk: React.FC<StrikePricingDeskProps> = ({
  selectedModel,
  capabilities,
  onSelectModel,
  contracts,
  onLockContract
}) => {
  const cap = capabilities[selectedModel] || Object.values(capabilities)[0];

  const [forwardCurve, setForwardCurve] = useState<ForwardCurvePoint[]>([]);
  const [strikeSurface, setStrikeSurface] = useState<any[]>([]);
  const [monteCarlo, setMonteCarlo] = useState<MonteCarloSummary | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Contract Builder State
  const [executionDays, setExecutionDays] = useState<number>(14);
  const [strikePrice, setStrikePrice] = useState<number>(42.50);
  const [gpuQuantity, setGpuQuantity] = useState<number>(32);
  const [durationHours, setDurationHours] = useState<number>(24);
  const [settlementMethod, setSettlementMethod] = useState<SettlementMethod>('PHYSICAL_EXECUTION');
  const [performanceFloor, setPerformanceFloor] = useState<number>(95.0);
  const [availabilityFloor, setAvailabilityFloor] = useState<number>(99.5);
  const [buyerName, setBuyerName] = useState<string>('DeepSeek Frontier AI Lab');
  const [isMinting, setIsMinting] = useState<boolean>(false);
  const [mintSuccess, setMintSuccess] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      setIsLoading(true);
      try {
        const [fwdRes, surfRes, mcRes] = await Promise.all([
          fetch(`/api/forward/${selectedModel}`).then(r => r.json()),
          fetch(`/api/strike-surface/${selectedModel}`).then(r => r.json()),
          fetch('/api/monte-carlo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ gpuModel: selectedModel, daysToExecution: executionDays, simulationsCount: 1000 })
          }).then(r => r.json())
        ]);

        if (isMounted) {
          setForwardCurve(fwdRes.curve || []);
          setStrikeSurface(surfRes.surface || []);
          setMonteCarlo(mcRes);
          if (fwdRes?.curve?.[0]) {
            const spot = fwdRes.curve[0]?.forwardSpotPrice || 40.0;
            setStrikePrice(Number((spot * 1.02).toFixed(2)));
          }
        }
      } catch (err) {
        console.error('Error fetching pricing desk data:', err);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }
    loadData();
    return () => { isMounted = false; };
  }, [selectedModel, executionDays]);

  const handleMintContract = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsMinting(true);
    setMintSuccess(null);
    try {
      const execStart = new Date(Date.now() + executionDays * 86400000).toISOString();
      const execEnd = new Date(Date.now() + executionDays * 86400000 + durationHours * 3600000).toISOString();

      await onLockContract({
        gpuModel: selectedModel,
        gpuQuantity,
        executionStartTime: execStart,
        executionEndTime: execEnd,
        durationHours,
        strikePricePerGpuHour: strikePrice,
        settlementMethod,
        performanceFloorPct: performanceFloor,
        availabilityFloorPct: availabilityFloor,
        buyerName
      });

      confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
      setMintSuccess(`Compute Strike Contract successfully locked with Escrow!`);
      setTimeout(() => setMintSuccess(null), 5000);
    } catch (err: any) {
      setMintSuccess(`Mint failed: ${err.message}`);
    } finally {
      setIsMinting(false);
    }
  };

  const notionalValue = (gpuQuantity * durationHours * strikePrice).toFixed(2);
  const totalCu = (gpuQuantity * (cap?.baseGpuxCu || 1.0)).toFixed(1);

  const monteCarloChartData = monteCarlo?.samplePaths?.[0]?.points.map((p, idx) => {
    const item: any = { day: `Day ${p.day}`, spot: p.simulatedSpot, costFloor: p.simulatedCost };
    monteCarlo.samplePaths.slice(0, 8).forEach((path, pathIdx) => {
      if (path.points[idx]) {
        item[`sim_${pathIdx}`] = path.points[idx].simulatedSpot;
      }
    });
    return item;
  }) || [];

  return (
    <div id="strike-pricing-desk" className="p-4 space-y-4 text-[#D1D1D1] font-sans">
      {/* Top Banner with Model & Tenor Quick Switcher */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="text-xl font-black text-white font-mono flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#00E5FF]" />
              Forward Compute Curve & Strike Pricing Engine
            </div>
            <span className="px-2 py-0.5 rounded bg-[#001A1D] text-[#00E5FF] text-[9px] font-mono border border-[#00E5FF]/40 uppercase tracking-wider">
              BLACK-76 QUANT MODEL
            </span>
          </div>
          <p className="text-xs text-[#888] font-mono mt-1">
            Price future execution rights, calculate cost-of-capacity floors, and execute forward compute contracts.
          </p>
        </div>

        {/* Model Picker */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-[#666] font-mono uppercase tracking-wider">UNDERLYING:</span>
          <select
            value={selectedModel}
            onChange={(e) => onSelectModel(e.target.value as GpuModelId)}
            className="bg-[#050505] border border-[#222] text-white text-xs font-mono px-3 py-1.5 rounded focus:border-[#00E5FF] focus:outline-none cursor-pointer"
          >
            {(Object.keys(capabilities) as GpuModelId[]).map((k) => (
              <option key={k} value={k}>
                {capabilities[k]?.model || k} ({capabilities[k]?.baseGpuxCu} CU)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main 2-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 7 Columns: Forward Curve, Greeks & Monte Carlo Fan */}
        <div className="lg:col-span-7 space-y-4">
          {/* Forward Curve Chart */}
          <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5 text-[#00E5FF]" />
                  GPU Compute Forward Curve (Term Structure)
                </div>
                <p className="text-[11px] text-[#888] font-mono mt-0.5">
                  Expected capacity clearing price across tenors (Spot to 360D)
                </p>
              </div>

              <div className="text-right font-mono text-xs">
                <span className="text-[#666]">STRUCTURE: </span>
                <span className="text-[#00E5FF] font-bold">CONTANGO (+12.4% 1Y)</span>
              </div>
            </div>

            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={forwardCurve}>
                  <XAxis dataKey="tenor" stroke="#444" fontSize={9} fontFamily="monospace" />
                  <YAxis domain={['auto', 'auto']} stroke="#444" fontSize={9} fontFamily="monospace" tickFormatter={(v) => `$${v}`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#050505', borderColor: '#222', fontSize: '11px', fontFamily: 'monospace' }}
                    formatter={(v: any, name: any) => [
                      `$${Number(v).toFixed(2)}/hr`, 
                      name === 'forwardSpotPrice' ? 'Forward Price' : 'CapEx Cost Floor'
                    ]}
                  />
                  <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace' }} />
                  <Line 
                    type="monotone" 
                    dataKey="forwardSpotPrice" 
                    name="Forward Price"
                    stroke="#00E5FF" 
                    strokeWidth={2.5}
                    dot={{ fill: '#00E5FF', r: 3 }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="costOfCapacityFloor" 
                    name="CapEx Cost Floor"
                    stroke="#F27D26" 
                    strokeDasharray="4 4"
                    strokeWidth={1.5}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Monte Carlo 1,000 Path Fan Simulation */}
          <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-[#00E5FF]" />
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-[#666]">Monte Carlo Jump-Diffusion Fan</div>
                  <p className="text-[11px] text-[#888] font-mono">1,000 Trajectories with Shortage Shocks</p>
                </div>
              </div>

              {monteCarlo && (
                <div className="flex items-center gap-3 text-xs font-mono">
                  <div>P05: <span className="text-[#00FF41] font-bold">${monteCarlo.p05Strike}</span></div>
                  <div>MEAN: <span className="text-white font-bold">${monteCarlo.meanStrike}</span></div>
                  <div>P95: <span className="text-[#FF4444] font-bold">${monteCarlo.p95Strike}</span></div>
                </div>
              )}
            </div>

            <div className="h-52 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monteCarloChartData}>
                  <XAxis dataKey="day" stroke="#444" fontSize={9} fontFamily="monospace" />
                  <YAxis domain={['auto', 'auto']} stroke="#444" fontSize={9} fontFamily="monospace" tickFormatter={(v) => `$${v}`} />
                  <Tooltip contentStyle={{ backgroundColor: '#050505', borderColor: '#222', fontSize: '11px', fontFamily: 'monospace' }} />
                  {monteCarlo?.samplePaths.slice(0, 6).map((path, pIdx) => (
                    <Line
                      key={path.pathIndex}
                      type="monotone"
                      dataKey={`sim_${pIdx}`}
                      stroke={pIdx === 0 ? '#00E5FF' : pIdx % 2 === 0 ? '#00FF41' : '#F27D26'}
                      strokeWidth={1.2}
                      strokeOpacity={0.7}
                      dot={false}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Quantitative Greeks Bar */}
            {monteCarlo && (
              <div className="grid grid-cols-4 gap-2 mt-3 pt-3 border-t border-[#1A1A1A] text-xs font-mono text-center">
                <div className="bg-[#050505] p-2 rounded border border-[#222]">
                  <div className="text-[#666] text-[9px] uppercase">DELTA (Δ)</div>
                  <div className="text-[#00E5FF] font-bold">{monteCarlo.delta?.toFixed(3) ?? '0.000'}</div>
                </div>
                <div className="bg-[#050505] p-2 rounded border border-[#222]">
                  <div className="text-[#666] text-[9px] uppercase">GAMMA (Γ)</div>
                  <div className="text-[#00FF41] font-bold">{monteCarlo.gamma?.toFixed(4) ?? '0.0000'}</div>
                </div>
                <div className="bg-[#050505] p-2 rounded border border-[#222]">
                  <div className="text-[#666] text-[9px] uppercase">VEGA (ν)</div>
                  <div className="text-[#F27D26] font-bold">{monteCarlo.vega?.toFixed(3) ?? '0.000'}</div>
                </div>
                <div className="bg-[#050505] p-2 rounded border border-[#222]">
                  <div className="text-[#666] text-[9px] uppercase">THETA (Θ)</div>
                  <div className="text-[#FF4444] font-bold">{monteCarlo.theta?.toFixed(3) ?? '0.000'}</div>
                </div>
              </div>
            )}
          </div>

          {/* 3D / 2D Strike Volatility Surface Table */}
          <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-[#00E5FF]" />
                Strike Volatility Matrix
              </div>
              <span className="text-[9px] text-[#666] font-mono uppercase">Tenor × Moneyness</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-[11px] font-mono text-left">
                <thead>
                  <tr className="text-[#555] border-b border-[#1A1A1A] text-[9px] uppercase">
                    <th className="pb-2">TENOR</th>
                    <th className="pb-2">STRIKE ($)</th>
                    <th className="pb-2">MONEYNESS</th>
                    <th className="pb-2">PREMIUM ($/HR)</th>
                    <th className="pb-2">IMPLIED VOL (IV)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1A1A1A]">
                  {(strikeSurface || []).slice(0, 6).map((s, idx) => (
                    <tr key={idx} className="hover:bg-[#111]">
                      <td className="py-1.5 text-white font-bold">{s.tenor || '14D'}</td>
                      <td className="py-1.5 text-[#D1D1D1]">${s.strike?.toFixed(2) ?? '0.00'}</td>
                      <td className="py-1.5 text-[#888]">{((s.moneyness || 0) * 100).toFixed(0)}%</td>
                      <td className="py-1.5 text-[#00E5FF] font-bold">${s.premium?.toFixed(2) ?? '0.00'}</td>
                      <td className="py-1.5 text-[#F27D26] font-bold">{s.iv?.toFixed(1) ?? '0.0'}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right 5 Columns: Interactive Compute Strike Contract Builder */}
        <div className="lg:col-span-5 bg-[#0A0A0A] border border-[#222] rounded-lg p-4 flex flex-col justify-between">
          <form onSubmit={handleMintContract} className="space-y-4">
            <div className="flex items-center justify-between border-b border-[#222] pb-2">
              <div>
                <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-[#00E5FF]" />
                  Mint Compute Strike Contract
                </div>
                <p className="text-[11px] text-[#888] font-mono">Lock guaranteed execution capacity with smart contract escrow</p>
              </div>
              <span className="text-[9px] px-2 py-0.5 rounded bg-[#001A1D] text-[#00E5FF] font-mono border border-[#00E5FF]/40 uppercase tracking-wider">
                FORWARD ASSET
              </span>
            </div>

            {/* Execution Window */}
            <div>
              <div className="flex justify-between text-xs mb-1 font-mono">
                <span className="text-[#888]">EXECUTION DATE:</span>
                <span className="text-white font-bold">
                  +{executionDays} Days ({new Date(Date.now() + executionDays * 86400000).toLocaleDateString()})
                </span>
              </div>
              <div className="grid grid-cols-4 gap-1 mb-1 font-mono text-xs">
                {[7, 14, 30, 90].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setExecutionDays(d)}
                    className={`py-1 rounded border text-[10px] font-bold ${
                      executionDays === d
                        ? 'bg-[#001A1D] border-[#00E5FF] text-[#00E5FF]'
                        : 'bg-[#111] border-[#222] text-[#888] hover:bg-[#1A1A1A]'
                    }`}
                  >
                    {d}D
                  </button>
                ))}
              </div>
              <input
                type="range"
                min="1"
                max="180"
                value={executionDays}
                onChange={(e) => setExecutionDays(Number(e.target.value))}
                className="w-full accent-[#00E5FF] cursor-pointer"
              />
            </div>

            {/* GPU Quantity & Duration */}
            <div className="grid grid-cols-2 gap-3 font-mono">
              <div>
                <span className="block text-[#888] text-[10px] uppercase mb-1">GPU QUANTITY:</span>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    max="512"
                    value={gpuQuantity}
                    onChange={(e) => setGpuQuantity(Number(e.target.value))}
                    className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-xs text-white focus:border-[#00E5FF] focus:outline-none"
                  />
                  <span className="absolute right-3 top-1.5 text-[9px] text-[#666]">
                    {totalCu} CU
                  </span>
                </div>
              </div>

              <div>
                <span className="block text-[#888] text-[10px] uppercase mb-1">DURATION (HOURS):</span>
                <input
                  type="number"
                  min="1"
                  max="720"
                  value={durationHours}
                  onChange={(e) => setDurationHours(Number(e.target.value))}
                  className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-xs text-white focus:border-[#00E5FF] focus:outline-none"
                />
              </div>
            </div>

            {/* Locked Strike Price */}
            <div>
              <div className="flex justify-between text-xs mb-1 font-mono">
                <span className="text-[#888]">LOCKED STRIKE PRICE:</span>
                <span className="text-[#00E5FF] font-bold">${Number(strikePrice).toFixed(2)}/hr</span>
              </div>
              <div className="relative font-mono">
                <span className="absolute left-3 top-2 text-[#666] text-xs">$</span>
                <input
                  type="number"
                  step="0.25"
                  min="1"
                  value={strikePrice}
                  onChange={(e) => setStrikePrice(Number(e.target.value))}
                  className="w-full bg-[#050505] border border-[#222] rounded pl-7 pr-3 py-1.5 text-xs text-white focus:border-[#00E5FF] focus:outline-none"
                />
              </div>
            </div>

            {/* Settlement Method Choice */}
            <div>
              <div className="text-[10px] uppercase tracking-widest text-[#666] mb-1 font-mono">
                SETTLEMENT METHOD:
              </div>
              <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                <button
                  type="button"
                  onClick={() => setSettlementMethod('PHYSICAL_EXECUTION')}
                  className={`p-2.5 rounded border text-left transition ${
                    settlementMethod === 'PHYSICAL_EXECUTION'
                      ? 'bg-[#001A1D] border-[#00E5FF] text-[#00E5FF] shadow-[0_0_10px_rgba(0,229,255,0.2)]'
                      : 'bg-[#050505] border-[#222] text-[#666] hover:border-[#333]'
                  }`}
                >
                  <div className="font-bold text-xs uppercase">Physical Delivery</div>
                  <div className="text-[9px] text-[#888] mt-0.5">Direct GPU cluster allocation</div>
                </button>

                <button
                  type="button"
                  onClick={() => setSettlementMethod('CASH_SETTLEMENT')}
                  className={`p-2.5 rounded border text-left transition ${
                    settlementMethod === 'CASH_SETTLEMENT'
                      ? 'bg-[#221200] border-[#F27D26] text-[#F27D26] shadow-[0_0_10px_rgba(242,125,38,0.2)]'
                      : 'bg-[#050505] border-[#222] text-[#666] hover:border-[#333]'
                  }`}
                >
                  <div className="font-bold text-xs uppercase">Cash Settlement</div>
                  <div className="text-[9px] text-[#888] mt-0.5">Financial delta payout</div>
                </button>
              </div>
            </div>

            {/* SLA Floors */}
            <div className="grid grid-cols-2 gap-3 font-mono text-xs">
              <div>
                <span className="block text-[#888] text-[9px] uppercase mb-1">PERFORMANCE FLOOR:</span>
                <select
                  value={performanceFloor}
                  onChange={(e) => setPerformanceFloor(Number(e.target.value))}
                  className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-xs text-white focus:border-[#00E5FF] focus:outline-none"
                >
                  <option value={95.0}>≥ 95.0% Benchmark</option>
                  <option value={98.0}>≥ 98.0% Strict SLA</option>
                </select>
              </div>

              <div>
                <span className="block text-[#888] text-[9px] uppercase mb-1">AVAILABILITY FLOOR:</span>
                <select
                  value={availabilityFloor}
                  onChange={(e) => setAvailabilityFloor(Number(e.target.value))}
                  className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-xs text-white focus:border-[#00E5FF] focus:outline-none"
                >
                  <option value={99.0}>≥ 99.0% Uptime</option>
                  <option value={99.5}>≥ 99.5% Uptime</option>
                </select>
              </div>
            </div>

            {/* Buyer Organization */}
            <div>
              <div className="text-[9px] uppercase tracking-widest text-[#666] mb-1 font-mono">
                ORGANIZATION / BENEFICIARY
              </div>
              <input
                type="text"
                value={buyerName}
                onChange={(e) => setBuyerName(e.target.value)}
                className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-xs text-white font-mono focus:border-[#00E5FF] focus:outline-none"
              />
            </div>

            {/* Notional & Escrow Summary */}
            <div className="bg-[#050505] border border-[#222] rounded p-3 space-y-1 text-xs font-mono">
              <div className="flex justify-between text-[#888]">
                <span>COMPUTE ASSET:</span>
                <span className="text-white font-bold">{gpuQuantity} × {cap?.model} ({totalCu} CU)</span>
              </div>
              <div className="flex justify-between text-[#888]">
                <span>ESCROW LOCKED TOTAL:</span>
                <span className="text-[#00E5FF] font-bold text-sm drop-shadow-[0_0_8px_rgba(0,229,255,0.3)]">${notionalValue} USD</span>
              </div>
            </div>

            {mintSuccess && (
              <div className="p-2.5 rounded bg-[#001A1D] border border-[#00E5FF] text-[#00E5FF] text-xs font-mono flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#00E5FF] flex-shrink-0" />
                <span>{mintSuccess}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isMinting}
              className="w-full py-3 rounded bg-[#00E5FF] hover:bg-[#00cce6] text-[#050505] text-xs font-mono font-bold transition shadow-[0_0_12px_rgba(0,229,255,0.3)] flex items-center justify-center gap-2 uppercase tracking-wider"
            >
              <Lock className="w-4 h-4" />
              <span>{isMinting ? 'MINTING ESCROW...' : `Lock Contract ($${notionalValue})`}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
