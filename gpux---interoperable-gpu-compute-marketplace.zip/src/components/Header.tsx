import React from 'react';
import { 
  Zap, 
  Activity, 
  Layers, 
  TrendingUp, 
  ShieldCheck, 
  Cpu, 
  Clock, 
  Sliders, 
  Sparkles,
  Server,
  FileCode2,
  Database
} from 'lucide-react';
import { GpuxIndex, MacroScenario, SpotMarketState } from '../types/market.js';

interface HeaderProps {
  markets: SpotMarketState[];
  indices: GpuxIndex[];
  activeScenario: string;
  scenarios: MacroScenario[];
  onSelectScenario: (key: string) => void;
  onStepTime: (unit: '1D' | '1W' | '1M' | '1Y') => void;
  onOpenSolver: () => void;
  onOpenAiAnalyst: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  markets,
  indices,
  activeScenario,
  scenarios,
  onSelectScenario,
  onStepTime,
  onOpenSolver,
  onOpenAiAnalyst,
  activeTab,
  setActiveTab
}) => {
  const currentScenarioObj = scenarios.find(s => s.key === activeScenario) || scenarios[0];
  const globalIndex = indices.find(i => i.symbol === 'GPUX-GLOBAL-100') || indices[0];

  return (
    <header id="gpux-main-header" className="bg-[#0A0A0A] border-b border-[#222] text-[#D1D1D1] sticky top-0 z-40">
      {/* Top Real-time Marquee Ticker Bar */}
      <div id="gpux-ticker-tape" className="bg-[#050505] px-6 py-2 text-[10px] border-b border-[#1A1A1A] flex items-center justify-between overflow-x-auto gap-6 whitespace-nowrap scrollbar-none font-mono">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-[#00FF41] font-bold tracking-widest uppercase">
            <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse"></span>
            GPUX MAINNET
          </div>

          <div className="h-4 w-[1px] bg-[#333]"></div>

          {globalIndex && (
            <div className="flex items-center gap-2 pr-4 border-r border-[#222]">
              <span className="text-[#666] uppercase tracking-wider">GPUX-100:</span>
              <span className="text-white font-bold">${globalIndex.value?.toFixed(2) ?? '0.00'}</span>
              <span className={(globalIndex.change24hPct || 0) >= 0 ? 'text-[#00FF41]' : 'text-[#FF4444]'}>
                {(globalIndex.change24hPct || 0) >= 0 ? '+' : ''}{globalIndex.change24hPct?.toFixed(1) ?? '0.0'}%
              </span>
            </div>
          )}

          {(markets || []).slice(0, 6).map((m) => {
            const isPos = (m.priceChange24hPct || 0) >= 0;
            return (
              <div key={m.gpuModel} className="flex items-center gap-2 border-r border-[#222] pr-4">
                <span className="text-[#777] uppercase">{m.gpuModel ? m.gpuModel.replace('_SXM5', '').replace('_SXM4_80GB', '') : 'GPU'}:</span>
                <span className="text-white font-bold">${m.lastPrice?.toFixed(2) ?? '0.00'}/hr</span>
                <span className={isPos ? 'text-[#00FF41]' : 'text-[#FF4444]'}>
                  {isPos ? '▲' : '▼'} {Math.abs(m.priceChange24hPct || 0).toFixed(1)}%
                </span>
              </div>
            );
          })}
        </div>

        <div className="flex items-center gap-5 text-[10px] uppercase tracking-wider">
          <div className="flex items-center gap-1.5">
            <span className="text-[#666]">UTIL:</span>
            <span className="text-[#00FF41] font-bold">82.4%</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[#666]">PUE:</span>
            <span className="text-[#00E5FF] font-bold">1.14</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[#666]">ESCROW:</span>
            <span className="text-[#F27D26] font-bold">$248.9K</span>
          </div>
        </div>
      </div>

      {/* Main Terminal Command Navigation */}
      <div className="px-6 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Left Branding */}
        <div className="flex items-center gap-4">
          <div className="text-2xl font-black tracking-tighter text-[#00E5FF] drop-shadow-[0_0_15px_rgba(0,229,255,0.4)] flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-[#001A1D] border border-[#00E5FF] flex items-center justify-center shadow-[0_0_10px_rgba(0,229,255,0.3)]">
              <Zap className="w-4 h-4 text-[#00E5FF] fill-[#00E5FF]" />
            </div>
            GPUX
          </div>

          <div className="h-6 w-[1px] bg-[#333]"></div>

          <div className="hidden sm:flex flex-col">
            <span className="text-[11px] font-bold text-white tracking-wider uppercase">
              Compute Commodity Marketplace
            </span>
            <span className="text-[9px] font-mono text-[#666] uppercase tracking-widest">
              Spot • Strike • DCGM • On-Chain Settlement
            </span>
          </div>
        </div>

        {/* Center Navigation Tabs */}
        <nav id="gpux-nav-tabs" className="flex items-center bg-[#050505] p-1 rounded-lg border border-[#222] font-mono text-[11px]">
          {[
            { id: 'spot', label: 'Spot & Book', icon: TrendingUp },
            { id: 'strike', label: 'Strike & Fwd', icon: Activity },
            { id: 'solver', label: 'Router', icon: Cpu },
            { id: 'topology', label: 'Topology', icon: Database },
            { id: 'telemetry', label: 'DCGM', icon: Server },
            { id: 'settlement', label: 'Settlement', icon: ShieldCheck },
            { id: 'scenarios', label: 'Sandbox', icon: Sliders },
            { id: 'indices', label: 'Indices', icon: Layers },
            { id: 'api', label: 'API / Rust', icon: FileCode2 },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`nav-tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all uppercase tracking-wider ${
                  isActive
                    ? 'bg-[#001A1D] border border-[#00E5FF] text-[#00E5FF] font-bold shadow-[0_0_10px_rgba(0,229,255,0.25)]'
                    : 'text-[#777] hover:text-[#D1D1D1] hover:bg-[#111]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Controls: Scenario Picker, Fast Time Step, AI Assistant, Workload Solver */}
        <div className="flex items-center gap-2.5">
          {/* Status Badges */}
          <div className="hidden xl:flex items-center gap-2">
            <div className="px-2.5 py-1 bg-[#1A1A1A] border border-[#333] rounded text-[9px] font-mono text-[#00E5FF] uppercase tracking-wider">
              RUST_ENGINE::STABLE
            </div>
            <div className="px-2.5 py-1 bg-[#221200] border border-[#F27D26] rounded text-[9px] font-mono text-[#F27D26] shadow-[0_0_8px_rgba(242,125,38,0.2)] uppercase tracking-wider">
              SETTLEMENT_ACTIVE
            </div>
          </div>

          {/* Active Scenario Selector */}
          <div className="flex items-center gap-1.5 bg-[#050505] px-2.5 py-1 rounded border border-[#222] text-xs">
            <Sliders className="w-3.5 h-3.5 text-[#F27D26]" />
            <select
              id="macro-scenario-dropdown"
              value={activeScenario}
              onChange={(e) => onSelectScenario(e.target.value)}
              className="bg-transparent text-slate-200 text-xs font-mono focus:outline-none cursor-pointer max-w-[150px] truncate"
            >
              {scenarios.map((s) => (
                <option key={s.key} value={s.key} className="bg-[#0A0A0A] text-white">
                  {s.title}
                </option>
              ))}
            </select>
          </div>

          {/* Time Stepper */}
          <div className="hidden lg:flex items-center gap-1 bg-[#050505] p-1 rounded border border-[#222] text-xs font-mono">
            <Clock className="w-3 h-3 text-[#666] ml-1" />
            <span className="text-[9px] text-[#666] pr-1 uppercase">STEP:</span>
            {(['1D', '1W', '1M', '1Y'] as const).map((unit) => (
              <button
                key={unit}
                id={`time-step-${unit}`}
                onClick={() => onStepTime(unit)}
                className="px-1.5 py-0.5 rounded bg-[#1A1A1A] text-[#888] hover:bg-[#00E5FF] hover:text-[#050505] transition text-[10px] font-bold"
                title={`Advance simulation time by ${unit}`}
              >
                {unit}
              </button>
            ))}
          </div>

          {/* AI Quantitative Analyst Button */}
          <button
            id="ai-analyst-btn"
            onClick={onOpenAiAnalyst}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#0A1A24] text-[#00E5FF] border border-[#00E5FF]/40 hover:bg-[#00E5FF]/20 transition text-xs font-mono font-bold"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span>AI QUANT</span>
          </button>

          {/* Workload Solver CTA */}
          <button
            id="open-workload-solver-btn"
            onClick={onOpenSolver}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded bg-[#00E5FF] text-[#050505] hover:bg-[#00cce6] transition text-xs font-mono font-bold shadow-[0_0_12px_rgba(0,229,255,0.35)] uppercase tracking-wider"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Quote Workload</span>
          </button>
        </div>
      </div>

      {/* Scenario Brief Banner if active */}
      {currentScenarioObj && currentScenarioObj.key !== 'BASE_MARKET' && (
        <div id="active-scenario-alert-banner" className="bg-[#221200] border-t border-[#F27D26]/50 px-6 py-1.5 text-xs text-[#F27D26] flex items-center justify-between font-mono">
          <div className="flex items-center gap-2">
            <span className="px-1.5 py-0.2 rounded bg-[#F27D26] text-[#050505] font-bold text-[9px] uppercase tracking-wider">
              SIMULATION ACTIVE
            </span>
            <span className="font-bold text-white">{currentScenarioObj.title}:</span>
            <span className="text-[#D1D1D1]/90">{currentScenarioObj.narrative}</span>
          </div>
          <button 
            onClick={() => onSelectScenario('BASE_MARKET')}
            className="text-[10px] underline text-[#00E5FF] hover:text-white uppercase tracking-wider"
          >
            Reset to Baseline
          </button>
        </div>
      )}
    </header>
  );
};
