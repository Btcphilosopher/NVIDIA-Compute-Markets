import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Layers, 
  Lock, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  ExternalLink, 
  Key, 
  Clock,
  ArrowRight,
  Database
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { BlockchainBlock, ProofOfCompute, StrikeContract } from '../types/market.js';

interface BlockchainSettlementProps {
  contracts: StrikeContract[];
  proofs: ProofOfCompute[];
  blocks: BlockchainBlock[];
  onTriggerSettlement: (contractId: string, proofId: string) => Promise<void>;
  onGenerateProof: (params: any) => Promise<ProofOfCompute>;
}

export const BlockchainSettlement: React.FC<BlockchainSettlementProps> = ({
  contracts,
  proofs,
  blocks,
  onTriggerSettlement,
  onGenerateProof
}) => {
  const [selectedContractId, setSelectedContractId] = useState<string>(contracts[0]?.id || '');
  const [isSettling, setIsSettling] = useState<boolean>(false);
  const [settleFeedback, setSettleFeedback] = useState<string | null>(null);

  const selectedContract = contracts.find(c => c.id === selectedContractId) || contracts[0];
  const relatedProofs = proofs.filter(p => p.contractId === selectedContract?.id);
  const latestProof = relatedProofs[relatedProofs.length - 1];

  const handleSettle = async () => {
    if (!selectedContract || !latestProof) return;
    setIsSettling(true);
    setSettleFeedback(null);
    try {
      await onTriggerSettlement(selectedContract.id, latestProof.id);
      confetti({ particleCount: 70, spread: 50, origin: { y: 0.7 } });
      setSettleFeedback(`Contract settled on-chain! Block minted with PoC Merkle verification.`);
      setTimeout(() => setSettleFeedback(null), 5000);
    } catch (err: any) {
      setSettleFeedback(`Settlement failed: ${err.message}`);
    } finally {
      setIsSettling(false);
    }
  };

  return (
    <div id="blockchain-settlement-desk" className="p-4 space-y-4 text-[#D1D1D1] font-sans">
      {/* Top Banner */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="text-xl font-black text-white font-mono flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#00E5FF]" />
              Verifiable Proof-of-Compute & Settlement Ledger
            </div>
            <span className="px-2 py-0.5 rounded bg-[#001A1D] text-[#00E5FF] text-[9px] font-mono border border-[#00E5FF]/40 uppercase tracking-wider">
              ON-CHAIN ESCROW ENGINE
            </span>
          </div>
          <p className="text-xs text-[#888] font-mono mt-1">
            Cryptographic verification of GPU workloads via DCGM Merkle roots, automated escrow release, and SLA slashing.
          </p>
        </div>

        {/* Status Indicators */}
        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="px-3 py-1.5 rounded bg-[#050505] border border-[#222] text-[#00E5FF]">
            {blocks.length} Finalized Blocks
          </div>
          <div className="px-3 py-1.5 rounded bg-[#221200] border border-[#F27D26] text-[#F27D26]">
            {contracts.filter(c => c.status === 'ESCROW_LOCKED').length} Active Escrows
          </div>
        </div>
      </div>

      {/* Main Grid: Contracts & Settlement Action (Left 7) & Blockchain Ledger (Right 5) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Contracts & PoC Verification Details */}
        <div className="lg:col-span-7 space-y-4">
          {/* Contracts List */}
          <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 space-y-3">
            <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center justify-between">
              <span>ACTIVE COMPUTE STRIKE CONTRACTS</span>
              <span className="text-[#00E5FF] font-mono">{contracts.length} Total Contracts</span>
            </div>

            <div className="space-y-2 max-h-72 overflow-y-auto pr-1 scrollbar-thin">
              {contracts.map((c) => {
                const isSelected = c.id === selectedContractId;
                const isSettled = c.status === 'SETTLED_RELEASED';
                const isSlashed = c.status === 'SLA_SLASHED_REFUND';
                const escrowVal = c.escrowLockedUsd || c.notionalValueUsd || 0;
                return (
                  <div
                    key={c.id}
                    onClick={() => setSelectedContractId(c.id)}
                    className={`p-3 rounded border transition cursor-pointer font-mono ${
                      isSelected
                        ? 'bg-[#001A1D] border-[#00E5FF] shadow-[0_0_10px_rgba(0,229,255,0.2)]'
                        : 'bg-[#050505] border-[#222] hover:border-[#333]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-white font-bold text-xs">{c.id}</span>
                        <span className="text-[#888] text-[10px]">({c.gpuQuantity}× {c.gpuModel})</span>
                      </div>

                      <span className={`text-[9px] px-2 py-0.5 rounded font-bold uppercase ${
                        isSettled
                          ? 'bg-[#002200] text-[#00FF41] border border-[#00FF41]/40'
                          : isSlashed
                          ? 'bg-[#220000] text-[#FF4444] border border-[#FF4444]/40'
                          : 'bg-[#221200] text-[#F27D26] border border-[#F27D26]/40'
                      }`}>
                        {c.status.replace(/_/g, ' ')}
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-2 mt-2 pt-2 border-t border-[#1A1A1A] text-[10px] text-[#888]">
                      <div>
                        <div className="text-[#666] text-[8px] uppercase">ESCROW</div>
                        <div className="text-[#00E5FF] font-bold">${escrowVal.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-[#666] text-[8px] uppercase">STRIKE</div>
                        <div className="text-white">${c.strikePricePerGpuHour?.toFixed(2) ?? '0.00'}/hr</div>
                      </div>
                      <div>
                        <div className="text-[#666] text-[8px] uppercase">SLA FLOOR</div>
                        <div className="text-[#00FF41]">{c.performanceFloorPct ?? 95}%</div>
                      </div>
                      <div>
                        <div className="text-[#666] text-[8px] uppercase">BUYER</div>
                        <div className="text-white truncate">{c.buyerName ? c.buyerName.split(' ')[0] : 'Buyer'}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Contract Proof-of-Compute Details */}
          {selectedContract && (
            <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 space-y-3 font-mono">
              <div className="flex items-center justify-between border-b border-[#222] pb-2">
                <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-[#00E5FF]" />
                  Cryptographic Proof & SLA Validation State
                </div>
                <span className="text-[9px] text-[#00E5FF]">Contract: {selectedContract.id}</span>
              </div>

              {latestProof ? (
                <div className="space-y-3">
                  <div className="bg-[#050505] p-3 rounded border border-[#222] space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-[#888]">Workload Execution Hash:</span>
                      <span className="text-[#00E5FF] truncate max-w-[280px]" title={latestProof.workloadSignatureSha256}>
                        {latestProof.workloadSignatureSha256}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#888]">DCGM Merkle Root:</span>
                      <span className="text-[#00E5FF] truncate max-w-[280px]" title={latestProof.telemetryMerkleRoot}>
                        {latestProof.telemetryMerkleRoot}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#888]">Achieved Performance:</span>
                      <span className={`font-bold ${(latestProof.deliveredPerformancePct || 0) >= (selectedContract?.performanceFloorPct || 95) ? 'text-[#00FF41]' : 'text-[#FF4444]'}`}>
                        {latestProof.deliveredPerformancePct?.toFixed(2) ?? '0.00'}% (Floor: {selectedContract?.performanceFloorPct ?? 95}%)
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#888]">Uptime Achieved:</span>
                      <span className="text-[#00FF41] font-bold">{latestProof.deliveredAvailabilityPct?.toFixed(2) ?? '0.00'}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#888]">Energy Telemetry:</span>
                      <span className="text-white">{latestProof.totalEnergyKwh?.toFixed(1) ?? '0.0'} kWh</span>
                    </div>
                  </div>

                  {settleFeedback && (
                    <div className="p-2.5 rounded bg-[#001A1D] border border-[#00E5FF] text-[#00E5FF] text-xs">
                      {settleFeedback}
                    </div>
                  )}

                  {selectedContract.status === 'ESCROW_LOCKED' && (
                    <button
                      onClick={handleSettle}
                      disabled={isSettling}
                      className="w-full py-3 rounded bg-[#00E5FF] hover:bg-[#00cce6] text-[#050505] text-xs font-bold transition shadow-[0_0_12px_rgba(0,229,255,0.3)] flex items-center justify-center gap-2 uppercase tracking-wider"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>{isSettling ? 'VERIFYING ON-CHAIN...' : `Trigger Settlement & Escrow Release ($${(selectedContract.escrowLockedUsd || selectedContract.notionalValueUsd || 0).toLocaleString()})`}</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="p-6 text-center text-xs text-[#666]">
                  Awaiting workload completion telemetry from DCGM oracle...
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Live Blockchain Explorer Blocks */}
        <div className="lg:col-span-5 bg-[#0A0A0A] border border-[#222] rounded-lg p-4 space-y-3 font-mono flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-[#222] pb-2">
              <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-[#00E5FF]" />
                On-Chain Blockchain Blocks
              </div>
              <span className="text-[9px] text-[#00FF41] bg-[#002200] px-2 py-0.5 rounded border border-[#00FF41]/40 uppercase font-bold">
                BLS12-381
              </span>
            </div>

            <div className="space-y-2 mt-3 max-h-[480px] overflow-y-auto pr-1 scrollbar-thin">
              {blocks.slice(0, 8).map((b) => (
                <div
                  key={b.blockNumber}
                  className="bg-[#050505] border border-[#222] rounded p-3 space-y-1 text-xs hover:border-[#333] transition"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-white font-bold">BLOCK #{b.blockNumber}</span>
                    <span className="text-[#666] text-[10px]">{new Date(b.timestamp).toLocaleTimeString()}</span>
                  </div>

                  <div className="text-[#888] text-[10px] flex justify-between">
                    <span>TX COUNT: <span className="text-white font-bold">{b.transactionsCount}</span></span>
                    <span>GAS: <span className="text-[#00E5FF]">{b.gasUsed}</span></span>
                  </div>

                  <div className="text-[9px] text-[#555] truncate pt-1 border-t border-[#1A1A1A]">
                    HASH: <span className="text-[#00E5FF]">{b.blockHash}</span>
                  </div>
                  <div className="text-[9px] text-[#555] truncate">
                    MERKLE: <span className="text-[#888]">{b.merkleRoot}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-3 rounded bg-[#050505] border border-[#222] text-[10px] text-[#666] flex items-center justify-between">
            <span>CONSENSUS: Proof-of-Compute + DCGM</span>
            <span className="text-[#00FF41] font-bold">STABLE</span>
          </div>
        </div>
      </div>
    </div>
  );
};
