import React, { useState, useEffect } from 'react';
import { 
  Server, 
  Activity, 
  Zap, 
  Thermometer, 
  ShieldAlert, 
  Cpu, 
  HardDrive, 
  CheckCircle2,
  RefreshCw,
  Clock
} from 'lucide-react';
import { DcgmTelemetryRollup } from '../types/market.js';

export const TelemetryDCGM: React.FC = () => {
  const [telemetryList, setTelemetryList] = useState<DcgmTelemetryRollup[]>([]);
  const [selectedNodeId, setSelectedNodeId] = useState<string>('node-cw-01');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchTelemetry = async () => {
    try {
      const res = await fetch('/api/telemetry');
      const data = await res.json();
      if (data.telemetry) {
        setTelemetryList(data.telemetry);
      }
    } catch (err) {
      console.error('Failed to fetch DCGM telemetry:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTelemetry();
    const interval = setInterval(fetchTelemetry, 3000);
    return () => clearInterval(interval);
  }, []);

  const activeTelemetry = telemetryList.find(t => t.nodeId === selectedNodeId) || telemetryList[0];

  return (
    <div id="telemetry-dcgm-desk" className="p-4 space-y-4 text-[#D1D1D1] font-sans">
      {/* Top Banner */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="text-xl font-black text-white font-mono flex items-center gap-2">
              <Server className="w-5 h-5 text-[#00E5FF]" />
              NVIDIA DCGM & NVML Physical Telemetry Engine
            </div>
            <span className="px-2 py-0.5 rounded bg-[#001A1D] text-[#00E5FF] text-[9px] font-mono border border-[#00E5FF]/40 uppercase tracking-wider">
              1000Hz HARDWARE METRICS
            </span>
          </div>
          <p className="text-xs text-[#888] font-mono mt-1">
            Real-time physical hardware metrics, thermal dissipation, memory bandwidth, throttling flags, and SLA verification.
          </p>
        </div>

        {/* Live Status indicator */}
        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded bg-[#050505] border border-[#222]">
            <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse"></span>
            <span className="text-white font-bold">DCGM ORACLE RUNNING</span>
          </div>
          <button
            onClick={fetchTelemetry}
            className="p-1.5 rounded bg-[#050505] border border-[#222] text-[#888] hover:text-white"
            title="Refresh metrics"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Layout: Node Selector (Left) & Deep Metrics Dashboard (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Node Selector List */}
        <div className="lg:col-span-4 bg-[#0A0A0A] border border-[#222] rounded-lg p-4 space-y-3">
          <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center justify-between">
            <span>ACTIVE CLUSTER RIGS</span>
            <span className="text-[#00E5FF] font-mono">{telemetryList.length} Nodes Online</span>
          </div>

          <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1 scrollbar-thin">
            {telemetryList.map((item) => {
              const isSelected = item.nodeId === selectedNodeId;
              const hasThrottling = item.thermalThrottleEvents > 0 || item.powerCapThrottleEvents > 0;
              return (
                <div
                  key={item.nodeId}
                  onClick={() => setSelectedNodeId(item.nodeId)}
                  className={`p-3 rounded border transition cursor-pointer font-mono ${
                    isSelected
                      ? 'bg-[#001A1D] border-[#00E5FF] shadow-[0_0_10px_rgba(0,229,255,0.2)]'
                      : 'bg-[#050505] border-[#222] hover:border-[#333]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="font-bold text-xs text-white">{item.nodeId}</div>
                    <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                      hasThrottling
                        ? 'bg-[#220000] text-[#FF4444] border border-[#FF4444]/40'
                        : 'bg-[#002200] text-[#00FF41] border border-[#00FF41]/40'
                    }`}>
                      {hasThrottling ? 'THROTTLED' : 'NOMINAL'}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-[#1A1A1A] text-[10px] text-[#888]">
                    <div>
                      <div className="text-[#666] text-[8px] uppercase">UTIL</div>
                      <div className="text-[#00FF41] font-bold">{item.avgGpuCoreUtilPct?.toFixed(1) ?? '0.0'}%</div>
                    </div>
                    <div>
                      <div className="text-[#666] text-[8px] uppercase">POWER</div>
                      <div className="text-[#F27D26] font-bold">{item.avgPowerDrawWatts?.toFixed(0) ?? '0'}W</div>
                    </div>
                    <div>
                      <div className="text-[#666] text-[8px] uppercase">TEMP</div>
                      <div className="text-white font-bold">{item.avgTemperatureCelsius?.toFixed(1) ?? '0.0'}°C</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Hardware Health & Physical Gauges */}
        <div className="lg:col-span-8 space-y-4">
          {activeTelemetry ? (
            <>
              {/* Primary Gauge Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 font-mono">
                {/* Core Util */}
                <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-3.5 space-y-2">
                  <div className="text-[9px] uppercase tracking-widest text-[#666] flex items-center justify-between">
                    <span>GPU CORE UTIL</span>
                    <Activity className="w-3.5 h-3.5 text-[#00FF41]" />
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {activeTelemetry.avgGpuCoreUtilPct?.toFixed(1) ?? '0.0'}%
                  </div>
                  <div className="w-full bg-[#1A1A1A] h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-[#00FF41] h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, activeTelemetry.avgGpuCoreUtilPct || 0)}%` }}
                    />
                  </div>
                </div>

                {/* Tensor Core Util */}
                <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-3.5 space-y-2">
                  <div className="text-[9px] uppercase tracking-widest text-[#666] flex items-center justify-between">
                    <span>TENSOR CORES (FP8)</span>
                    <Cpu className="w-3.5 h-3.5 text-[#00E5FF]" />
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {activeTelemetry.avgTensorCoreUtilPct?.toFixed(1) ?? '0.0'}%
                  </div>
                  <div className="w-full bg-[#1A1A1A] h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-[#00E5FF] h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, activeTelemetry.avgTensorCoreUtilPct || 0)}%` }}
                    />
                  </div>
                </div>

                {/* Power & Cost Draw */}
                <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-3.5 space-y-2">
                  <div className="text-[9px] uppercase tracking-widest text-[#666] flex items-center justify-between">
                    <span>POWER DRAW</span>
                    <Zap className="w-3.5 h-3.5 text-[#F27D26]" />
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {activeTelemetry.avgPowerDrawWatts?.toFixed(0) ?? '0'} W
                  </div>
                  <div className="text-[10px] text-[#F27D26]">
                    ${activeTelemetry.energyCostAccumulatedUsd?.toFixed(3) ?? '0.000'}/hr energy cost
                  </div>
                </div>

                {/* Temperature */}
                <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-3.5 space-y-2">
                  <div className="text-[9px] uppercase tracking-widest text-[#666] flex items-center justify-between">
                    <span>AVG THERMAL TEMP</span>
                    <Thermometer className="w-3.5 h-3.5 text-[#00E5FF]" />
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {activeTelemetry.avgTemperatureCelsius?.toFixed(1) ?? '0.0'} °C
                  </div>
                  <div className="text-[10px] text-[#00FF41]">
                    Threshold ceiling: 84°C
                  </div>
                </div>
              </div>

              {/* Memory Bandwidth & SLA Telemetry Breakdown */}
              <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 space-y-3 font-mono">
                <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center justify-between">
                  <span>HBM3e HIGH-BANDWIDTH MEMORY & INTERCONNECT</span>
                  <span className="text-[#00E5FF]">{activeTelemetry.memoryBandwidthUtilPct?.toFixed(1) ?? '0.0'}% Capacity</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="bg-[#050505] p-3 rounded border border-[#222]">
                    <div className="text-[#666] text-[9px] uppercase mb-1">VRAM ALLOCATION</div>
                    <div className="text-white font-bold">{activeTelemetry.vramUsedGb?.toFixed(1) ?? '0.0'} GB / 80.0 GB</div>
                  </div>
                  <div className="bg-[#050505] p-3 rounded border border-[#222]">
                    <div className="text-[#666] text-[9px] uppercase mb-1">NVLINK / PCIE RX/TX</div>
                    <div className="text-white font-bold">{activeTelemetry.pcieNvlinkThroughputGbs?.toFixed(1) ?? '0.0'} GB/s</div>
                  </div>
                  <div className="bg-[#050505] p-3 rounded border border-[#222]">
                    <div className="text-[#666] text-[9px] uppercase mb-1">DCGM MERKLE LEAF</div>
                    <div className="text-[#00E5FF] truncate" title={activeTelemetry.telemetryMerkleLeaf}>
                      {activeTelemetry.telemetryMerkleLeaf.slice(0, 16)}...
                    </div>
                  </div>
                </div>
              </div>

              {/* Hardware SLA Throttling Audit Box */}
              <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 font-mono space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-[#00E5FF]" />
                    Hardware SLA & Throttling Verification Oracle
                  </div>
                  <span className="text-[9px] text-[#00FF41] bg-[#002200] px-2 py-0.5 rounded border border-[#00FF41]/40 font-bold uppercase">
                    BLS-381 ORACLE COMPLIANT
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded bg-[#050505] border border-[#222] flex items-center justify-between">
                    <span className="text-[#888]">Thermal Throttling Events:</span>
                    <span className={`font-bold ${activeTelemetry.thermalThrottleEvents > 0 ? 'text-[#FF4444]' : 'text-[#00FF41]'}`}>
                      {activeTelemetry.thermalThrottleEvents} events
                    </span>
                  </div>
                  <div className="p-3 rounded bg-[#050505] border border-[#222] flex items-center justify-between">
                    <span className="text-[#888]">Power Cap Throttling Events:</span>
                    <span className={`font-bold ${activeTelemetry.powerCapThrottleEvents > 0 ? 'text-[#FF4444]' : 'text-[#00FF41]'}`}>
                      {activeTelemetry.powerCapThrottleEvents} events
                    </span>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="p-8 text-center text-xs font-mono text-[#666]">
              Loading DCGM telemetry stream...
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
