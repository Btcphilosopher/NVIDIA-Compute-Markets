import React, { useState, useEffect } from 'react';
import { 
  FileCode2, 
  Terminal, 
  Copy, 
  Check, 
  Play, 
  Layers, 
  Cpu, 
  Database,
  Code
} from 'lucide-react';

export const CodePlayground: React.FC = () => {
  const [activeLang, setActiveLang] = useState<'rust' | 'r' | 'rest'>('rust');
  const [rustCode, setRustCode] = useState<string>('');
  const [rCode, setRCode] = useState<string>('');
  const [apiEndpoint, setApiEndpoint] = useState<string>('/api/markets');
  const [apiResponse, setApiResponse] = useState<string>('');
  const [isLoadingApi, setIsLoadingApi] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    fetch('/api/rust-code').then(r => r.json()).then(d => setRustCode(d.code || ''));
    fetch('/api/r-code').then(r => r.json()).then(d => setRCode(d.code || ''));
  }, []);

  const handleRunApi = async () => {
    setIsLoadingApi(true);
    try {
      const res = await fetch(apiEndpoint);
      const data = await res.json();
      setApiResponse(JSON.stringify(data, null, 2));
    } catch (err: any) {
      setApiResponse(`Error calling API: ${err.message}`);
    } finally {
      setIsLoadingApi(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="code-playground-desk" className="p-4 space-y-4 text-[#D1D1D1] font-sans">
      {/* Top Banner */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="text-xl font-black text-white font-mono flex items-center gap-2">
              <FileCode2 className="w-5 h-5 text-[#00E5FF]" />
              GPUX Production Systems & Quantitative Modules
            </div>
            <span className="px-2 py-0.5 rounded bg-[#001A1D] text-[#00E5FF] text-[9px] font-mono border border-[#00E5FF]/40 uppercase tracking-wider">
              RUST • R • REST ENGINE
            </span>
          </div>
          <p className="text-xs text-[#888] font-mono mt-1">
            Explore native Rust blockchain matching kernels, R statistical forward volatility routines, and the live REST marketplace API.
          </p>
        </div>

        {/* Language Tabs */}
        <div className="flex items-center bg-[#050505] p-1 rounded border border-[#222] font-mono text-xs">
          <button
            onClick={() => setActiveLang('rust')}
            className={`px-3 py-1.5 rounded transition uppercase font-bold ${
              activeLang === 'rust'
                ? 'bg-[#001A1D] border border-[#00E5FF] text-[#00E5FF]'
                : 'text-[#666] hover:text-white'
            }`}
          >
            Rust Engine
          </button>
          <button
            onClick={() => setActiveLang('r')}
            className={`px-3 py-1.5 rounded transition uppercase font-bold ${
              activeLang === 'r'
                ? 'bg-[#221200] border border-[#F27D26] text-[#F27D26]'
                : 'text-[#666] hover:text-white'
            }`}
          >
            R Quant Model
          </button>
          <button
            onClick={() => setActiveLang('rest')}
            className={`px-3 py-1.5 rounded transition uppercase font-bold ${
              activeLang === 'rest'
                ? 'bg-[#002200] border border-[#00FF41] text-[#00FF41]'
                : 'text-[#666] hover:text-white'
            }`}
          >
            REST API
          </button>
        </div>
      </div>

      {/* Code Display or REST Playground */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 font-mono">
        {activeLang === 'rust' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs pb-2 border-b border-[#222]">
              <div className="flex items-center gap-2 text-white">
                <span className="w-2 h-2 rounded-full bg-[#00E5FF]"></span>
                <span>crates/gpux-core/src/matching_engine.rs (Rust 2024 Edition)</span>
              </div>
              <button
                onClick={() => handleCopy(rustCode)}
                className="flex items-center gap-1.5 text-xs text-[#888] hover:text-white bg-[#050505] px-2.5 py-1 rounded border border-[#222]"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-[#00FF41]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Code'}</span>
              </button>
            </div>
            <pre className="p-4 bg-[#050505] border border-[#1A1A1A] rounded-lg text-xs text-[#00E5FF] overflow-x-auto leading-relaxed max-h-[500px] scrollbar-thin">
              {rustCode}
            </pre>
          </div>
        )}

        {activeLang === 'r' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs pb-2 border-b border-[#222]">
              <div className="flex items-center gap-2 text-white">
                <span className="w-2 h-2 rounded-full bg-[#F27D26]"></span>
                <span>analytics/quant_volatility_black76.R (R Statistical Engine)</span>
              </div>
              <button
                onClick={() => handleCopy(rCode)}
                className="flex items-center gap-1.5 text-xs text-[#888] hover:text-white bg-[#050505] px-2.5 py-1 rounded border border-[#222]"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-[#00FF41]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Code'}</span>
              </button>
            </div>
            <pre className="p-4 bg-[#050505] border border-[#1A1A1A] rounded-lg text-xs text-[#F27D26] overflow-x-auto leading-relaxed max-h-[500px] scrollbar-thin">
              {rCode}
            </pre>
          </div>
        )}

        {activeLang === 'rest' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs pb-2 border-b border-[#222]">
              <div className="flex items-center gap-2 text-white">
                <span className="w-2 h-2 rounded-full bg-[#00FF41]"></span>
                <span>GPUX High-Frequency REST API Explorer</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-2.5 py-2 bg-[#002200] text-[#00FF41] border border-[#00FF41]/40 rounded text-xs font-bold">
                GET
              </span>
              <select
                value={apiEndpoint}
                onChange={(e) => setApiEndpoint(e.target.value)}
                className="flex-1 bg-[#050505] border border-[#222] text-white text-xs px-3 py-2 rounded focus:border-[#00E5FF] focus:outline-none"
              >
                <option value="/api/markets">/api/markets (Spot order books and prices)</option>
                <option value="/api/forward/H100_SXM5">/api/forward/H100_SXM5 (Term structure curve)</option>
                <option value="/api/telemetry">/api/telemetry (DCGM hardware metrics)</option>
                <option value="/api/contracts">/api/contracts (Active strike escrows)</option>
                <option value="/api/blockchain">/api/blockchain (On-chain blocks)</option>
                <option value="/api/indices">/api/indices (Benchmark basket indices)</option>
              </select>
              <button
                onClick={handleRunApi}
                disabled={isLoadingApi}
                className="px-5 py-2 bg-[#00FF41] hover:bg-[#00e63a] text-[#050505] font-bold text-xs rounded transition flex items-center gap-1.5 uppercase"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isLoadingApi ? 'SENDING...' : 'EXECUTE'}</span>
              </button>
            </div>

            {apiResponse && (
              <pre className="p-4 bg-[#050505] border border-[#1A1A1A] rounded-lg text-xs text-[#00FF41] overflow-x-auto leading-relaxed max-h-[420px] scrollbar-thin">
                {apiResponse}
              </pre>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
