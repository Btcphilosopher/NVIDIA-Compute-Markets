import React, { useState } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  ArrowUpRight, 
  ArrowDownRight, 
  Zap, 
  Cpu, 
  Layers, 
  ShieldCheck, 
  DollarSign,
  Activity,
  Server
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip 
} from 'recharts';
import { GpuCapability, GpuModelId, SpotMarketState } from '../types/market.js';

interface SpotMarketDeskProps {
  markets: SpotMarketState[];
  selectedModel: GpuModelId;
  onSelectModel: (model: GpuModelId) => void;
  capabilities: Record<GpuModelId, GpuCapability>;
  onPlaceOrder: (order: {
    side: 'BUY' | 'SELL';
    gpuModel: GpuModelId;
    quantityGpus: number;
    pricePerGpuHour: number;
    durationHours: number;
    creatorName: string;
  }) => Promise<void>;
  trades: { id: string; gpuModel: GpuModelId; quantity: number; price: number; timestamp: string; buyer: string; seller: string }[];
}

export const SpotMarketDesk: React.FC<SpotMarketDeskProps> = ({
  markets,
  selectedModel,
  onSelectModel,
  capabilities,
  onPlaceOrder,
  trades
}) => {
  const currentMarket = markets.find(m => m.gpuModel === selectedModel) || markets[0];
  const cap = capabilities[selectedModel] || Object.values(capabilities)[0];

  // Order Placement Form State
  const [orderSide, setOrderSide] = useState<'BUY' | 'SELL'>('BUY');
  const [quantity, setQuantity] = useState<number>(16);
  const [orderPrice, setOrderPrice] = useState<number>(currentMarket ? currentMarket.lastPrice : 42.0);
  const [duration, setDuration] = useState<number>(24);
  const [buyerName, setBuyerName] = useState<string>('Tier-1 AI Lab Trader');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [orderFeedback, setOrderFeedback] = useState<string | null>(null);

  React.useEffect(() => {
    if (currentMarket) {
      setOrderPrice(currentMarket.lastPrice);
    }
  }, [selectedModel, currentMarket?.lastPrice]);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setOrderFeedback(null);
    try {
      await onPlaceOrder({
        side: orderSide,
        gpuModel: selectedModel,
        quantityGpus: quantity,
        pricePerGpuHour: orderPrice,
        durationHours: duration,
        creatorName: buyerName
      });
      setOrderFeedback(`Order placed successfully! Matched against order book.`);
      setTimeout(() => setOrderFeedback(null), 4000);
    } catch (err: any) {
      setOrderFeedback(`Order failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const totalNotional = (quantity * orderPrice * duration).toFixed(2);
  const normalizedCuTotal = (quantity * (cap?.baseGpuxCu || 1.0)).toFixed(1);

  // Physical Cost of Capacity components
  const capexAmortization = Number(((cap?.powerTdpW || 700) > 800 ? 2.15 : 1.35).toFixed(2));
  const energyCostHour = Number(((cap?.powerTdpW || 700) / 1000 * 1.15 * 0.082).toFixed(3));
  const chassisInfiniBand = Number((capexAmortization * 0.4).toFixed(2));
  const baseCostFloor = (capexAmortization + energyCostHour + chassisInfiniBand + 0.25).toFixed(2);

  return (
    <div id="spot-market-desk" className="p-4 space-y-4 text-[#D1D1D1] font-sans">
      {/* GPU Model Selector Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {(Object.keys(capabilities || {}) as GpuModelId[]).map((modelKey) => {
          const c = capabilities?.[modelKey];
          const m = (markets || []).find(item => item.gpuModel === modelKey);
          const isSelected = selectedModel === modelKey;
          const isPos = (m?.priceChange24hPct ?? 0) >= 0;

          return (
            <button
              key={modelKey}
              id={`gpu-select-${modelKey}`}
              onClick={() => onSelectModel(modelKey)}
              className={`flex-shrink-0 px-4 py-2.5 rounded-lg border transition text-left ${
                isSelected
                  ? 'bg-[#001A1D] border-[#00E5FF] shadow-[0_0_12px_rgba(0,229,255,0.25)]'
                  : 'bg-[#0A0A0A] border-[#222] hover:border-[#333] hover:bg-[#111]'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <span className={`font-mono font-bold text-xs uppercase tracking-wider ${isSelected ? 'text-[#00E5FF]' : 'text-white'}`}>
                  {c?.model || modelKey}
                </span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#1A1A1A] text-[#888] font-mono border border-[#333]">
                  {c?.baseGpuxCu?.toFixed(2) ?? '1.00'} CU
                </span>
              </div>
              <div className="flex items-center justify-between gap-4 mt-1.5 text-[11px] font-mono">
                <span className="text-[#00E5FF] font-bold">
                  ${m?.lastPrice?.toFixed(2) ?? '40.00'}/hr
                </span>
                <span className={`text-[10px] font-bold ${isPos ? 'text-[#00FF41]' : 'text-[#FF4444]'}`}>
                  {isPos ? '+' : ''}{(m?.priceChange24hPct ?? 0).toFixed(1)}%
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Grid: Left Charts & Specs, Center Order Book, Right Place Order Desk */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Market Candlestick/Area Chart & Cost of Capacity (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Header Stats */}
          <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-[10px] uppercase tracking-widest text-[#666] mb-1">
                  GPU CLASSIFICATION & BENCHMARK
                </div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-black text-white tracking-tight font-mono">{cap?.model || selectedModel}</h2>
                  <span className="px-2 py-0.5 rounded bg-[#1A1A1A] text-[#00E5FF] text-[10px] font-mono border border-[#333] uppercase">
                    {cap?.architecture || 'Hopper'}
                  </span>
                </div>
                <p className="text-[11px] font-mono text-[#888] mt-1">
                  {cap?.memoryGb ?? 80}GB {cap?.memoryType ?? 'HBM3'} • {cap?.memoryBandwidthGbs ?? 3350} GB/s • {cap?.bf16Tflops ?? 989} BF16 TFLOPs
                </p>
              </div>

              <div className="text-right font-mono">
                <div className="text-2xl font-bold text-[#00E5FF] drop-shadow-[0_0_8px_rgba(0,229,255,0.3)]">
                  ${currentMarket?.lastPrice?.toFixed(2) ?? '42.00'}
                  <span className="text-xs text-[#666] font-normal"> / GPU-hr</span>
                </div>
                <div className={`text-xs flex items-center justify-end gap-1 font-bold ${
                  (currentMarket?.priceChange24hPct ?? 0) >= 0 ? 'text-[#00FF41]' : 'text-[#FF4444]'
                }`}>
                  {(currentMarket?.priceChange24hPct ?? 0) >= 0 ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                  {Math.abs(currentMarket?.priceChange24hPct ?? 0).toFixed(2)}% (24H)
                </div>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-4 gap-2 mt-4 pt-3 border-t border-[#1A1A1A] text-xs font-mono">
              <div>
                <div className="text-[#666] text-[9px] uppercase tracking-widest">24H HIGH</div>
                <div className="text-white font-bold">${currentMarket?.high24h?.toFixed(2) ?? '45.00'}</div>
              </div>
              <div>
                <div className="text-[#666] text-[9px] uppercase tracking-widest">24H LOW</div>
                <div className="text-white font-bold">${currentMarket?.low24h?.toFixed(2) ?? '38.00'}</div>
              </div>
              <div>
                <div className="text-[#666] text-[9px] uppercase tracking-widest">24H VOLUME</div>
                <div className="text-white font-bold">{currentMarket?.volume24hGpuHours?.toLocaleString() ?? '12,500'} hrs</div>
              </div>
              <div>
                <div className="text-[#666] text-[9px] uppercase tracking-widest">VOLATILITY</div>
                <div className="text-[#F27D26] font-bold">{currentMarket?.impliedVolatility24h?.toFixed(1) ?? '32.0'}%</div>
              </div>
            </div>

            {/* Chart View */}
            <div className="mt-4 h-52 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={currentMarket?.priceHistory || []}>
                  <defs>
                    <linearGradient id="spotGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00E5FF" stopOpacity={0.35}/>
                      <stop offset="95%" stopColor="#00E5FF" stopOpacity={0.0}/>
                    </linearGradient>
                  </defs>
                  <XAxis 
                    dataKey="timestamp" 
                    tickFormatter={(t) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    stroke="#444"
                    fontSize={9}
                    fontFamily="monospace"
                  />
                  <YAxis 
                    domain={['auto', 'auto']}
                    stroke="#444"
                    fontSize={9}
                    fontFamily="monospace"
                    tickFormatter={(v) => `$${v}`}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#050505', borderColor: '#222', fontSize: '11px', fontFamily: 'monospace', color: '#D1D1D1' }}
                    formatter={(value: any) => [`$${Number(value).toFixed(2)}/hr`, 'Spot Price']}
                    labelFormatter={(l) => new Date(l).toLocaleString()}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="close" 
                    stroke="#00E5FF" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#spotGradient)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Physical Cost of Capacity Model Breakdown */}
          <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-1.5">
                <DollarSign className="w-3.5 h-3.5 text-[#00E5FF]" />
                Physical Cost-of-Capacity Model
              </div>
              <span className="text-[10px] text-[#00E5FF] font-mono">Floor: ${baseCostFloor}/GPU-hr</span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="flex items-center justify-between text-[#888]">
                <span>Hardware CapEx (3-Yr / 26k hrs):</span>
                <span className="text-white">${capexAmortization.toFixed(2)}/hr</span>
              </div>
              <div className="flex items-center justify-between text-[#888]">
                <span>Chassis + InfiniBand NDR Switch:</span>
                <span className="text-white">${chassisInfiniBand.toFixed(2)}/hr</span>
              </div>
              <div className="flex items-center justify-between text-[#888]">
                <span>Energy Cost (TDP {cap?.powerTdpW}W × 1.15 PUE):</span>
                <span className="text-[#F27D26]">${energyCostHour.toFixed(3)}/hr</span>
              </div>
              <div className="flex items-center justify-between text-[#888]">
                <span>Facility OpEx & Redundancy:</span>
                <span className="text-white">$0.25/hr</span>
              </div>
              <div className="pt-2 border-t border-[#1A1A1A] flex items-center justify-between font-bold">
                <span className="text-[#00E5FF]">Market Clearing Spot:</span>
                <span className="text-[#00E5FF] text-sm">
                  ${currentMarket?.lastPrice?.toFixed(2) ?? '40.00'}/hr 
                  <span className="text-[10px] text-[#888] font-normal ml-1">
                    (+{(((currentMarket?.lastPrice || 40) - Number(baseCostFloor)) / Number(baseCostFloor || 1) * 100).toFixed(0)}% Rent)
                  </span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Center Column: Live Continuous Double-Auction Order Book (4 Cols) */}
        <div className="lg:col-span-4 bg-[#0A0A0A] border border-[#222] rounded-lg flex flex-col justify-between overflow-hidden">
          <div>
            <div className="flex border-b border-[#222] bg-[#111]">
              <div className="px-5 py-2.5 border-b-2 border-[#00E5FF] text-[10px] tracking-widest text-white uppercase font-mono font-bold">
                ORDER BOOK: {selectedModel ? selectedModel.split('_')[0] : 'H100'}
              </div>
              <div className="px-5 py-2.5 text-[10px] tracking-widest text-[#666] uppercase font-mono">
                SPREAD: ${(((currentMarket?.asks?.[0]?.pricePerGpuHour ?? 42)) - ((currentMarket?.bids?.[0]?.pricePerGpuHour ?? 41.5))).toFixed(2)}
              </div>
            </div>

            {/* Asks (Sell Orders) - Red */}
            <div className="p-3 space-y-1 text-[11px] font-mono">
              <div className="grid grid-cols-4 text-[#555] text-[9px] uppercase pb-1.5 border-b border-[#1A1A1A]">
                <span>ASK ($)</span>
                <span className="text-right">QTY</span>
                <span className="text-right">CU</span>
                <span className="text-right">NODE</span>
              </div>

              {(currentMarket?.asks || []).slice(0, 5).reverse().map((ask, i) => (
                <div 
                  key={ask.id || i}
                  className="grid grid-cols-4 py-1 px-2 rounded relative overflow-hidden group bg-[#220000]/60 text-[#FF4444]"
                >
                  <div 
                    className="absolute right-0 top-0 bottom-0 bg-[#FF4444]/15 pointer-events-none"
                    style={{ width: `${Math.min(100, (ask.quantityGpus / 256) * 100)}%` }}
                  />
                  <span className="font-bold relative z-10">${ask.pricePerGpuHour?.toFixed(2) ?? '0.00'}</span>
                  <span className="text-right text-[#D1D1D1] relative z-10">{ask.quantityGpus}</span>
                  <span className="text-right text-[#888] relative z-10">{ask.normalizedCu?.toFixed(0) ?? '0'}</span>
                  <span className="text-right text-[#888] truncate relative z-10" title={ask.creatorName}>
                    {ask.creatorName ? ask.creatorName.split(' ')[0] : 'Node'}
                  </span>
                </div>
              ))}
            </div>

            {/* Middle Market Clearing Price Bar */}
            <div className="my-1 py-2 px-4 bg-[#050505] border-y border-[#222] flex items-center justify-between font-mono text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse"></span>
                <span className="text-[#888] uppercase text-[10px] tracking-wider">MATCHING ENGINE CLEARING</span>
              </div>
              <span className="text-[#00E5FF] font-bold text-sm drop-shadow-[0_0_8px_rgba(0,229,255,0.3)]">
                ${currentMarket?.lastPrice?.toFixed(2) ?? '40.00'}
                <span className="text-[10px] text-[#666] font-normal"> /hr</span>
              </span>
            </div>

            {/* Bids (Buy Orders) - Green */}
            <div className="p-3 space-y-1 text-[11px] font-mono">
              {(currentMarket?.bids || []).slice(0, 5).map((bid, i) => (
                <div 
                  key={bid.id || i}
                  className="grid grid-cols-4 py-1 px-2 rounded relative overflow-hidden group bg-[#002200]/60 text-[#00FF41]"
                >
                  <div 
                    className="absolute right-0 top-0 bottom-0 bg-[#00FF41]/15 pointer-events-none"
                    style={{ width: `${Math.min(100, (bid.quantityGpus / 256) * 100)}%` }}
                  />
                  <span className="font-bold relative z-10">${bid.pricePerGpuHour?.toFixed(2) ?? '0.00'}</span>
                  <span className="text-right text-[#D1D1D1] relative z-10">{bid.quantityGpus}</span>
                  <span className="text-right text-[#888] relative z-10">{bid.normalizedCu?.toFixed(0) ?? '0'}</span>
                  <span className="text-right text-[#888] truncate relative z-10" title={bid.creatorName}>
                    {bid.creatorName ? bid.creatorName.split(' ')[0] : 'Node'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Trades Tape */}
          <div className="p-3 border-t border-[#222] bg-[#0D0D0D]">
            <div className="text-[9px] uppercase tracking-widest text-[#666] mb-2 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Activity className="w-3 h-3 text-[#00E5FF]" />
                EXECUTED TRADE TAPE
              </span>
              <span className="text-[#00E5FF] text-[9px] font-mono">LIVE FEED</span>
            </div>
            <div className="space-y-1 text-[10px] font-mono max-h-28 overflow-y-auto scrollbar-thin">
              {(trades || []).slice(0, 5).map((t) => (
                <div key={t.id} className="flex items-center justify-between text-[#888] py-0.5">
                  <span className="text-[#555]">{new Date(t.timestamp).toLocaleTimeString()}</span>
                  <span className="text-white font-bold">{t.quantity}× {t.gpuModel ? t.gpuModel.split('_')[0] : 'GPU'}</span>
                  <span className="text-[#00FF41] font-bold">${t.price?.toFixed(2) ?? '0.00'}</span>
                  <span className="text-[#777] truncate max-w-[80px]">{t.buyer ? t.buyer.split(' ')[0] : 'Buyer'}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Order Desk (3 Cols) */}
        <div className="lg:col-span-3 bg-[#0A0A0A] border border-[#222] rounded-lg p-4 flex flex-col justify-between">
          <form onSubmit={handleSubmitOrder} className="space-y-3.5 font-sans">
            <div className="flex items-center justify-between border-b border-[#222] pb-2">
              <div className="text-[10px] uppercase tracking-widest text-[#666] flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-[#00E5FF]" />
                Place Spot Order
              </div>
              <span className="text-[9px] font-mono text-[#00FF41] bg-[#002200] border border-[#00FF41]/40 px-1.5 py-0.2 rounded font-bold uppercase">
                INSTANT
              </span>
            </div>

            {/* Buy / Sell Toggle */}
            <div className="grid grid-cols-2 gap-1 bg-[#050505] p-1 rounded border border-[#222] font-mono">
              <button
                type="button"
                id="order-side-buy-btn"
                onClick={() => setOrderSide('BUY')}
                className={`py-1.5 text-xs font-bold rounded transition uppercase tracking-wider ${
                  orderSide === 'BUY'
                    ? 'bg-[#002200] border border-[#00FF41] text-[#00FF41] shadow-[0_0_8px_rgba(0,255,65,0.25)]'
                    : 'text-[#666] hover:text-white'
                }`}
              >
                BUY (Demand)
              </button>
              <button
                type="button"
                id="order-side-sell-btn"
                onClick={() => setOrderSide('SELL')}
                className={`py-1.5 text-xs font-bold rounded transition uppercase tracking-wider ${
                  orderSide === 'SELL'
                    ? 'bg-[#220000] border border-[#FF4444] text-[#FF4444] shadow-[0_0_8px_rgba(255,68,68,0.25)]'
                    : 'text-[#666] hover:text-white'
                }`}
              >
                SELL (Supply)
              </button>
            </div>

            {/* Quantity in GPUs */}
            <div>
              <div className="flex justify-between text-xs mb-1 font-mono">
                <span className="text-[#888]">GPU QUANTITY:</span>
                <span className="text-white font-bold">{quantity} GPUs ({normalizedCuTotal} CU)</span>
              </div>
              <div className="grid grid-cols-4 gap-1 mb-1.5 font-mono text-xs">
                {[8, 16, 32, 64].map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => setQuantity(q)}
                    className={`py-1 rounded border text-[10px] font-bold ${
                      quantity === q
                        ? 'bg-[#001A1D] border-[#00E5FF] text-[#00E5FF]'
                        : 'bg-[#111] border-[#222] text-[#888] hover:bg-[#1A1A1A]'
                    }`}
                  >
                    {q}x
                  </button>
                ))}
              </div>
              <input
                type="range"
                min="1"
                max="256"
                step="1"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full accent-[#00E5FF] cursor-pointer"
              />
            </div>

            {/* Price Per GPU-Hour */}
            <div>
              <div className="flex justify-between text-xs mb-1 font-mono">
                <span className="text-[#888]">PRICE / GPU-HOUR:</span>
                <span className="text-[#00E5FF] font-bold">${Number(orderPrice).toFixed(2)}</span>
              </div>
              <div className="relative font-mono">
                <span className="absolute left-3 top-2 text-[#666] text-xs">$</span>
                <input
                  type="number"
                  step="0.10"
                  min="1"
                  value={orderPrice}
                  onChange={(e) => setOrderPrice(Number(e.target.value))}
                  className="w-full bg-[#050505] border border-[#222] rounded pl-7 pr-3 py-1.5 text-xs text-white focus:border-[#00E5FF] focus:outline-none font-mono"
                />
              </div>
            </div>

            {/* Duration */}
            <div>
              <div className="flex justify-between text-xs mb-1 font-mono">
                <span className="text-[#888]">EXECUTION DURATION:</span>
                <span className="text-white font-bold">{duration} Hours</span>
              </div>
              <select
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-xs text-white font-mono focus:border-[#00E5FF] focus:outline-none"
              >
                <option value={6}>6 Hours (Quick Batch)</option>
                <option value={12}>12 Hours (Half-Day Run)</option>
                <option value={24}>24 Hours (1 Full Day)</option>
                <option value={72}>72 Hours (3-Day Training)</option>
                <option value={168}>168 Hours (1-Week Cluster)</option>
              </select>
            </div>

            {/* Account Identifier */}
            <div>
              <div className="text-[9px] uppercase tracking-widest text-[#666] mb-1 font-mono">
                ORGANIZATION / TRADER
              </div>
              <input
                type="text"
                value={buyerName}
                onChange={(e) => setBuyerName(e.target.value)}
                className="w-full bg-[#050505] border border-[#222] rounded px-3 py-1.5 text-xs text-white font-mono focus:border-[#00E5FF] focus:outline-none"
                placeholder="e.g. Nexus Research Labs"
              />
            </div>

            {/* Cost Summary Box */}
            <div className="bg-[#050505] border border-[#222] rounded p-3 space-y-1 text-xs font-mono">
              <div className="flex justify-between text-[#888]">
                <span>TOTAL GPU-HOURS:</span>
                <span className="text-white font-bold">{(quantity * duration).toLocaleString()} hrs</span>
              </div>
              <div className="flex justify-between text-[#888]">
                <span>TOTAL NOTIONAL:</span>
                <span className="text-[#00E5FF] font-bold text-sm drop-shadow-[0_0_8px_rgba(0,229,255,0.3)]">${totalNotional}</span>
              </div>
            </div>

            {orderFeedback && (
              <div className="p-2 rounded bg-[#001A1D] border border-[#00E5FF]/40 text-[#00E5FF] text-[10px] font-mono">
                {orderFeedback}
              </div>
            )}

            <button
              type="submit"
              id="submit-spot-order-btn"
              disabled={isSubmitting}
              className={`w-full py-2.5 rounded text-xs font-mono font-bold transition uppercase tracking-wider ${
                orderSide === 'BUY'
                  ? 'bg-[#00E5FF] hover:bg-[#00cce6] text-[#050505] shadow-[0_0_12px_rgba(0,229,255,0.3)]'
                  : 'bg-[#FF4444] hover:bg-[#ee3333] text-white shadow-[0_0_12px_rgba(255,68,68,0.3)]'
              }`}
            >
              {isSubmitting ? 'ROUTING...' : `${orderSide === 'BUY' ? 'Execute Buy Spot' : 'Expose Compute Capacity'}`}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
