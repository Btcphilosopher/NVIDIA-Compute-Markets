import React from 'react';
import { 
  Sliders, 
  Zap, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  RefreshCw, 
  CheckCircle2,
  AlertTriangle,
  Flame,
  Leaf,
  Cpu,
  Layers
} from 'lucide-react';
import { MacroScenario } from '../types/market.js';

interface ScenarioSandboxProps {
  scenarios: MacroScenario[];
  activeScenarioKey: string;
  onSelectScenario: (key: string) => void;
  onStepTime: (unit: '1D' | '1W' | '1M' | '1Y') => void;
}

export const ScenarioSandbox: React.FC<ScenarioSandboxProps> = ({
  scenarios,
  activeScenarioKey,
  onSelectScenario,
  onStepTime
}) => {
  const activeScenario = scenarios.find(s => s.key === activeScenarioKey) || scenarios[0];

  return (
    <div id="scenario-sandbox" className="p-4 space-y-4 text-[#D1D1D1] font-sans">
      {/* Top Banner */}
      <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="text-xl font-black text-white font-mono flex items-center gap-2">
              <Sliders className="w-5 h-5 text-[#F27D26]" />
              Macro Market Scenarios & Stress Simulation
            </div>
            <span className="px-2 py-0.5 rounded bg-[#221200] text-[#F27D26] text-[9px] font-mono border border-[#F27D26]/40 uppercase tracking-wider">
              QUANT SIMULATION ENGINE
            </span>
          </div>
          <p className="text-xs text-[#888] font-mono mt-1">
            Simulate supply shortages, Blackwell architecture shifts, green energy mandates, and geopolitical shocks across spot and strike forward curves.
          </p>
        </div>

        {/* Fast Time Stepper Bar */}
        <div className="flex items-center gap-2 bg-[#050505] p-1.5 rounded border border-[#222] font-mono text-xs">
          <Clock className="w-4 h-4 text-[#666] ml-1" />
          <span className="text-[10px] text-[#888] uppercase pr-1">ADVANCE MARKET CLOCK:</span>
          {(['1D', '1W', '1M', '1Y'] as const).map((unit) => (
            <button
              key={unit}
              onClick={() => onStepTime(unit)}
              className="px-2.5 py-1 rounded bg-[#1A1A1A] text-white hover:bg-[#00E5FF] hover:text-[#050505] transition font-bold text-xs"
            >
              +{unit}
            </button>
          ))}
        </div>
      </div>

      {/* Active Multipliers Status Bar */}
      {activeScenario && (
        <div className="bg-[#0A0A0A] border border-[#222] rounded-lg p-4 font-mono">
          <div className="flex items-center justify-between mb-3">
            <div className="text-[10px] uppercase tracking-widest text-[#666]">
              ACTIVE MACRO MULTIPLIERS — {activeScenario.title}
            </div>
            <span className="text-xs text-[#00E5FF]">{activeScenario.narrative}</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
            <div className="bg-[#050505] p-3 rounded border border-[#222]">
              <div className="text-[#666] text-[9px] uppercase mb-1">SPOT PRICE MULTIPLIER</div>
              <div className={`text-lg font-bold ${(activeScenario.spotPriceMultiplier || 1.0) >= 1.0 ? 'text-[#FF4444]' : 'text-[#00FF41]'}`}>
                {activeScenario.spotPriceMultiplier?.toFixed(2) ?? '1.00'}×
              </div>
            </div>
            <div className="bg-[#050505] p-3 rounded border border-[#222]">
              <div className="text-[#666] text-[9px] uppercase mb-1">VOLATILITY MULTIPLIER</div>
              <div className="text-lg font-bold text-[#F27D26]">
                {activeScenario.volatilityMultiplier?.toFixed(2) ?? '1.00'}×
              </div>
            </div>
            <div className="bg-[#050505] p-3 rounded border border-[#222]">
              <div className="text-[#666] text-[9px] uppercase mb-1">DEMAND SURGE</div>
              <div className="text-lg font-bold text-[#00E5FF]">
                {activeScenario.demandSurgeMultiplier?.toFixed(2) ?? '1.00'}×
              </div>
            </div>
            <div className="bg-[#050505] p-3 rounded border border-[#222]">
              <div className="text-[#666] text-[9px] uppercase mb-1">CAPACITY AVAILABLE</div>
              <div className="text-lg font-bold text-white">
                {activeScenario.capacityAvailableMultiplier?.toFixed(2) ?? '1.00'}×
              </div>
            </div>
            <div className="bg-[#050505] p-3 rounded border border-[#222]">
              <div className="text-[#666] text-[9px] uppercase mb-1">ENERGY COST SHIFT</div>
              <div className="text-lg font-bold text-[#F27D26]">
                {activeScenario.energyCostMultiplier?.toFixed(2) ?? '1.00'}×
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Scenario Presets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {scenarios.map((scen) => {
          const isActive = scen.key === activeScenarioKey;
          return (
            <div
              key={scen.key}
              onClick={() => onSelectScenario(scen.key)}
              className={`p-4 rounded-lg border transition cursor-pointer flex flex-col justify-between font-mono ${
                isActive
                  ? 'bg-[#001A1D] border-[#00E5FF] shadow-[0_0_15px_rgba(0,229,255,0.25)]'
                  : 'bg-[#0A0A0A] border-[#222] hover:border-[#333]'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <h3 className={`font-bold text-sm ${isActive ? 'text-[#00E5FF]' : 'text-white'}`}>
                    {scen.title}
                  </h3>
                  {isActive && (
                    <span className="text-[9px] px-2 py-0.5 rounded bg-[#00E5FF] text-[#050505] font-bold uppercase tracking-wider">
                      ACTIVE
                    </span>
                  )}
                </div>
                <p className="text-xs text-[#888] font-sans mt-1.5 leading-relaxed">
                  {scen.narrative}
                </p>
              </div>

              <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-[#1A1A1A] text-[10px] text-[#888]">
                <div>
                  <span className="text-[#555] block">SPOT</span>
                  <span className={`font-bold ${scen.spotPriceMultiplier >= 1.0 ? 'text-[#FF4444]' : 'text-[#00FF41]'}`}>
                    {scen.spotPriceMultiplier}×
                  </span>
                </div>
                <div>
                  <span className="text-[#555] block">VOL</span>
                  <span className="font-bold text-[#F27D26]">{scen.volatilityMultiplier}×</span>
                </div>
                <div>
                  <span className="text-[#555] block">DEMAND</span>
                  <span className="font-bold text-[#00E5FF]">{scen.demandSurgeMultiplier}×</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
