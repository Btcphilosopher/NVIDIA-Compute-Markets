export type GpuModelId = 
  | 'H100_SXM5' 
  | 'H100_NVL' 
  | 'H200_SXM5' 
  | 'B100' 
  | 'B200' 
  | 'GB200_NVL72' 
  | 'A100_SXM4_80GB' 
  | 'L40S' 
  | 'RTX_4090' 
  | 'RTX_6000_ADA';

export type WorkloadType = 
  | 'transformer_pretrain' 
  | 'transformer_inference' 
  | 'matrix_multiplication' 
  | 'image_diffusion' 
  | 'scientific_hpc' 
  | 'simulation_rendering' 
  | 'finetuning_lora';

export type SettlementMethod = 'PHYSICAL_EXECUTION' | 'CASH_SETTLEMENT';

export type ContractStatus = 
  | 'PROPOSED' 
  | 'ESCROW_LOCKED' 
  | 'ACTIVE_EXECUTING' 
  | 'PROOF_SUBMITTED' 
  | 'ORACLE_VERIFIED' 
  | 'SETTLED' 
  | 'SLA_PENALIZED' 
  | 'DEFAULTED' 
  | 'CANCELLED';

export interface GpuCapability {
  id: GpuModelId;
  manufacturer: string;
  model: string;
  architecture: string;
  generation: string;
  memoryGb: number;
  memoryType: string;
  memoryBandwidthGbs: number;
  computeCapability: string;
  tensorCoreGen: number;
  tensorCoreCount: number;
  fp32Tflops: number;
  fp16Tflops: number;
  bf16Tflops: number;
  fp8Tflops: number;
  int8Tops: number;
  nvlinkBandwidthGbs: number;
  powerTdpW: number;
  thermalLimitC: number;
  baseGpuxCu: number;
  workloadMultipliers: Record<WorkloadType, number>;
}

export interface ProviderFacility {
  id: string;
  providerId: string;
  providerName: string;
  providerType: 'HYPERSCALER' | 'NEOCLOUD' | 'PRIVATE_DATACENTRE' | 'AI_LAB' | 'ENTERPRISE';
  facilityId: string;
  facilityName: string;
  region: string;
  country: string;
  city: string;
  lat: number;
  lng: number;
  pue: number;
  electricityRateKwh: number;
  greenEnergyPercentage: number;
  networkTier: string;
  egressCostGb: number;
  clusterCount: number;
  totalGpuCount: number;
  availableGpuCount: number;
  externalProviderId: string;
}

export interface ClusterNode {
  id: string;
  clusterId: string;
  facilityId: string;
  providerId: string;
  nodeName: string;
  gpuModel: GpuModelId;
  gpuCount: number;
  cpuModel: string;
  ramGb: number;
  storageTb: number;
  interconnect: 'NVLINK_4' | 'NVLINK_5' | 'INFINIBAND_NDR' | 'INFINIBAND_HDR' | 'PCIE_GEN5' | 'ROCE_V2';
  networkSpeedGbps: number;
  status: 'AVAILABLE' | 'RESERVED' | 'EXECUTING' | 'MAINTENANCE' | 'OFFLINE';
  hourlySpotAsk: number;
  reliabilityScore: number;
  externalNodeId: string;
}

export interface LiveGpuTelemetry {
  nodeId: string;
  gpuIndex: number;
  gpuModel: GpuModelId;
  timestamp: string;
  gpuUtilPct: number;
  memoryUtilPct: number;
  tensorCoreUtilPct: number;
  hbm3eBandwidthPct: number;
  powerDrawWatts: number;
  temperatureC: number;
  fanSpeedPct: number;
  pcieRxMbS: number;
  pcieTxMbS: number;
  nvlinkThroughputGbs: number;
  throttleReason: 'NONE' | 'THERMAL' | 'POWER' | 'SW_REDUCTION';
  energyCostCurrentHourUsd: number;
}

export interface DcgmTelemetryRollup {
  nodeId: string;
  facilityId: string;
  gpuModel: GpuModelId;
  gpuCount: number;
  avgGpuCoreUtilPct: number;
  avgTensorCoreUtilPct: number;
  memoryBandwidthUtilPct: number;
  vramUsedGb: number;
  avgPowerDrawWatts: number;
  avgTemperatureCelsius: number;
  pcieNvlinkThroughputGbs: number;
  thermalThrottleEvents: number;
  powerCapThrottleEvents: number;
  energyCostAccumulatedUsd: number;
  telemetryMerkleLeaf: string;
  timestamp: string;
}

export interface OrderBookEntry {
  id: string;
  side: 'BUY' | 'SELL';
  gpuModel: GpuModelId;
  quantityGpus: number;
  normalizedCu: number;
  pricePerGpuHour: number;
  locationRequirement?: string;
  durationHours: number;
  minReliability: number;
  creatorAddress: string;
  creatorName: string;
  timestamp: string;
  filledQuantity: number;
}

export interface SpotMarketState {
  gpuModel: GpuModelId;
  lastPrice: number;
  priceChange24hPct: number;
  high24h: number;
  low24h: number;
  volume24hGpuHours: number;
  impliedVolatility24h: number;
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  depthChart: { price: number; cumulativeBids: number; cumulativeAsks: number }[];
  priceHistory: { timestamp: string; open: number; high: number; low: number; close: number; volume: number }[];
}

export interface StrikeContract {
  id: string;
  contractNumber: string;
  buyerAddress: string;
  buyerName: string;
  sellerAddress?: string;
  sellerName?: string;
  gpuModel: GpuModelId;
  gpuQuantity: number;
  totalNormalizedCu: number;
  executionStartTime: string;
  executionEndTime: string;
  durationHours: number;
  strikePricePerGpuHour: number;
  totalPremiumUsd: number;
  notionalValueUsd: number;
  escrowLockedUsd: number;
  settlementMethod: SettlementMethod;
  performanceFloorPct: number;
  availabilityFloorPct: number;
  locationConstraint?: string;
  status: ContractStatus;
  createdAt: string;
  txHashEscrow?: string;
  txHashSettlement?: string;
  proofHash?: string;
  actualDeliveredPerformance?: number;
  actualAvailability?: number;
  settlementAmountUsd?: number;
  penaltySlashedUsd?: number;
}

export interface ProofOfCompute {
  id: string;
  contractId: string;
  jobId: string;
  providerId: string;
  nodeId: string;
  gpuModel: GpuModelId;
  gpuCount: number;
  startTime: string;
  endTime: string;
  workloadType: WorkloadType;
  workloadSignatureSha256: string;
  telemetryMerkleRoot: string;
  dcgmSamplingCount: number;
  avgGpuUtilPct: number;
  avgTensorUtilPct: number;
  avgMemoryUtilPct: number;
  totalEnergyKwh: number;
  deliveredPerformancePct: number;
  deliveredAvailabilityPct: number;
  slaPassed: boolean;
  oracleSignature: string;
  verifiedAt: string;
  onChainBlockNumber: number;
}

export interface ForwardCurvePoint {
  tenor: string;
  days: number;
  forwardSpotPrice: number;
  impliedVolatility: number;
  costOfCapacityFloor: number;
  expectedDemandGrowthPct: number;
  riskFreeRate: number;
}

export interface MonteCarloPath {
  pathIndex: number;
  points: { step: number; day: number; simulatedSpot: number; simulatedCost: number }[];
  finalPrice: number;
  isTriggeredShortage: boolean;
}

export interface MonteCarloSummary {
  simulationsCount: number;
  meanStrike: number;
  medianStrike: number;
  p05Strike: number;
  p95Strike: number;
  expectedPayoff: number;
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  samplePaths: MonteCarloPath[];
}

export interface GpuxIndex {
  symbol: string;
  name: string;
  value: number;
  change24h: number;
  change24hPct: number;
  description: string;
  basket: { gpuModel: string; weightPct: number; currentPrice: number }[];
  history: { timestamp: string; value: number }[];
}

export interface MacroScenario {
  id: string;
  key: string;
  title: string;
  description: string;
  active: boolean;
  spotMultiplier: number;
  volatilityMultiplier: number;
  demandMultiplier: number;
  capacityMultiplier: number;
  energyMultiplier: number;
  narrative: string;
}

export interface ComputeRoutingRequest {
  workloadType: WorkloadType;
  requiredCu: number;
  preferredGpu?: GpuModelId;
  durationHours: number;
  maxBudgetUsd: number;
  minPerformancePct: number;
  dataSizeGb: number;
  sourceDataRegion?: string;
  executionDate?: string;
}

export interface ComputeRoutingSolution {
  facilityId: string;
  providerName: string;
  location: string;
  gpuModel: GpuModelId;
  recommendedGpuCount: number;
  deliveredCu: number;
  computeCostUsd: number;
  dataTransferCostUsd: number;
  totalCostUsd: number;
  effectiveHourlyPerGpu: number;
  strikeLockRecommendedPrice: number;
  estimatedLatencyMs: number;
  pue: number;
  carbonScore: 'A+' | 'A' | 'B' | 'C';
  savingsVsHyperscalerPct: number;
  matchScorePct: number;
}

export interface BlockchainBlock {
  blockNumber: number;
  blockHash: string;
  previousHash: string;
  timestamp: string;
  txCount: number;
  transactions: {
    txHash: string;
    type: 'ESCROW_LOCK' | 'PROOF_VERIFIED' | 'SETTLEMENT_PAYOUT' | 'SLA_SLASH' | 'ORACLE_UPDATE';
    contractId?: string;
    amountUsd?: number;
    proofHash?: string;
    from: string;
    to: string;
    status: 'SUCCESS' | 'FINALIZED';
  }[];
}
